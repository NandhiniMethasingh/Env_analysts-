"""
Database initialization script

This script initializes the PostgreSQL database for the Environmental Monitoring application.
It creates all the necessary tables and seeds them with initial data.
"""
import os
import sys
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def init_database():
    """Initialize the database schema and seed with initial data"""
    try:
        logger.info("Starting database initialization")
        
        # Import database modules
        from database.connection import init_db
        from database.seed import seed_locations, seed_sample_readings
        
        # Initialize database tables
        logger.info("Creating database tables")
        init_db()
        
        # Seed locations from the predefined states and cities
        logger.info("Seeding locations data")
        loc_count = seed_locations()
        logger.info(f"Successfully seeded {loc_count} locations")
        
        # Seed sample environmental readings
        logger.info("Seeding sample environmental readings")
        air_count, water_count, noise_count = seed_sample_readings()
        logger.info(f"Successfully seeded {air_count} air readings, {water_count} water readings, and {noise_count} noise readings")
        
        logger.info("Database initialization completed successfully")
        return True
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        return False

if __name__ == "__main__":
    success = init_database()
    sys.exit(0 if success else 1)