"""
Location data for major cities across 5 Indian states
Contains coordinates and metadata for environmental monitoring
"""

# Dictionary of states and their major cities with coordinates
STATES_DATA = {
    "Tamil Nadu": {
        "cities": {
            "Chennai": {"lat": 13.0827, "lon": 80.2707, "description": "State capital and major port city"},
            "Coimbatore": {"lat": 11.0168, "lon": 76.9558, "description": "Industrial hub and textile center"},
            "Madurai": {"lat": 9.9252, "lon": 78.1198, "description": "Historic temple city"},
            "Tiruchirappalli": {"lat": 10.7905, "lon": 78.7047, "description": "Central Tamil Nadu commercial center"},
            "Salem": {"lat": 11.6643, "lon": 78.1460, "description": "Steel and textile manufacturing center"}
        },
        "description": "Southern state known for its Dravidian culture, temples, and industrial centers",
        "major_environmental_concerns": ["Industrial pollution", "Water scarcity", "Coastal erosion", "Urban air pollution"]
    },
    "Maharashtra": {
        "cities": {
            "Mumbai": {"lat": 19.0760, "lon": 72.8777, "description": "Financial capital of India"},
            "Pune": {"lat": 18.5204, "lon": 73.8567, "description": "Education and IT hub"},
            "Nagpur": {"lat": 21.1458, "lon": 79.0882, "description": "Winter capital of Maharashtra"},
            "Nashik": {"lat": 19.9975, "lon": 73.7898, "description": "Wine capital of India"},
            "Aurangabad": {"lat": 19.8762, "lon": 75.3433, "description": "Tourism hub with historical monuments"}
        },
        "description": "Western state with India's financial capital and diverse geography",
        "major_environmental_concerns": ["Industrial pollution", "Urban air quality", "Water pollution", "Deforestation"]
    },
    "Karnataka": {
        "cities": {
            "Bengaluru": {"lat": 12.9716, "lon": 77.5946, "description": "IT capital of India"},
            "Mysuru": {"lat": 12.2958, "lon": 76.6394, "description": "Cultural and heritage city"},
            "Mangaluru": {"lat": 12.9141, "lon": 74.8560, "description": "Major port city"},
            "Hubballi-Dharwad": {"lat": 15.3647, "lon": 75.1240, "description": "Second largest urban agglomeration in Karnataka"},
            "Belagavi": {"lat": 15.8497, "lon": 74.4977, "description": "Trading and commercial center"}
        },
        "description": "Southern state known for technology industry and natural beauty",
        "major_environmental_concerns": ["Lake pollution", "Rapid urbanization impact", "Deforestation", "Water scarcity"]
    },
    "Kerala": {
        "cities": {
            "Thiruvananthapuram": {"lat": 8.5241, "lon": 76.9366, "description": "State capital and IT hub"},
            "Kochi": {"lat": 9.9312, "lon": 76.2673, "description": "Major port and commercial center"},
            "Kozhikode": {"lat": 11.2588, "lon": 75.7804, "description": "Historic trading port"},
            "Thrissur": {"lat": 10.5276, "lon": 76.2144, "description": "Cultural capital of Kerala"},
            "Kollam": {"lat": 8.8932, "lon": 76.6141, "description": "Port city and cashew trading center"}
        },
        "description": "Coastal state known for high literacy, backwaters, and natural beauty",
        "major_environmental_concerns": ["Coastal erosion", "Wetland destruction", "Flooding", "Climate change impact"]
    },
    "Gujarat": {
        "cities": {
            "Ahmedabad": {"lat": 23.0225, "lon": 72.5714, "description": "Largest city and industrial hub"},
            "Surat": {"lat": 21.1702, "lon": 72.8311, "description": "Diamond cutting and textile center"},
            "Vadodara": {"lat": 22.3072, "lon": 73.1812, "description": "Cultural and industrial center"},
            "Rajkot": {"lat": 22.3039, "lon": 70.8022, "description": "Commercial hub of Saurashtra"},
            "Gandhinagar": {"lat": 23.2156, "lon": 72.6369, "description": "State capital and planned city"}
        },
        "description": "Western state with rapid industrialization and diverse ecosystems",
        "major_environmental_concerns": ["Industrial pollution", "Water scarcity", "Coastal degradation", "Desertification"]
    }
}

# Function to get all cities as a flat list
def get_all_cities():
    """
    Returns a flat list of all cities across all states
    
    Returns:
    - list: List of tuples with (city_name, state_name, latitude, longitude, description)
    """
    cities_list = []
    
    for state_name, state_data in STATES_DATA.items():
        for city_name, city_data in state_data["cities"].items():
            cities_list.append((
                city_name,
                state_name,
                city_data["lat"],
                city_data["lon"],
                city_data["description"]
            ))
    
    return cities_list

# Get a dictionary of state descriptions
def get_state_descriptions():
    """
    Returns a dictionary of state names and descriptions
    
    Returns:
    - dict: Dictionary with state names as keys and descriptions as values
    """
    return {state: data["description"] for state, data in STATES_DATA.items()}

# Get a list of cities in a specific state
def get_cities_in_state(state_name):
    """
    Returns a list of cities in the specified state
    
    Parameters:
    - state_name (str): Name of the state
    
    Returns:
    - list: List of tuples with (city_name, latitude, longitude, description)
    """
    if state_name not in STATES_DATA:
        return []
    
    cities = []
    for city_name, city_data in STATES_DATA[state_name]["cities"].items():
        cities.append((
            city_name, 
            city_data["lat"], 
            city_data["lon"], 
            city_data["description"]
        ))
    
    return cities

# Get major environmental concerns for a state
def get_environmental_concerns(state_name):
    """
    Returns a list of major environmental concerns for the specified state
    
    Parameters:
    - state_name (str): Name of the state
    
    Returns:
    - list: List of environmental concerns
    """
    if state_name not in STATES_DATA:
        return []
    
    return STATES_DATA[state_name]["major_environmental_concerns"]