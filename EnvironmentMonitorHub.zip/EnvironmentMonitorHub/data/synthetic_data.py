"""
Synthetic data generator for environmental quality metrics
This module generates realistic environmental data for testing and development
"""

import random
import datetime
import math
import numpy as np

# Seed for reproducibility
random.seed(42)
np.random.seed(42)

def generate_air_quality_data(latitude, longitude, date, state_name=None):
    """
    Generate synthetic air quality data for a location
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to generate data for
    - state_name (str, optional): State name to adjust data generation
    
    Returns:
    - dict: Synthetic air quality data
    """
    # Base values with some randomness
    base_aqi = 60
    
    # Seasonal variations (worse in winter)
    month = date.month
    if month in [11, 12, 1, 2]:  # Winter months
        seasonal_factor = 1.3
    elif month in [3, 4, 5]:  # Spring
        seasonal_factor = 0.9
    elif month in [6, 7, 8]:  # Summer
        seasonal_factor = 0.8
    else:  # Fall
        seasonal_factor = 1.1
    
    # State-based adjustments
    state_factors = {
        "Tamil Nadu": 1.1,
        "Maharashtra": 1.3,
        "Karnataka": 1.2,
        "Kerala": 0.8,
        "Gujarat": 1.4
    }
    
    state_factor = state_factors.get(state_name, 1.0) if state_name else 1.0
    
    # Population density proxy (simplistic model based on location)
    # Using distance from city center as a crude proxy
    def city_center_distance(lat, lon, center_lat, center_lon):
        return math.sqrt((lat - center_lat)**2 + (lon - center_lon)**2)
    
    # Average coordinates for India
    india_center_lat, india_center_lon = 20.5937, 78.9629
    distance = city_center_distance(latitude, longitude, india_center_lat, india_center_lon)
    distance_factor = 1.0 + 0.1 * math.exp(-distance * 5)  # Higher pollution near center
    
    # Calculate AQI with all factors
    aqi = int(base_aqi * seasonal_factor * state_factor * distance_factor * (0.9 + random.random() * 0.2))
    
    # Ensure AQI is within realistic range
    aqi = max(30, min(aqi, 350))
    
    # Generate pollutant values based on AQI
    pm25 = aqi * 0.4 * (0.85 + random.random() * 0.3)
    pm10 = aqi * 0.6 * (0.85 + random.random() * 0.3)
    so2 = (aqi / 5) * (0.7 + random.random() * 0.6)
    no2 = (aqi / 4) * (0.7 + random.random() * 0.6)
    co = (aqi / 40) * (0.7 + random.random() * 0.6)
    o3 = (aqi / 3) * (0.7 + random.random() * 0.6) if month in [3, 4, 5, 6, 7, 8] else (aqi / 6) * (0.7 + random.random() * 0.6)
    
    return {
        'aqi': aqi,
        'pm25': round(pm25, 1),
        'pm10': round(pm10, 1),
        'so2': round(so2, 1),
        'no2': round(no2, 1),
        'co': round(co, 1),
        'o3': round(o3, 1),
        'timestamp': datetime.datetime.now().isoformat(),
        'source': 'synthetic_data'
    }

def generate_water_quality_data(latitude, longitude, date, state_name=None):
    """
    Generate synthetic water quality data for a location
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to generate data for
    - state_name (str, optional): State name to adjust data generation
    
    Returns:
    - dict: Synthetic water quality data
    """
    # Base water quality - higher is better
    base_wqi = 75
    
    # Seasonal variations
    month = date.month
    if month in [11, 12, 1, 2]:  # Winter months
        seasonal_factor = 1.05  # Better in winter
    elif month in [3, 4, 5]:  # Spring
        seasonal_factor = 0.95  # Worse in spring (agricultural runoff)
    elif month in [6, 7, 8]:  # Summer (monsoon in many parts)
        seasonal_factor = 0.9  # Worse in monsoon
    else:  # Fall
        seasonal_factor = 1.0
    
    # State-based adjustments based on water management and resources
    state_factors = {
        "Tamil Nadu": 0.95,  # Water scarcity issues
        "Maharashtra": 0.9,  # Industrial pollution concerns
        "Karnataka": 0.97,  # Better water management but urbanization issues
        "Kerala": 1.1,  # Better rainfall and management
        "Gujarat": 0.85  # Water scarcity and industrial pollution
    }
    
    state_factor = state_factors.get(state_name, 1.0) if state_name else 1.0
    
    # Distance from coast affects salinity and other factors
    coastal_states = ["Tamil Nadu", "Kerala", "Gujarat", "Maharashtra"]
    coastal_factor = 0.95 if state_name in coastal_states else 1.0
    
    # Calculate WQI with all factors
    wqi = int(base_wqi * seasonal_factor * state_factor * coastal_factor * (0.95 + random.random() * 0.1))
    
    # Ensure WQI is within realistic range
    wqi = max(30, min(wqi, 95))
    
    # Generate water quality parameters
    ph = 7.0 + (random.random() - 0.5) * 1.5  # pH between 6.25 and 7.75
    do = 5.0 + (wqi / 100) * 3 * (0.9 + random.random() * 0.2)  # Dissolved Oxygen (mg/L)
    bod = 8.0 - (wqi / 100) * 6 * (0.9 + random.random() * 0.2)  # BOD (mg/L)
    cod = 30.0 - (wqi / 100) * 25 * (0.9 + random.random() * 0.2)  # COD (mg/L)
    tds = 500.0 - (wqi / 100) * 300 * (0.9 + random.random() * 0.2)  # TDS (mg/L)
    turbidity = 15.0 - (wqi / 100) * 12 * (0.9 + random.random() * 0.2)  # Turbidity (NTU)
    
    return {
        'ph': round(ph, 1),
        'do': round(do, 1),
        'bod': round(bod, 1),
        'cod': round(cod, 1),
        'tds': round(tds, 1),
        'turbidity': round(turbidity, 1),
        'wqi': wqi,
        'timestamp': datetime.datetime.now().isoformat(),
        'source': 'synthetic_data'
    }

def generate_noise_data(latitude, longitude, date, state_name=None):
    """
    Generate synthetic noise pollution data for a location
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to generate data for
    - state_name (str, optional): State name to adjust data generation
    
    Returns:
    - dict: Synthetic noise data
    """
    # Base noise level
    base_decibel = 60
    
    # Time-based variations (using date as a proxy for time of day in this simulation)
    day_of_week = date.weekday()
    weekend_factor = 1.1 if day_of_week >= 5 else 1.0  # Higher on weekends
    
    # State and urbanization factors
    state_factors = {
        "Tamil Nadu": 1.05,
        "Maharashtra": 1.15,
        "Karnataka": 1.1,
        "Kerala": 0.9,
        "Gujarat": 1.1
    }
    
    state_factor = state_factors.get(state_name, 1.0) if state_name else 1.0
    
    # Cities are typically noisier
    def is_major_city(lat, lon):
        # Simple check if the location is near any major city
        from data.locations import get_all_cities
        cities = get_all_cities()
        for _, _, city_lat, city_lon, _ in cities:
            distance = math.sqrt((lat - city_lat)**2 + (lon - city_lon)**2)
            if distance < 0.1:  # Arbitrary threshold
                return True
        return False
    
    urbanization_factor = 1.15 if is_major_city(latitude, longitude) else 0.9
    
    # Calculate noise level with all factors
    decibel = int(base_decibel * weekend_factor * state_factor * urbanization_factor * (0.95 + random.random() * 0.1))
    
    # Ensure noise level is within realistic range
    decibel = max(35, min(decibel, 95))
    
    # Determine category based on decibel level
    if decibel < 45:
        category = "Low"
    elif decibel < 55:
        category = "Moderate"
    elif decibel < 65:
        category = "Noticeable"
    elif decibel < 75:
        category = "Loud"
    elif decibel < 85:
        category = "Very Loud"
    else:
        category = "Extremely Loud"
    
    return {
        'decibel': decibel,
        'category': category,
        'timestamp': datetime.datetime.now().isoformat(),
        'source': 'synthetic_data'
    }

def generate_historical_data(latitude, longitude, start_date, days=7, state_name=None):
    """
    Generate synthetic historical data for trends
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - start_date (datetime.date): Start date for the historical data
    - days (int): Number of days of historical data to generate
    - state_name (str, optional): State name to adjust data generation
    
    Returns:
    - tuple: (air_data_list, water_data_list, noise_data_list)
    """
    air_data_list = []
    water_data_list = []
    noise_data_list = []
    
    for i in range(days):
        current_date = start_date - datetime.timedelta(days=i)
        
        # Generate data for each day
        air_data = generate_air_quality_data(latitude, longitude, current_date, state_name)
        water_data = generate_water_quality_data(latitude, longitude, current_date, state_name)
        noise_data = generate_noise_data(latitude, longitude, current_date, state_name)
        
        # Add timestamps
        timestamp = datetime.datetime.combine(current_date, datetime.time(12, 0))
        air_data['timestamp'] = timestamp.isoformat()
        water_data['timestamp'] = timestamp.isoformat()
        noise_data['timestamp'] = timestamp.isoformat()
        
        air_data_list.append(air_data)
        water_data_list.append(water_data)
        noise_data_list.append(noise_data)
    
    return air_data_list, water_data_list, noise_data_list