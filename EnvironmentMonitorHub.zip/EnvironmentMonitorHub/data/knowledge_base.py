"""
Knowledge base module for environmental health information
Contains reference data, educational content, and health guidelines
"""

def get_health_tips(aqi):
    """
    Get health tips based on Air Quality Index
    
    Parameters:
    - aqi (int): Air Quality Index value
    
    Returns:
    - list: List of health tips
    """
    if aqi <= 50:  # Good
        return [
            "Air quality is good - enjoy outdoor activities.",
            "Perfect time for outdoor exercise and recreational activities.",
            "No special precautions needed for the general population."
        ]
    elif aqi <= 100:  # Moderate
        return [
            "Air quality is acceptable but may be a concern for sensitive individuals.",
            "People with respiratory diseases should monitor their symptoms.",
            "Consider reducing prolonged or heavy exertion if you experience symptoms.",
            "Keep windows closed during peak traffic hours if you live near busy roads."
        ]
    elif aqi <= 150:  # Unhealthy for Sensitive Groups
        return [
            "Members of sensitive groups may experience health effects.",
            "People with heart or lung disease, older adults, and children should limit prolonged outdoor exertion.",
            "Consider moving long or intense outdoor exercises indoors or rescheduling them.",
            "If you have asthma, keep your rescue inhaler readily available.",
            "Stay hydrated and take breaks if you must be outdoors."
        ]
    elif aqi <= 200:  # Unhealthy
        return [
            "Everyone may begin to experience health effects.",
            "Avoid prolonged outdoor exertion, especially near busy roads or industrial areas.",
            "People with heart or lung disease, older adults, and children should avoid prolonged outdoor activities.",
            "Consider using an air purifier indoors.",
            "Wear a mask (N95 or better) if you must spend extended time outdoors.",
            "Keep medications on hand if you have respiratory conditions."
        ]
    elif aqi <= 300:  # Very Unhealthy
        return [
            "Health warnings of emergency conditions - everyone is likely to be affected.",
            "Avoid all outdoor physical activities.",
            "People with heart or lung disease, older adults, and children should remain indoors.",
            "Use air purifiers indoors, and keep windows and doors closed.",
            "Wear N95 respirator masks if you must go outdoors.",
            "Consider relocating temporarily if you belong to a sensitive group and cannot improve indoor air."
        ]
    else:  # Hazardous
        return [
            "Health alert: everyone may experience serious health effects.",
            "Stay indoors with filtered air and avoid all physical exertion outdoors.",
            "Keep all windows and doors closed and use air purifiers with HEPA filters.",
            "Wear N95 respirator masks or better if you must go outdoors.",
            "Check on elderly neighbors and those with heart or lung conditions.",
            "Seek medical attention if you experience difficulty breathing or other severe symptoms.",
            "Consider temporarily relocating if possible."
        ]

def get_water_health_tips(wqi):
    """
    Get health tips based on Water Quality Index
    
    Parameters:
    - wqi (int): Water Quality Index value
    
    Returns:
    - list: List of health tips
    """
    if wqi >= 95:  # Excellent
        return [
            "Water quality is excellent, suitable for all uses with standard treatment.",
            "Safe for drinking after conventional treatment such as chlorination.",
            "Ideal for recreational activities like swimming.",
            "Supports healthy aquatic ecosystems."
        ]
    elif wqi >= 80:  # Good
        return [
            "Water quality is good, with only minor pollution.",
            "Safe for drinking after proper conventional treatment.",
            "Generally safe for recreational activities.",
            "Use standard water filters for drinking water.",
            "Consider additional filtration if you have a compromised immune system."
        ]
    elif wqi >= 65:  # Fair
        return [
            "Water quality is fair with moderate pollution levels.",
            "Requires thorough treatment before drinking.",
            "Use a good quality water purifier with multiple filtration stages.",
            "Occasional monitoring of home water quality is recommended.",
            "Children and immunocompromised individuals should avoid recreational contact.",
            "Boil water for 1-3 minutes before consumption if proper filtration is unavailable."
        ]
    elif wqi >= 45:  # Marginal
        return [
            "Water quality is poor with significant contamination.",
            "Not recommended for drinking without advanced purification systems.",
            "Use RO (Reverse Osmosis) or multi-stage purification systems.",
            "Avoid recreational contact with this water.",
            "Regularly monitor your home water quality.",
            "Consider using bottled water from reliable sources for drinking.",
            "Be alert for waterborne illnesses such as diarrhea, stomach cramps, or nausea."
        ]
    else:  # Poor
        return [
            "Water quality is very poor with severe contamination.",
            "Not suitable for drinking even with conventional treatment.",
            "Avoid any contact with this water.",
            "Use only bottled water from reliable sources for drinking and cooking.",
            "Advanced water purification systems are essential if this is your water source.",
            "Contact local authorities to report poor water quality.",
            "Consider testing for specific contaminants in your home water supply.",
            "Watch for symptoms of waterborne illnesses and seek medical attention if they occur."
        ]

def get_noise_health_tips(decibel):
    """
    Get health tips based on noise levels
    
    Parameters:
    - decibel (int): Noise level in decibels
    
    Returns:
    - list: List of health tips
    """
    if decibel < 45:  # Very Low
        return [
            "Current noise levels are very comfortable.",
            "Ideal environment for rest, sleep, and concentration.",
            "No special precautions needed."
        ]
    elif decibel < 55:  # Low
        return [
            "Noise levels are comfortable for most activities.",
            "Good environment for rest and concentration.",
            "No special precautions needed for most people.",
            "Light sleepers may benefit from white noise machines."
        ]
    elif decibel < 65:  # Moderate
        return [
            "Noise levels are moderate - comparable to normal conversation.",
            "May cause slight difficulty with highly focused work.",
            "Consider using noise-cancelling headphones for concentration tasks.",
            "Light sleepers should consider earplugs or white noise for sleep."
        ]
    elif decibel < 75:  # Loud
        return [
            "Noise levels are loud - may cause stress with prolonged exposure.",
            "Can disrupt sleep and concentration.",
            "Use earplugs or noise-cancelling headphones when needed.",
            "Take breaks from the noise when possible.",
            "Consider soundproofing options for your home or workspace.",
            "Be aware that chronic exposure to this level can increase stress."
        ]
    elif decibel < 85:  # Very Loud
        return [
            "Noise levels are very loud - can cause hearing damage with extended exposure.",
            "Limit exposure time to less than 8 hours.",
            "Use ear protection like earplugs or earmuffs.",
            "Take regular breaks in quieter environments.",
            "Be aware of stress, sleep disturbance and concentration problems.",
            "Consider noise barriers or soundproofing for your living space.",
            "Monitor for symptoms like ringing in the ears."
        ]
    else:  # Extremely Loud
        return [
            "Noise levels are extremely loud - can cause hearing damage even with brief exposure.",
            "Wear proper hearing protection at all times in this environment.",
            "Limit exposure time as much as possible.",
            "Avoid adding to noise exposure with headphones.",
            "Be alert for symptoms of hearing damage like muffled hearing or ringing in the ears.",
            "Seek medical attention if you experience hearing issues.",
            "Consider relocating if this is your regular environment.",
            "Advocate for noise reduction measures in your community."
        ]

def get_pollutant_info(pollutant_name):
    """
    Get detailed information about a specific air pollutant
    
    Parameters:
    - pollutant_name (str): Name of the pollutant
    
    Returns:
    - dict: Dictionary containing pollutant information
    """
    pollutants = {
        'pm25': {
            'description': 'Fine particulate matter with a diameter of 2.5 micrometers or smaller. These particles are small enough to penetrate deep into the lungs and even enter the bloodstream.',
            'health_effects': 'Can cause respiratory issues, heart problems, lung cancer, and premature death. PM2.5 can aggravate asthma and chronic bronchitis, and has been linked to heart attacks and irregular heartbeat.',
            'sources': 'Vehicle emissions, power plants, industrial processes, cooking with solid fuels, forest fires, and construction activities. In Coimbatore, major sources include vehicle exhaust, industrial emissions, and construction dust.',
            'safe_limit': '12', # Annual mean, μg/m³ (WHO guideline)
            'protection_measures': 'Use air purifiers with HEPA filters, wear N95 masks when pollution levels are high, limit outdoor activities during high pollution periods, and keep windows closed during peak pollution hours.'
        },
        'pm10': {
            'description': 'Particulate matter with a diameter of 10 micrometers or smaller. These include dust, pollen, mold spores, and other particles that can be inhaled into the lungs.',
            'health_effects': 'Can cause respiratory problems, aggravate asthma and bronchitis, reduce lung function, and lead to premature death in people with heart or lung disease. PM10 can also irritate the eyes, nose, and throat.',
            'sources': 'Road dust, construction activities, industrial processes, agricultural operations, and natural sources like pollen and sea salt. In Coimbatore, prominent sources include road dust, construction, and stone crushers.',
            'safe_limit': '45', # Annual mean, μg/m³ (WHO guideline)
            'protection_measures': 'Wet mop indoor surfaces instead of sweeping, use air purifiers, wear masks when outdoors during dusty conditions, and keep windows closed during high wind or construction nearby.'
        },
        'so2': {
            'description': 'Sulfur dioxide is a colorless gas with a sharp, pungent odor. It is primarily emitted from the burning of fossil fuels containing sulfur.',
            'health_effects': 'Can cause respiratory problems, particularly in children, the elderly, and those with asthma. SO2 can irritate the respiratory tract, causing coughing, wheezing, and shortness of breath.',
            'sources': 'Burning of coal and oil in power plants, industrial processes, vehicle emissions (especially diesel), and metal extraction. In Coimbatore, industrial emissions are a significant source.',
            'safe_limit': '20', # 24-hour mean, ppb (WHO guideline)
            'protection_measures': 'Limit outdoor activities during high pollution alerts, use air purifiers, ensure proper ventilation when using combustion appliances, and advocate for cleaner fuel use in your community.'
        },
        'no2': {
            'description': 'Nitrogen dioxide is a reddish-brown gas with a sharp, biting odor. It is a primary air pollutant and contributes to the formation of ground-level ozone.',
            'health_effects': 'Can inflame the airways and increase susceptibility to respiratory infections. Long-term exposure can lead to chronic respiratory diseases. NO2 exposure has been linked to asthma development in children.',
            'sources': 'Vehicle emissions, power plants, industrial boilers, and any combustion process. In Coimbatore, vehicle traffic is the primary source, especially in congested areas.',
            'safe_limit': '40', # Annual mean, ppb (WHO guideline)
            'protection_measures': 'Avoid busy roads during rush hours, ensure proper ventilation when using gas stoves or heaters, use air purifiers with activated carbon filters, and reduce driving by using public transportation when possible.'
        },
        'co': {
            'description': 'Carbon monoxide is a colorless, odorless gas that is toxic at high levels. It binds to hemoglobin in the blood, reducing oxygen delivery to tissues.',
            'health_effects': 'Can cause headaches, dizziness, confusion, and at high levels, unconsciousness and death. People with heart disease are particularly vulnerable. Chronic exposure can affect cardiovascular health.',
            'sources': 'Incomplete combustion of carbon-containing fuels, vehicle exhaust, malfunctioning heating systems, and indoor sources like gas stoves and tobacco smoke. In Coimbatore, vehicle emissions are a major source.',
            'safe_limit': '9', # 8-hour average, ppm (WHO guideline)
            'protection_measures': 'Install carbon monoxide detectors in your home, ensure proper ventilation when using combustion appliances, have heating systems inspected regularly, and avoid idling vehicles in enclosed spaces.'
        },
        'o3': {
            'description': 'Ground-level ozone is not emitted directly but forms when nitrogen oxides and volatile organic compounds react in sunlight. Unlike stratospheric ozone, ground-level ozone is harmful to breathe.',
            'health_effects': 'Can cause throat irritation, coughing, chest pain, and inflammation of lung tissue. Ozone can worsen bronchitis, emphysema, and asthma. Long-term exposure may lead to permanent lung damage.',
            'sources': 'Formed by chemical reactions between oxides of nitrogen and volatile organic compounds in the presence of sunlight. These precursors come from vehicle exhaust, industrial emissions, and chemical solvents.',
            'safe_limit': '70', # 8-hour average, ppb (WHO guideline)
            'protection_measures': 'Limit outdoor activities during high ozone days (typically hot, sunny afternoons), schedule outdoor activities in the morning or evening when ozone levels are lower, and use air conditioning with a clean filter.'
        }
    }
    
    return pollutants.get(pollutant_name, {
        'description': 'Information not available',
        'health_effects': 'Information not available',
        'sources': 'Information not available',
        'safe_limit': 'Information not available',
        'protection_measures': 'Information not available'
    })

def get_water_parameter_info(parameter_name):
    """
    Get detailed information about a specific water quality parameter
    
    Parameters:
    - parameter_name (str): Name of the water parameter
    
    Returns:
    - dict: Dictionary containing parameter information
    """
    parameters = {
        'ph': {
            'description': 'pH is a measure of how acidic or basic water is, measured on a scale of 0 to 14. A pH of 7 is neutral, below 7 is acidic, and above 7 is basic.',
            'significance': 'pH affects many chemical and biological processes in water. It influences the solubility and biological availability of nutrients and heavy metals.',
            'health_effects': 'Water that is too acidic (low pH) can cause irritation to the eyes and skin, and can corrode plumbing, leaching metals into the water. Water that is too basic (high pH) can taste bitter, feel slippery, and cause scale buildup.',
            'optimal_range': '6.5 to 8.5 for drinking water'
        },
        'do': {
            'description': 'Dissolved Oxygen (DO) is the amount of oxygen dissolved in water, typically measured in milligrams per liter (mg/L).',
            'significance': 'DO is essential for aquatic life and is an indicator of a water body\'s ability to support a balanced ecosystem. Low DO levels can indicate water pollution or stagnation.',
            'health_effects': 'While not directly harmful to human health, low DO in drinking water sources can lead to bad taste, odor, and can indicate contamination. Water with low DO may also contain harmful bacteria that thrive in oxygen-poor environments.',
            'optimal_range': 'Above 5 mg/L for healthy aquatic ecosystems, though drinking water typically has higher levels after treatment'
        },
        'bod': {
            'description': 'Biochemical Oxygen Demand (BOD) measures the amount of oxygen required by microorganisms to decompose organic matter in water over a specific time period, usually 5 days.',
            'significance': 'BOD is an important indicator of organic pollution in water. High BOD indicates high levels of organic matter, which can deplete oxygen in water bodies.',
            'health_effects': 'High BOD itself is not directly harmful to humans, but it indicates possible microbial contamination and organic pollutants that could contain pathogens or toxic compounds. Waters with high BOD may have unpleasant tastes and odors.',
            'optimal_range': 'Less than 3 mg/L for clean water, drinking water should ideally have BOD close to 0 after treatment'
        },
        'cod': {
            'description': 'Chemical Oxygen Demand (COD) measures the amount of oxygen required to chemically oxidize organic and inorganic material in water.',
            'significance': 'COD is used to measure the total quantity of oxygen-demanding substances in water, including those that cannot be broken down biologically. It\'s particularly useful for assessing industrial wastewaters.',
            'health_effects': 'Like BOD, high COD itself is not directly harmful to human health, but it indicates the presence of chemicals that could be harmful. High COD can signal industrial pollution that may include toxic compounds.',
            'optimal_range': 'Less than 10 mg/L for clean water, drinking water should have very low COD after treatment'
        },
        'tds': {
            'description': 'Total Dissolved Solids (TDS) refers to the total amount of dissolved substances in water, including minerals, salts, and metals.',
            'significance': 'TDS affects the taste and appearance of water. It can indicate the presence of both natural minerals and contaminants from various sources.',
            'health_effects': 'Very high TDS levels (above 1000 mg/L) can give water an unpleasant taste and may indicate the presence of harmful contaminants. However, some dissolved minerals contribute to the nutritional value of water.',
            'optimal_range': '300 to 500 mg/L is generally acceptable for drinking water, though water with TDS up to 1000 mg/L is generally considered safe'
        },
        'turbidity': {
            'description': 'Turbidity is a measure of water clarity or cloudiness, caused by suspended particles that scatter light. It is typically measured in Nephelometric Turbidity Units (NTU).',
            'significance': 'Turbidity can indicate the presence of sediment, microorganisms, or other particles in water. High turbidity can interfere with disinfection processes and harbor pathogens.',
            'health_effects': 'While turbidity itself is not a health concern, the particles that cause it can harbor pathogens or toxic compounds. High turbidity can reduce the effectiveness of water disinfection, potentially allowing disease-causing organisms to persist.',
            'optimal_range': 'Less than 1 NTU for drinking water, with many treatment plants aiming for below 0.3 NTU'
        }
    }
    
    return parameters.get(parameter_name, {
        'description': 'Information not available',
        'significance': 'Information not available',
        'health_effects': 'Information not available',
        'optimal_range': 'Information not available'
    })

def get_educational_content(topic):
    """
    Get educational content about environmental health topics
    
    Parameters:
    - topic (str): Topic name
    
    Returns:
    - dict: Dictionary containing educational content sections
    """
    content = {
        'air_pollution': {
            'aqi_explanation': """
            The Air Quality Index (AQI) is a standardized indicator developed by environmental agencies to communicate how polluted the air currently is or how polluted it is forecast to become. It focuses on health effects you may experience within a few hours or days after breathing polluted air.
            
            The AQI scale typically ranges from 0 to 500, with higher values indicating worse air pollution and greater health concerns. The scale is divided into different categories, each corresponding to a different level of health concern.
            
            Different countries may have slightly different AQI scales and breakpoints, but they all serve the same purpose: to help you understand the implications of air quality for your health.
            """,
            
            'coimbatore_air_quality': """
            Coimbatore, known as the "Manchester of South India" due to its industrial activities, faces several air quality challenges:
            
            **Industrial Emissions**: The city hosts textile mills, foundries, and manufacturing units that contribute to air pollution through particulate matter, sulfur dioxide, and nitrogen oxides.
            
            **Vehicular Pollution**: With increasing urbanization, the number of vehicles has grown significantly, leading to higher levels of exhaust emissions, particularly in traffic congestion areas.
            
            **Construction Activities**: Rapid urban development and construction projects generate substantial dust and particulate matter.
            
            **Seasonal Variations**: Air quality tends to worsen during winter months due to temperature inversions that trap pollutants close to the ground. The pre-monsoon and post-monsoon periods can also see higher pollution levels.
            
            **Geographical Factors**: Coimbatore's location in a valley between the Western Ghats and the Nilgiri Hills affects air circulation patterns, sometimes leading to pollution build-up.
            
            According to recent data, Coimbatore generally maintains moderate air quality (AQI 51-100) on most days, though it can deteriorate to unhealthy levels in industrial zones and during adverse weather conditions. Certain areas like Peelamedu, Singanallur, and heavy traffic zones typically experience higher pollution levels compared to residential areas like Saibaba Colony.
            """,
            
            'protection_measures': """
            ### Personal Protection Measures
            
            1. **Stay Informed**: Check daily air quality forecasts for Coimbatore through the TNPCB website, CPCB's SAMEER app, or global platforms like IQAir.
            
            2. **Time Outdoor Activities**: Schedule outdoor exercises during periods of better air quality, typically early morning hours.
            
            3. **Use Face Masks**: When air quality is poor, use N95 or better respirator masks when outdoors.
            
            4. **Indoor Air Quality**:
               - Use air purifiers with HEPA filters in your home
               - Keep windows closed during high pollution periods
               - Use indoor plants known for air-purifying properties like Snake Plant, Areca Palm, and Money Plant
               - Avoid burning incense or candles indoors when air quality is poor
            
            5. **Transportation Choices**:
               - Consider carpooling or using public transportation
               - Maintain your vehicle with regular emission checks
               - Avoid idling your vehicle for extended periods
            
            6. **Diet and Health**:
               - Stay well hydrated
               - Consume antioxidant-rich foods like fruits and vegetables
               - Consider adding foods with anti-inflammatory properties to your diet
            
            ### Community-Level Actions
            
            1. **Report Violations**: Report industrial or vehicular pollution violations to the TNPCB.
            
            2. **Support Green Initiatives**: Participate in local tree planting and environmental cleanup activities.
            
            3. **Advocate for Policy Changes**: Support policies that reduce emissions from industries and vehicles.
            
            4. **Water Conservation**: Practice water conservation to help maintain adequate water levels in local water bodies, which can help control dust.
            
            5. **Waste Management**: Properly dispose of waste and avoid burning garbage, which contributes significantly to air pollution.
            """
        },
        
        'water_quality': {
            'wqi_explanation': """
            The Water Quality Index (WQI) is a single numerical value that expresses the overall water quality at a certain location and time, based on multiple water quality parameters. The WQI simplifies complex water quality data into an easily understandable and usable form.
            
            The index typically incorporates parameters such as dissolved oxygen, pH, biochemical oxygen demand, total suspended solids, total dissolved solids, fecal coliform, turbidity, and specific nutrients or pollutants.
            
            Different organizations may use slightly different methodologies to calculate WQI, but all aim to translate complex water quality data into a simple indicator that can inform decision-making and public awareness.
            
            A higher WQI value (typically on a scale of 0-100) indicates better water quality, while a lower value indicates poorer quality and greater treatment requirements before use.
            """,
            
            'coimbatore_water_quality': """
            Coimbatore's water quality varies considerably across different areas and water sources:
            
            **Surface Water Sources**:
            - **Siruvani Dam**: Traditionally considered one of the best water sources in India with naturally sweet water, though water levels and quality have faced challenges in recent years.
            - **Pillur Dam**: Another major source for Coimbatore with generally good water quality.
            - **Noyyal River**: Historically important but currently faces serious pollution from industrial effluents, sewage discharge, and urban runoff. Restoration efforts are ongoing.
            - **Lakes and Tanks**: The city has several lakes and tanks, many of which face encroachment and pollution issues.
            
            **Groundwater**:
            Groundwater quality varies substantially across the district:
            - Western areas generally have better groundwater quality
            - Eastern parts often show higher dissolved solids
            - Industrial areas may have contamination from heavy metals and chemicals
            - In some parts, fluoride levels exceed permissible limits
            
            **Common Water Quality Issues**:
            - **Hardness**: Many areas have hard water due to the region's geology
            - **Bacterial Contamination**: Particularly during monsoon seasons
            - **Industrial Pollution**: Affecting water bodies near industrial zones
            - **Salinity**: Increasing in certain areas due to over-extraction of groundwater
            - **Sewage Contamination**: Due to inadequate sewage treatment infrastructure
            
            **Seasonal Variations**:
            Water quality typically deteriorates during the monsoon due to increased runoff carrying contaminants, while pre-monsoon periods may see more concentrated pollutants due to lower water levels.
            """,
            
            'waterborne_diseases': """
            ### Common Waterborne Diseases in Coimbatore Region
            
            1. **Gastroenteritis**: Commonly caused by bacteria like E. coli or viruses. Symptoms include diarrhea, abdominal cramps, nausea, vomiting, and sometimes fever.
            
            2. **Typhoid Fever**: Caused by Salmonella typhi, spread through contaminated water or food. Symptoms include sustained high fever, weakness, stomach pains, headache, and loss of appetite.
            
            3. **Hepatitis A and E**: Viral infections affecting the liver, spread through the fecal-oral route, often via contaminated water. Symptoms include jaundice, fatigue, abdominal pain, loss of appetite, nausea, and fever.
            
            4. **Cholera**: Though not common, outbreaks can occur, especially during floods or in areas with poor sanitation. Caused by Vibrio cholerae, it leads to severe diarrhea and dehydration.
            
            5. **Diarrheal Diseases**: Various pathogens can cause diarrhea, a common symptom of waterborne illness.
            
            6. **Leptospirosis**: Caused by bacteria found in the urine of infected animals, which can contaminate water. More common during floods. Symptoms include high fever, headache, chills, muscle aches, and vomiting.
            
            7. **Amoebiasis**: Caused by the parasite Entamoeba histolytica, leading to amoebic dysentery. Symptoms include loose stools with blood and mucus, abdominal cramps, and fever.
            
            **Prevention**:
            - Always use properly treated water for drinking and cooking
            - Have a quality water purification system at home
            - Practice good hygiene and handwashing
            - Ensure food is properly washed and cooked
            - Get vaccinated against typhoid and hepatitis A
            - Avoid swimming in potentially contaminated water bodies
            """,
            
            'water_treatment_methods': """
            ### Home Water Treatment Methods
            
            1. **Boiling**:
               - Simplest method to kill pathogens
               - Bring water to a rolling boil for at least 1 minute (3 minutes at higher elevations)
               - Doesn't remove chemical contaminants or improve taste
               - Suitable for: Emergency situations and removing biological contaminants
            
            2. **Filtration Systems**:
               - **Sediment Filters**: Remove particulate matter, suitable as pre-filters
               - **Activated Carbon Filters**: Improve taste and odor, remove some chemicals
               - **Ceramic Filters**: Remove bacteria and protozoa but not viruses
               - **Reverse Osmosis (RO) Systems**: Remove most contaminants including dissolved solids (recommended for areas with hard water or industrial contamination)
               - **UV Purifiers**: Kill bacteria, viruses, and other microorganisms but don't remove chemicals or particulates
            
            3. **Chemical Treatment**:
               - **Chlorination**: Effective against many microorganisms
               - **Iodine**: Less commonly used but effective against pathogens
               - Both methods can affect taste and may not remove all contaminants
            
            4. **Multi-stage Purification**:
               - Combines various methods (e.g., sediment filtration, activated carbon, RO, and UV)
               - Most comprehensive approach for Coimbatore's variable water conditions
            
            5. **Water Softeners**:
               - Use ion exchange to remove calcium and magnesium that cause hardness
               - Useful in areas of Coimbatore with hard water problems
            
            ### Recommendations for Coimbatore:
            
            - **Areas with municipal supply**: RO or multi-stage purification systems are recommended
            - **Areas with high TDS or industrial proximity**: RO systems are essential
            - **Areas with primarily biological contamination concerns**: UV purifiers with pre-filtration
            - **For taste improvement**: Activated carbon filters (often part of multi-stage systems)
            
            ### Maintenance Tips:
            
            - Follow manufacturer's recommendations for filter replacement
            - Clean storage tanks regularly (at least every 3 months)
            - Test water quality periodically, especially after monsoons
            - Ensure systems are serviced by qualified technicians
            """
        },
        
        'noise_pollution': {
            'noise_levels_explanation': """
            Noise level is typically measured in decibels (dB), a logarithmic unit where an increase of 10 dB represents a 10-fold increase in sound intensity and is perceived as roughly twice as loud by the human ear.
            
            The decibel scale starts at 0 dB, which is the threshold of human hearing. Normal conversation typically occurs around 60 dB, while sounds above 85 dB can cause hearing damage with prolonged exposure. Pain begins around 120-130 dB.
            
            Different environments have different recommended noise limits. For example, WHO guidelines suggest that nighttime noise in residential areas should not exceed 40 dB to avoid sleep disturbance, while daytime residential noise should ideally stay below 55 dB.
            
            It's important to understand that decibels measure sound intensity on a logarithmic scale, so small increases in decibel levels represent significant increases in sound energy. For example, a 3 dB increase represents a doubling of sound energy.
            """,
            
            'health_effects': """
            ### Short-term Health Effects
            
            1. **Hearing Impairment**: Temporary threshold shift can occur after short-term exposure to loud noise, causing a temporary decrease in hearing sensitivity.
            
            2. **Sleep Disturbance**: Noise can disrupt sleep patterns, leading to:
               - Difficulty falling asleep
               - Frequent awakenings
               - Reduced REM sleep
               - Decreased sleep quality
            
            3. **Cognitive Impairment**: Noise can impair:
               - Concentration
               - Reading comprehension
               - Memory
               - Problem-solving abilities
            
            4. **Stress Responses**: Even when we're not consciously bothered by noise, our bodies may react with:
               - Increased heart rate
               - Elevated blood pressure
               - Release of stress hormones (cortisol, adrenaline)
            
            5. **Communication Difficulties**: Noise can interfere with conversation and the ability to understand speech.
            
            ### Long-term Health Effects
            
            1. **Permanent Hearing Loss**: Prolonged exposure to noise above 85 dB can cause permanent hearing damage.
            
            2. **Cardiovascular Issues**: Chronic noise exposure has been linked to:
               - Hypertension (high blood pressure)
               - Coronary heart disease
               - Increased risk of heart attack and stroke
            
            3. **Mental Health Problems**:
               - Increased anxiety and irritability
               - Higher stress levels
               - Contribution to depression
            
            4. **Metabolic Effects**:
               - Potential links to obesity and diabetes
               - Disruption of hormonal balance
            
            5. **Cognitive Development**: In children, chronic noise exposure can affect:
               - Reading skills
               - Language acquisition
               - Attention and concentration
               - Academic performance
            
            6. **Tinnitus**: Persistent ringing, buzzing, or roaring in the ears, which can significantly impact quality of life.
            """,
            
            'coimbatore_noise_pollution': """
            Coimbatore, as an industrial and rapidly urbanizing city, faces various noise pollution challenges:
            
            **Major Sources of Noise in Coimbatore**:
            
            1. **Traffic Noise**:
               - Heavy traffic areas like Gandhipuram, Ukkadam, and Singanallur experience noise levels often exceeding 75-80 dB during peak hours
               - Two-wheeler concentration and frequent honking contribute significantly to traffic noise
            
            2. **Industrial Noise**:
               - Industrial areas like SIDCO and Peelamedu Industrial Area generate significant noise from machinery and operations
               - Small and medium-scale industries spread throughout the city add to the distributed noise burden
            
            3. **Construction Activities**:
               - Rapid urban development has led to extensive construction activities
               - Construction equipment, drilling, and demolition work can produce noise levels of 90-100 dB
            
            4. **Commercial Areas**:
               - Markets like Town Hall, R.S. Puram, and Cross Cut Road experience high noise levels due to commercial activities, crowds, and traffic
               - Use of public address systems and promotional activities adds to noise levels
            
            5. **Railway Noise**:
               - Areas near railway tracks experience intermittent high noise levels from passing trains
               - Level crossings with frequent honking contribute to the noise environment
            
            6. **Festival and Event Noise**:
               - Religious festivals, processions, and cultural events often involve loudspeakers and amplified music
               - Wedding halls in residential areas can be sources of nighttime noise
            
            **Most Affected Areas**:
            - Gandhipuram Bus Stand area
            - Ukkadam-Perur Road junction
            - Areas around Coimbatore Junction railway station
            - Cross Cut Road commercial stretches
            - Peelamedu along Avinashi Road
            - Industrial corridors in SIDCO and Kurichi
            
            **Temporal Patterns**:
            - Peak noise levels typically occur during morning (8-10 AM) and evening (5-8 PM) rush hours
            - Commercial areas experience consistent noise throughout the day
            - Industrial areas have more consistent noise patterns during working hours
            - Residential areas generally experience lower noise levels, except those near major roads or commercial establishments
            """,
            
            'protection_measures': """
            ### Personal Protection Measures
            
            1. **Hearing Protection**:
               - Use earplugs or earmuffs in noisy environments
               - Consider active noise-cancelling headphones for commuting or office environments
               - Limit the volume and duration of headphone use
            
            2. **Home Modifications**:
               - Install acoustic curtains or thick drapes
               - Use weatherstripping to seal gaps around doors and windows
               - Consider double-glazed windows in severely affected areas
               - Add soft furnishings like carpets, rugs, and cushions to absorb sound
               - Place bookshelves against walls facing noisy streets
            
            3. **Create Quiet Zones**:
               - Designate a quiet room in your home, ideally away from the street
               - Use white noise machines or fans to mask disruptive external sounds
               - Consider sound-absorbing wall panels for home offices or study areas
            
            4. **Behavioral Adaptations**:
               - Plan outdoor activities during quieter times of day
               - Take regular breaks from noisy environments
               - Choose quieter routes for walking and commuting
               - Schedule important work requiring concentration during quieter hours
            
            5. **Sleep Protection**:
               - Use earplugs designed for sleeping
               - Consider white noise machines or applications
               - Rearrange bedroom furniture so beds are away from walls facing noise sources
               - Use sound-absorbing materials for bedroom décor
            
            ### Community-Level Actions
            
            1. **Know the Regulations**:
               - Familiarize yourself with Coimbatore's noise pollution rules and permitted decibel levels
               - The Noise Pollution (Regulation and Control) Rules, 2000 specify limits for different areas and times of day
            
            2. **Reporting Violations**:
               - Report excessive noise to local authorities, TNPCB, or police
               - Document noise issues with sound level meter apps (though not legally calibrated, they can provide evidence)
               - Organize community monitoring of noise levels
            
            3. **Community Planning**:
               - Advocate for noise barriers along highways near residential areas
               - Support urban forestry initiatives as trees help reduce noise
               - Promote traffic calming measures in residential neighborhoods
            
            4. **Collective Awareness**:
               - Raise awareness about noise etiquette (limiting honking, lowering volumes during nighttime)
               - Encourage neighbors to schedule noisy activities during appropriate hours
               - Support local initiatives promoting noise awareness
            """,
            
            'regulations': """
            ### Noise Pollution Regulations in India
            
            India's primary legislation governing noise pollution is **The Noise Pollution (Regulation and Control) Rules, 2000**, amended in 2010. These rules apply to Coimbatore and all other parts of India.
            
            **Key Provisions**:
            
            1. **Ambient Air Quality Standards in Respect of Noise**:
            
               | Area Category | Daytime (6 AM - 10 PM) | Nighttime (10 PM - 6 AM) |
               |--------------|------------------------|--------------------------|
               | Industrial   | 75 dB                  | 70 dB                   |
               | Commercial   | 65 dB                  | 55 dB                   |
               | Residential  | 55 dB                  | 45 dB                   |
               | Silence Zone | 50 dB                  | 40 dB                   |
            
               *Silence Zones include areas within 100 meters of hospitals, educational institutions, courts, and religious places*
            
            2. **Restrictions on Use of Loudspeakers/Public Address Systems**:
               - A loudspeaker or public address system shall not be used except after obtaining written permission from the authority
               - Loudspeakers cannot be used at night (between 10 PM and 6 AM) except in closed premises
            
            3. **Restrictions on the Use of Horns, Sound Emitting Construction Equipment, and Bursting of Crackers**:
               - No horn should be used in silence zones or during nighttime in residential areas
               - Sound-emitting construction equipment should only be used during daytime
               - Firecrackers are regulated during nighttime
            
            **Local Regulations in Coimbatore**:
            
            The Coimbatore City Municipal Corporation, along with the Tamil Nadu Pollution Control Board, is responsible for implementing these rules. Additionally:
            
            - Special restrictions may apply during examinations and festivals
            - Specific regulations for industrial zones in Coimbatore
            - Permissions required for special events using loudspeakers
            - Designated authorities for monitoring and enforcement include:
              - District Collector
              - Commissioner of Police
              - Tamil Nadu Pollution Control Board officials
              - Local body representatives
            
            **Penalties for Violations**:
            
            Under Section 15 of the Environment (Protection) Act, 1986, penalties can include:
            - Imprisonment for up to five years
            - Fines up to ₹1 lakh (₹100,000)
            - Additional fine of up to ₹5,000 per day for continuing offenses
            
            **Reporting Violations in Coimbatore**:
            
            Citizens can report noise pollution violations to:
            - Local Police Station
            - Tamil Nadu Pollution Control Board, Coimbatore Office
            - Coimbatore City Municipal Corporation
            - Through the National Pollution Control Board's SAMEER app
            """
        },
        
        'health_effects': {
            'vulnerable_populations': """
            Some populations are particularly vulnerable to the health impacts of environmental pollution:
            
            **Children**: Children's developing bodies make them especially vulnerable to environmental contaminants:
            - Higher respiratory rates relative to body size lead to greater exposure to air pollutants
            - Developing immune, respiratory, and nervous systems are more susceptible to damage
            - Hand-to-mouth behaviors increase exposure to pollutants in dust and soil
            - Longer life expectancy means more time for chronic diseases to develop following exposure
            
            **Elderly**: Older adults face increased risk due to:
            - Age-related decrease in immune function
            - Pre-existing health conditions that can be exacerbated by pollution
            - Reduced physiological reserve to cope with environmental stressors
            - Potentially limited mobility to avoid exposure
            
            **Pregnant Women**: Environmental exposures during pregnancy can affect both mother and developing fetus:
            - Certain pollutants can cross the placental barrier
            - Air pollution exposure linked to low birth weight, preterm birth, and developmental issues
            - Some toxins can affect fetal development even at levels that don't harm the mother
            
            **People with Pre-existing Conditions**: Those with certain health conditions are at greater risk:
            - Respiratory conditions (asthma, COPD) can be severely aggravated by air pollution
            - Cardiovascular disease patients show increased vulnerability to particulate matter
            - People with compromised immune systems have less defense against environmentally linked infections
            
            **Low-income Communities**: Often face disproportionate exposure due to:
            - Proximity to industrial zones, major roadways, or contaminated sites
            - Limited access to healthcare and preventive services
            - Housing that may offer less protection from outdoor pollution
            - Fewer resources to mitigate exposures (air purifiers, water filters, etc.)
            
            **Outdoor Workers**: Face increased risks through:
            - Prolonged exposure to outdoor air pollution
            - Direct sun exposure and heat stress
            - Potential occupational exposure to additional toxins
            
            **Genetic Factors**: Some individuals have genetic variations that affect:
            - Ability to detoxify certain environmental chemicals
            - Susceptibility to respiratory irritants
            - Inflammatory responses to pollutants
            """,
            
            'short_term_effects': """
            Short-term (acute) effects typically occur during or shortly after exposure to environmental pollution and may include:
            
            **Respiratory Effects**:
            - Irritation of airways
            - Coughing and wheezing
            - Shortness of breath
            - Exacerbation of asthma symptoms
            - Increased susceptibility to respiratory infections
            
            **Cardiovascular Effects**:
            - Increased heart rate
            - Elevated blood pressure
            - Irregular heartbeat
            - Reduced oxygen delivery to the heart
            
            **Neurological Effects**:
            - Headaches
            - Dizziness
            - Irritability
            - Fatigue
            - Reduced cognitive function
            
            **Other Effects**:
            - Eye, nose, and throat irritation
            - Nausea
            - Skin rashes or irritation
            - Sleep disturbances
            - Stress responses
            """,
            
            'long_term_effects': """
            Long-term (chronic) effects develop after prolonged or repeated exposure to environmental pollution and may include:
            
            **Respiratory Diseases**:
            - Development of asthma
            - Chronic Obstructive Pulmonary Disease (COPD)
            - Reduced lung function
            - Pulmonary fibrosis
            - Increased risk of lung cancer
            
            **Cardiovascular Diseases**:
            - Atherosclerosis (hardening of arteries)
            - Hypertension (high blood pressure)
            - Coronary heart disease
            - Heart failure
            - Increased risk of stroke
            
            **Cancer**:
            - Lung cancer
            - Bladder cancer
            - Leukemia
            - Other site-specific cancers related to particular pollutants
            
            **Neurological Effects**:
            - Cognitive decline
            - Increased risk of neurodegenerative diseases
            - Changes in brain structure and function
            - Developmental effects in children
            
            **Other Chronic Effects**:
            - Reproductive problems
            - Developmental issues
            - Immune system dysfunction
            - Endocrine (hormone) disruption
            - Kidney and liver damage
            """,
            
            'respiratory_effects': """
            The respiratory system is often the first point of contact for air pollutants, making it particularly vulnerable to environmental health impacts.
            
            **How Air Pollution Affects the Respiratory System**:
            
            1. **Direct Irritation**: Pollutants like ozone, sulfur dioxide, and nitrogen dioxide directly irritate the airways, causing inflammation and bronchoconstriction (narrowing of airways).
            
            2. **Oxidative Stress**: Many air pollutants generate free radicals that damage lung cells and tissues through oxidative stress.
            
            3. **Impaired Clearance Mechanisms**: Pollutants can impair the lungs' natural clearance mechanisms, such as mucociliary clearance, which normally helps remove pathogens and particles.
            
            4. **Altered Immune Responses**: Chronic exposure can alter immune responses in the lungs, potentially increasing susceptibility to infections or contributing to autoimmune conditions.
            
            **Specific Respiratory Conditions Associated with Environmental Pollution**:
            
            1. **Asthma**:
               - Air pollution can trigger asthma attacks in those already diagnosed
               - Emerging evidence suggests air pollution may contribute to new-onset asthma, especially in children
               - Traffic-related air pollution and industrial emissions are particularly implicated
            
            2. **Chronic Obstructive Pulmonary Disease (COPD)**:
               - Exposure to air pollutants accelerates lung function decline in people with COPD
               - May contribute to COPD development along with other factors like smoking
               - Acute exacerbations often correlate with high pollution days
            
            3. **Acute Respiratory Infections**:
               - Increased susceptibility to pneumonia, bronchitis, and other respiratory infections
               - Longer recovery time from respiratory infections
               - Potentially more severe symptoms
            
            4. **Lung Cancer**:
               - Fine particulate matter (PM2.5) and diesel exhaust are classified as carcinogenic to humans
               - Long-term exposure increases lung cancer risk, even in non-smokers
            
            5. **Interstitial Lung Disease**:
               - Some occupational and environmental exposures can lead to scarring of lung tissue
               - Conditions like pulmonary fibrosis have been linked to specific environmental exposures
            
            **Population-Specific Concerns in Coimbatore**:
            
            - Industrial workers in textile, foundry, and manufacturing sectors face occupational respiratory exposures
            - Traffic police and street vendors in high-traffic areas have increased exposure to vehicle emissions
            - Residents near industrial zones may experience higher rates of respiratory symptoms
            - Seasonal factors like pre-monsoon dust and post-harvest agricultural burning affect respiratory health
            """,
            
            'cardiovascular_effects': """
            Environmental pollution, particularly air pollution, has significant effects on cardiovascular health through various mechanisms.
            
            **How Environmental Pollution Affects the Cardiovascular System**:
            
            1. **Systemic Inflammation**: Pollutants trigger inflammatory responses that affect blood vessels throughout the body.
            
            2. **Oxidative Stress**: Free radicals damage blood vessels and heart tissue, contributing to atherosclerosis (hardening and narrowing of arteries).
            
            3. **Autonomic Nervous System Effects**: Pollutants can affect heart rate variability and vascular tone through impacts on the nervous system.
            
            4. **Blood Coagulation Changes**: Some pollutants increase blood clotting factors, raising the risk of dangerous clots.
            
            5. **Direct Translocation**: Ultrafine particles may directly enter the bloodstream and affect cardiovascular tissues.
            
            **Specific Cardiovascular Conditions Associated with Environmental Pollution**:
            
            1. **Hypertension (High Blood Pressure)**:
               - Both short-term spikes and long-term elevations in blood pressure are associated with air pollution exposure
               - Noise pollution is also linked to hypertension through stress pathways
               - Water contaminants like lead and arsenic contribute to blood pressure issues
            
            2. **Coronary Heart Disease**:
               - Long-term exposure to air pollution accelerates atherosclerosis
               - Risk of heart attacks increases during and shortly after pollution spikes
               - The risk is especially pronounced in vulnerable populations
            
            3. **Heart Failure**:
               - Pollution exposure can exacerbate existing heart failure
               - May contribute to development of heart failure through mechanisms affecting heart muscle function
            
            4. **Arrhythmias (Irregular Heartbeats)**:
               - Particulate matter exposure linked to increased arrhythmia risk
               - Pollution may affect heart electrical conduction
            
            5. **Stroke**:
               - Both ischemic (clot-based) and hemorrhagic (bleeding) stroke risks increase with pollution exposure
               - Even short-term exposure to elevated pollution levels increases stroke risk
            
            **Cardiovascular Risk in Coimbatore Context**:
            
            - Industrial workers exposed to metal fumes face increased cardiovascular risks
            - Areas with high traffic density (e.g., Gandhipuram, Avinashi Road) have elevated exposures
            - Combined effects of air pollution and noise along major transport corridors compound cardiovascular risks
            - Heat stress during summer months adds to cardiovascular strain, especially when combined with air pollution
            
            **Early Warning Signs**:
            
            - Unexplained fatigue
            - Chest discomfort or pressure
            - Irregular heartbeat
            - Shortness of breath
            - Swelling in the ankles or legs
            - Dizziness or lightheadedness
            """,
            
            'other_health_effects': """
            Beyond respiratory and cardiovascular systems, environmental pollution affects multiple body systems and functions:
            
            **Neurological Effects**:
            
            1. **Cognitive Function**:
               - Air pollution exposure linked to reduced cognitive performance
               - Long-term exposure associated with accelerated cognitive decline in older adults
               - Lead, mercury, and certain pesticides directly impact brain development and function
            
            2. **Neurodevelopmental Disorders**:
               - Prenatal and early childhood exposure to certain pollutants linked to:
                 - Attention deficit hyperactivity disorder (ADHD)
                 - Autism spectrum disorders
                 - Learning disabilities
                 - Behavioral problems
            
            3. **Neurodegenerative Diseases**:
               - Growing evidence connects air pollution exposure to increased risk of:
                 - Alzheimer's disease
                 - Parkinson's disease
                 - Other forms of dementia
               - The blood-brain barrier may be compromised by certain pollutants
            
            **Reproductive and Developmental Effects**:
            
            1. **Fertility Issues**:
               - Reduced sperm quality and count associated with various environmental exposures
               - Female fertility and menstrual cycle disruptions linked to certain chemicals
            
            2. **Pregnancy Complications**:
               - Increased risk of preterm birth
               - Low birth weight
               - Pregnancy-induced hypertension
               - Gestational diabetes
            
            3. **Developmental Effects**:
               - Endocrine-disrupting chemicals can affect physical development
               - Some pollutants affect organ formation during critical developmental windows
            
            **Metabolic and Endocrine Effects**:
            
            1. **Diabetes**:
               - Air pollution exposure linked to increased risk of type 2 diabetes
               - Some environmental chemicals affect insulin sensitivity
            
            2. **Obesity**:
               - Certain endocrine-disrupting chemicals may contribute to weight gain
               - Some pollutants classified as "obesogens" that affect fat metabolism
            
            3. **Thyroid Disorders**:
               - Several environmental contaminants can disrupt thyroid hormone function
               - Particularly concerning during pregnancy and early development
            
            **Immune System Effects**:
            
            1. **Autoimmune Disorders**:
               - Some environmental exposures linked to increased risk of conditions like:
                 - Rheumatoid arthritis
                 - Systemic lupus erythematosus
                 - Multiple sclerosis
            
            2. **Allergic Conditions**:
               - Air pollution can exacerbate allergic responses
               - May contribute to increased prevalence of allergies
            
            3. **Immunosuppression**:
               - Certain environmental toxins can suppress immune function
               - Increased susceptibility to infections
            
            **Renal (Kidney) Effects**:
            
            1. **Chronic Kidney Disease**:
               - Heavy metals and certain chemicals linked to kidney damage
               - Air pollution exposure associated with faster progression of kidney disease
            
            2. **Heat-Related Kidney Injury**:
               - Climate change and increased temperatures contribute to dehydration and kidney stress
               - Particularly relevant for outdoor workers in Coimbatore's hot months
            """,
            
            'preventive_measures': """
            ### Personal Protective Measures
            
            1. **Monitor Environmental Quality**:
               - Track local air quality indices through apps or websites
               - Be aware of water quality reports for your area
               - Pay attention to local environmental health advisories
            
            2. **Reduce Exposure During High-Risk Periods**:
               - Limit outdoor activities during high pollution days
               - Avoid exercising near busy roads or industrial areas
               - Schedule outdoor activities when pollution levels are lower (typically early morning)
            
            3. **Home Environment Optimization**:
               - Use air purifiers with HEPA filters
               - Ensure proper ventilation systems
               - Use quality water filtration appropriate for local contaminants
               - Reduce indoor sources of pollution (avoid synthetic air fresheners, minimize chemical cleaning products)
               - Maintain moderate humidity (40-60%) to reduce mold and dust mites
            
            4. **Diet and Nutrition**:
               - Maintain adequate hydration
               - Consume antioxidant-rich foods (fruits, vegetables, nuts, and seeds)
               - Consider anti-inflammatory foods (fatty fish, olive oil, turmeric)
               - Ensure adequate vitamin D, which may help counter some pollution effects
               - Include fiber-rich foods that may help eliminate toxins
            
            5. **Personal Protective Equipment**:
               - Use appropriate masks (N95 or better) when air quality is poor
               - Wear ear protection in noisy environments
               - Use gloves when handling potential toxins
            
            ### Medical and Health Monitoring
            
            1. **Regular Health Check-ups**:
               - Monitor cardiovascular and respiratory health metrics
               - Follow age-appropriate health screening guidelines
               - Inform your doctor about environmental exposures
            
            2. **Management of Existing Conditions**:
               - Ensure proper management of asthma, COPD, or heart conditions
               - Adjust medication regimens during high pollution periods (consult healthcare provider)
               - Have emergency medications readily available
            
            3. **Specialized Screening**:
               - Consider specialized screening if you have occupational exposures
               - Monitor children's development if there are concerns about exposures
               - Test for specific toxins if indicated by symptoms or exposure history
            
            ### Community and Policy Level Actions
            
            1. **Support Environmental Initiatives**:
               - Participate in community clean-up efforts
               - Support tree planting and urban greening
               - Advocate for clean energy and transportation
            
            2. **Reduce Your Environmental Footprint**:
               - Use public transportation, carpooling, or non-motorized transport when possible
               - Reduce energy consumption
               - Practice proper waste disposal and recycling
            
            3. **Stay Informed and Engaged**:
               - Learn about local environmental health issues
               - Participate in community environmental monitoring projects
               - Engage with local policy decisions affecting environmental health
            
            ### Special Considerations for Vulnerable Groups
            
            1. **Children**:
               - Create "clean air" spaces in homes and schools
               - Ensure adequate ventilation in schools
               - Limit play near busy roads or industrial areas
            
            2. **Elderly**:
               - Monitor for subtle changes in health status
               - Ensure adequate support during extreme weather or pollution events
               - Consider air quality when planning outdoor activities
            
            3. **Pregnant Women**:
               - Take extra precautions to limit exposure to environmental toxins
               - Ensure adequate nutrition to support detoxification
               - Discuss environmental concerns with healthcare providers
            """
        },
        
        'local_issues': {
            'industrial_pollution': """
            Coimbatore has a rich industrial heritage that contributes significantly to the city's economy but also presents environmental challenges:
            
            **Key Industrial Sectors and Their Environmental Impact**:
            
            1. **Textile Industry**:
               - One of Coimbatore's oldest and largest industrial sectors
               - Environmental impacts include:
                 - Water pollution from dyeing and processing units
                 - Air emissions from boilers and generators
                 - Chemical waste issues
               - Clusters in areas like SIDCO, Kurichi, and Ganapathy
            
            2. **Foundries and Engineering Units**:
               - Coimbatore is a major engineering hub with numerous foundries
               - Environmental concerns include:
                 - Particulate matter emissions
                 - Heavy metal contamination
                 - High energy consumption
               - Concentrated in areas like Peelamedu Industrial Area and Singanallur
            
            3. **Motor and Pump Manufacturing**:
               - Coimbatore is known as the "Pump City" of India
               - Environmental impacts include:
                 - Metal processing wastes
                 - Noise pollution
                 - Industrial effluents
            
            4. **Small and Medium Enterprises (SMEs)**:
               - Thousands of SMEs spread throughout the city
               - Often lack advanced pollution control systems
               - Cumulative impact is significant despite smaller individual footprints
            
            **Major Pollution Concerns**:
            
            1. **Air Pollution**:
               - Particulate matter from foundries and metal industries
               - VOCs (Volatile Organic Compounds) from painting and coating processes
               - Emissions from industrial boilers and generators
               - Areas like Kurichi, SIDCO, and Ganapathy industrial areas show higher pollution levels
            
            2. **Water Pollution**:
               - Contamination of water bodies like Noyyal River and Singanallur Lake
               - Industrial effluents containing dyes, heavy metals, and chemicals
               - Groundwater contamination in industrial clusters
               - Particularly concerning during low-flow periods before monsoon
            
            3. **Soil Contamination**:
               - Heavy metal accumulation in industrial areas
               - Improper waste disposal leading to soil quality degradation
               - Affects agricultural land in peri-urban areas
            
            **Regulatory Framework and Compliance**:
            
            1. **Tamil Nadu Pollution Control Board (TNPCB) Oversight**:
               - Regular monitoring of larger industries
               - Consent to Operate (CTO) requirements
               - Challenges in monitoring thousands of smaller units
            
            2. **Industrial Associations and Self-Regulation**:
               - Industry associations like CODISSIA promoting cleaner production
               - Voluntary adoption of environmental management systems
               - Varying levels of compliance across sectors and unit sizes
            
            3. **Common Effluent Treatment Plants (CETPs)**:
               - Several CETPs serving industrial clusters like Tirupur-Coimbatore region
               - Helping smaller units comply with effluent standards
               - Operational and maintenance challenges persist
            
            **Improvement Initiatives**:
            
            1. **Cleaner Production Technologies**:
               - Adoption of cleaner technologies in textile sector
               - Energy efficiency improvements in foundries
               - Waste heat recovery systems in larger industries
            
            2. **Zero Liquid Discharge (ZLD)**:
               - Implementation in textile and dyeing units
               - Challenges in cost and technology adoption by smaller units
            
            3. **Renewable Energy Adoption**:
               - Solar installations in industrial units
               - Wind energy investments by larger corporations
               - Focus on reducing carbon footprint
            """,
            
            'water_body_pollution': """
            Coimbatore's water bodies face significant pollution challenges that affect both environmental and public health:
            
            **Major Water Bodies and Their Status**:
            
            1. **Noyyal River**:
               - Once the lifeline of Coimbatore, now faces severe pollution
               - Key issues:
                 - Industrial effluent discharge, particularly from textile and dyeing units
                 - Untreated sewage from urban areas
                 - Solid waste dumping along the banks
                 - Encroachment reducing the river's flow and natural cleaning capacity
               - Most polluted stretches include areas downstream of industrial zones
               - Seasonal variations: pollution concentrates during dry seasons
            
            2. **Singanallur Lake**:
               - One of the largest lakes in the city's tank system
               - Current challenges:
                 - Eutrophication (excessive nutrients leading to algal blooms)
                 - Sewage inflow from surrounding residential areas
                 - Industrial contamination
                 - Invasive water hyacinth growth
               - Recent restoration efforts have shown some improvement
            
            3. **Ukkadam Lake (Periyakulam)**:
               - Major water body in southern Coimbatore
               - Facing issues of:
                 - Sewage contamination
                 - Solid waste disposal
                 - Encroachment
                 - Sedimentation and reduced water storage capacity
               - Recent restoration work through Smart Cities Mission
            
            4. **Valankulam Lake**:
               - Centrally located tank under restoration
               - Historical problems:
                 - Urban runoff carrying pollutants
                 - Direct sewage disposal
                 - Encroachment of tank bed
               - Currently part of a major restoration project
            
            5. **Krishnampathy, Selvampathy, and other tanks**:
               - Part of the interconnected tank system
               - Various levels of degradation and restoration efforts
               - Critical for groundwater recharge in their respective areas
            
            **Health and Environmental Impacts**:
            
            1. **Water-borne Diseases**:
               - Gastrointestinal illnesses reported in areas using contaminated water
               - Skin conditions from contact with polluted water
               - Vector-borne diseases (especially during monsoon) due to stagnant water conditions
            
            2. **Groundwater Contamination**:
               - Leaching of contaminants into groundwater
               - Wells near polluted water bodies showing elevated levels of:
                 - Nitrates
                 - Heavy metals in some industrial areas
                 - Total dissolved solids
                 - Bacterial contamination
            
            3. **Ecological Impacts**:
               - Loss of native aquatic biodiversity
               - Disruption of natural food chains
               - Decline in bird populations that depend on these water bodies
               - Loss of ecosystem services
            
            **Restoration Efforts and Challenges**:
            
            1. **Smart Cities Mission Interventions**:
               - Major restoration of eight lakes in Coimbatore
               - Development of eco-friendly recreational spaces
               - Desilting and deepening to increase storage capacity
               - Sewage diversion systems
            
            2. **Noyyal River Restoration**:
               - Court-mandated cleanup efforts
               - Stricter enforcement against industrial polluters
               - Removal of encroachments in certain stretches
               - Challenges remain in comprehensive restoration
            
            3. **Community Initiatives**:
               - NGOs like Siruthuli working on water body conservation
               - Citizen monitoring of water quality
               - Community awareness programs
               - Tree planting along water bodies
            
            4. **Ongoing Challenges**:
               - Inadequate sewage treatment capacity (only about 30% of city sewage receives proper treatment)
               - Continued illegal discharges, especially during nighttime
               - Jurisdictional overlaps between agencies
               - Urban development pressure on water body boundaries
            """,
            
            'traffic_pollution': """
            Traffic-related pollution is a growing concern in Coimbatore as the city experiences rapid urbanization and increasing vehicle numbers:
            
            **Current Traffic Situation**:
            
            1. **Vehicle Population Growth**:
               - Coimbatore has one of the highest vehicle densities in Tamil Nadu
               - Private vehicle ownership increasing at approximately 8-10% annually
               - Two-wheelers constitute about 75% of the total vehicle population
               - Car ownership rising rapidly with economic development
            
            2. **Traffic Congestion Hotspots**:
               - Gandhipuram area (especially near bus stands)
               - Avinashi Road corridor
               - Trichy Road junction
               - Ukkadam-Perur Road junction
               - R.S. Puram commercial streets
               - Singanallur junction
               - Saibaba Colony main roads
            
            3. **Road Infrastructure Challenges**:
               - Limited road width in many areas
               - Insufficient parking facilities leading to roadside parking
               - Incomplete ring road system
               - Mixed traffic (heavy vehicles, cars, two-wheelers, and non-motorized transport sharing roads)
            
            **Pollution Impacts from Traffic**:
            
            1. **Air Quality Issues**:
               - Primary traffic-related pollutants:
                 - Nitrogen oxides (NOx) - especially in congested corridors
                 - Particulate matter (PM10 and PM2.5) - higher near major junctions
                 - Carbon monoxide (CO) - elevated during peak traffic hours
                 - Volatile Organic Compounds (VOCs)
               - Studies show pollutant concentrations 2-3 times higher near major intersections
               - Diurnal patterns show peaks during morning (8-10 AM) and evening (5-8 PM) rush hours
            
            2. **Noise Pollution**:
               - Traffic noise exceeding 75-80 dB in major corridors
               - Honking contributing significantly to noise levels
               - Affects concentration and productivity in educational and office buildings along busy roads
               - Sleep disturbance for residents in buildings facing main roads
            
            3. **Health Impacts Observed**:
               - Higher respiratory complaint rates in clinics near traffic hotspots
               - Traffic police showing elevated levels of respiratory issues
               - School children in schools near busy roads reporting higher incidence of asthma symptoms
               - Street vendors with prolonged exposure reporting more frequent headaches and respiratory issues
            
            **Mitigation Efforts and Challenges**:
            
            1. **Public Transportation Initiatives**:
               - Bus system improvements
               - Proposed Bus Rapid Transit (BRT) corridors
               - Last-mile connectivity challenges
               - Limited mass rapid transit options
            
            2. **Traffic Management Measures**:
               - One-way systems in congested areas
               - Synchronization of traffic signals along major corridors
               - Restrictions on heavy vehicles during daytime in certain areas
               - Limited implementation of congestion pricing or vehicle restriction schemes
            
            3. **Vehicle Emission Controls**:
               - Emission testing requirements
               - Gradual transition to BS-VI vehicles
               - Initiatives to phase out older, more polluting vehicles
               - Challenges in enforcement of emission standards
            
            4. **Alternative Transportation Promotion**:
               - Dedicated cycling tracks in some areas (limited network)
               - Pedestrian infrastructure improvements
               - Electric vehicle incentives
               - Bike-sharing initiatives in early stages
            
            5. **Urban Planning Approaches**:
               - Transit-oriented development concepts in newer areas
               - Decentralization of commercial activities to reduce journey lengths
               - Mixed-use development encouragement
               - Challenges in retrofitting established areas
            """,
            
            'urban_development': """
            Coimbatore's rapid urbanization presents both challenges and opportunities for environmental quality and green spaces:
            
            **Urban Development Patterns**:
            
            1. **Recent Growth Trends**:
               - Expansion along major corridors (particularly Avinashi Road, Trichy Road, and Sathy Road)
               - Conversion of agricultural lands in peri-urban areas to residential and commercial use
               - Densification of existing urban areas
               - Development of satellite townships and gated communities
            
            2. **Land Use Changes**:
               - Reduction in agricultural land (approximately 30% decline in the last two decades)
               - Loss of wetlands and water catchment areas
               - Encroachment on water bodies and channels
               - Conversion of private gardens and open spaces to built structures
            
            3. **Building Typologies**:
               - Shift from traditional courtyard homes to apartment buildings
               - Increasing building heights in central areas
               - Spread of villa developments in peripheral areas
               - Reduced plot sizes and increased built-up area ratios
            
            **Green Space Status and Challenges**:
            
            1. **Existing Green Areas**:
               - Major parks: VOC Park, Nehru Stadium surroundings, Race Course area
               - Reserved forests in city periphery, particularly in western edges near Western Ghats
               - Institutional green spaces (PSG, Bharathiar University, TNAU campus)
               - Avenue trees along certain roads (Race Course Road, parts of Avinashi Road)
            
            2. **Green Cover Metrics**:
               - Green cover approximately 12-15% of city area (below the WHO recommendation of 20%)
               - Uneven distribution with western zones having better green coverage
               - Industrial and densely populated areas showing lowest green cover
               - Tree density declining in newly developing areas
            
            3. **Urban Heat Island Effect**:
               - Temperature difference of 3-5°C between city center and rural surroundings
               - Hot spots identified in Gandhipuram, Ukkadam, and industrial areas
               - Correlation between reduced vegetation and higher surface temperatures
               - Heat island intensity increasing annually with urbanization
            
            **Green Initiatives and Infrastructure**:
            
            1. **Smart Cities Mission Contributions**:
               - Lake restoration with green belts around eight major water bodies
               - Development of waterfront recreational spaces
               - Model road projects with improved landscaping
               - Parks and open space enhancement
            
            2. **Urban Forestry Efforts**:
               - Miyawaki forests in selected locations
               - Avenue tree planting programs
               - Community nurseries and tree distribution
               - Tree census and heritage tree protection initiatives
            
            3. **Green Building Practices**:
               - IGBC (Indian Green Building Council) certified projects increasing
               - Rainwater harvesting mandatory for new constructions
               - Solar rooftop installations in government buildings and new developments
               - Green campus initiatives in educational institutions
            
            4. **Green Infrastructure Developments**:
               - Permeable pavement pilots in some areas
               - Rain gardens in selected public spaces
               - Green roof demonstrations in institutional buildings
               - Bioswales and natural drainage system preservation efforts
            
            **Challenges and Opportunities**:
            
            1. **Policy and Governance**:
               - Multiple agencies with overlapping jurisdictions
               - Enforcement challenges in development control regulations
               - Need for integration of environmental considerations in planning
               - Opportunities through updated master planning processes
            
            2. **Community Engagement**:
               - Growing citizen awareness and activism
               - Resident welfare associations increasingly involved in greening
               - Corporate social responsibility projects focusing on environmental improvement
               - Youth engagement through educational institutions
            
            3. **Future Directions**:
               - Need for ecological corridors connecting fragmented green spaces
               - Integration of blue-green infrastructure
               - Climate-responsive urban design
               - Preservation of urban biodiversity
            """,
            
            'seasonal_variations': """
            Coimbatore experiences distinct seasonal patterns that influence environmental quality and related health concerns:
            
            **Major Seasons and Their Environmental Characteristics**:
            
            1. **Winter (December-February)**:
               - Relatively cool and dry conditions
               - Environmental Characteristics:
                 - Moderate to poor air quality due to temperature inversions trapping pollutants
                 - Reduced wind speeds limiting pollution dispersion
                 - Morning fog mixed with pollution (smog) in urban and industrial areas
                 - Lower water levels in lakes and rivers concentrating pollutants
               - Typical Environmental Health Issues:
                 - Increased respiratory complaints, especially morning cough
                 - Higher incidence of asthma exacerbation
                 - Eye irritation from particulate matter
            
            2. **Summer (March-May)**:
               - Hot and dry period with peak temperatures
               - Environmental Characteristics:
                 - Heat island effect most pronounced in urban areas
                 - Dust pollution peaks, especially from construction and road dust
                 - Water scarcity issues as surface water sources diminish
                 - Groundwater quality concerns as water tables lower
                 - Occasional pre-monsoon thunderstorms bringing temporary relief
               - Typical Environmental Health Issues:
                 - Heat-related illnesses (heat stress, dehydration)
                 - Waterborne diseases as water quality deteriorates
                 - Respiratory issues from increased dust
                 - Heightened vector breeding in remaining water sources
            
            3. **Southwest Monsoon (June-September)**:
               - Moderate rainfall period
               - Environmental Characteristics:
                 - Improved air quality as rain washes out pollutants
                 - Water bodies begin to recharge
                 - Potential urban flooding in low-lying areas
                 - Initial monsoon rains flush accumulated pollutants into water bodies
               - Typical Environmental Health Issues:
                 - Vector-borne diseases (dengue, malaria) increase
                 - Waterborne diseases from contaminated water due to runoff
                 - Mold and fungi growth leading to allergies
                 - Reduced heat-related illnesses
            
            4. **Northeast Monsoon (October-November)**:
               - Primary rainfall season for Coimbatore
               - Environmental Characteristics:
                 - Heaviest rainfall period
                 - Maximum recharge of lakes and groundwater
                 - Potential flooding in urban areas with poor drainage
                 - Noyyal River and other waterways at peak flow
               - Typical Environmental Health Issues:
                 - Peak in vector-borne diseases
                 - Contamination of drinking water sources from flood runoff
                 - Infections from contact with flood waters
                 - Habitat disruption increasing human-animal conflict (snakes, insects)
            
            **Seasonal Monitoring and Adaptation**:
            
            1. **Air Quality Patterns**:
               - PM2.5 and PM10 levels highest in winter and summer
               - Ozone concerns greatest during summer months
               - Pollen and biological allergens peak in specific seasons
               - Monitoring intensity increases during known poor air quality periods
            
            2. **Water Quality Variations**:
               - Pre-monsoon: Concentrated contaminants due to low water levels
               - Early monsoon: First flush effect with high pollutant loads
               - Peak monsoon: Dilution improving certain parameters but increasing turbidity
               - Post-monsoon: Gradual deterioration as water levels recede
            
            3. **Seasonal Health Advisories**:
               - Season-specific health guidelines issued by health department
               - Monsoon preparedness campaigns
               - Summer heat advisory and water conservation messaging
               - Winter air quality precautions
            
            **Climate Change Influences on Seasonal Patterns**:
            
            1. **Observed Changes**:
               - Increasing temperature extremes during summer
               - Greater rainfall intensity but potentially fewer rainy days
               - Less predictable monsoon onset and withdrawal
               - More frequent extreme weather events
            
            2. **Adaptation Measures**:
               - Improved early warning systems for extreme weather
               - Enhanced stormwater management infrastructure
               - Heat action plans for summer months
               - Vector control programs adapted to changing seasonal patterns
               - Water conservation and management systems accounting for greater variability
            """,
            
            'community_initiatives': """
            Coimbatore has a vibrant community-led environmental movement with several notable initiatives:
            
            **Key Environmental Organizations and Their Work**:
            
            1. **Siruthuli**:
               - Focus: Water conservation and management
               - Major Activities:
                 - Restoration of water bodies including Krishnampathy and Narasampathy tanks
                 - Groundwater recharge projects
                 - Tree plantation drives
                 - Environmental awareness campaigns
               - Impact: Significant contribution to water body restoration and public awareness
            
            2. **Residents Awareness Association of Coimbatore (RAAC)**:
               - Focus: Urban environmental issues and civic engagement
               - Major Activities:
                 - "Clean and Green Kovai" campaigns
                 - Waste management initiatives
                 - Advocacy for better urban infrastructure
                 - Pollution monitoring and reporting
               - Impact: Effective citizen-government interface for environmental issues
            
            3. **Osai**:
               - Focus: Wildlife and forest conservation
               - Major Activities:
                 - Conservation of Western Ghats ecosystems
                 - Wildlife protection initiatives
                 - Environmental education
                 - Anti-plastic campaigns
               - Impact: Crucial role in protecting biodiversity in and around Coimbatore
            
            4. **Coimbatore Vizha Environmental Initiatives**:
               - Focus: Community celebration incorporating environmental action
               - Major Activities:
                 - Annual lake clean-ups
                 - Tree plantation during festival weeks
                 - Environmental awareness through cultural events
               - Impact: Making environmental action part of cultural celebration
            
            **Citizen Science and Community Monitoring**:
            
            1. **Air Quality Monitoring Networks**:
               - Citizen-led air quality monitoring stations in multiple locations
               - Data sharing through mobile applications and social media
               - Correlation with health symptoms reported by community members
               - Advocacy based on collected data
            
            2. **Water Quality Watchdogs**:
               - Community testing of water bodies
               - Documentation of illegal dumping and discharges
               - River health monitoring by student groups
               - Collaborative work with academic institutions for analysis
            
            3. **Biodiversity Documentation**:
               - Birdwatching groups conducting regular counts
               - Tree census by volunteer groups
               - Urban wildlife documentation
               - Participation in national biodiversity documentation platforms
            
            **Grassroots Sustainability Initiatives**:
            
            1. **Urban Farming Movement**:
               - Terrace gardening networks
               - Community gardens in available urban spaces
               - Organic farming techniques exchange
               - Seed saving and native variety preservation
            
            2. **Waste Management Innovations**:
               - Community composting centers
               - Plastic collection and upcycling initiatives
               - Zero waste neighborhoods
               - Repair cafes and sharing economies
            
            3. **Alternative Transportation Promotion**:
               - Cycling advocacy groups
               - Cycling day events
               - Carpool networks
               - Walking infrastructure improvement campaigns
            
            **Educational Institutions as Environmental Leaders**:
            
            1. **School Environmental Programs**:
               - Eco-clubs and green campus initiatives
               - Environmental curriculum enrichment
               - School gardens and mini-forests
               - Interschool environmental competitions
            
            2. **College and University Contributions**:
               - Research on local environmental issues
               - Technical support for community initiatives
               - Campus sustainability models
               - Environmental volunteering programs
            
            3. **Vocational Training**:
               - Green skills development
               - Solar installation training
               - Organic farming techniques
               - Water conservation technologies
            """,
            
            'government_actions': """
            Government initiatives at various levels address environmental challenges in Coimbatore:
            
            **Municipal Corporation Initiatives**:
            
            1. **Coimbatore Smart City Projects**:
               - Lake Restoration Project covering 8 major lakes
                 - Ukkadam Periyakulam
                 - Valankulam
                 - Singanallur
                 - Selvampathy
                 - Kumaraswamy
                 - Selvachinthamani
                 - Krishnampathy
                 - Narasampathy
               - Key interventions include:
                 - Desilting and deepening
                 - Sewage diversion
                 - Bund strengthening
                 - Creation of walking tracks and green spaces
                 - Biodiversity enhancement
            
            2. **Solid Waste Management**:
               - Door-to-door segregated waste collection
               - Micro-composting centers in multiple zones
               - Material recovery facilities
               - Biomining of legacy waste at Vellalore dump
               - Plastic waste collection and recycling initiatives
            
            3. **Urban Greening**:
               - Avenue plantation along major roads
               - Park development and renovation
               - Miyawaki forests in selected locations
               - Green belt development around water bodies
            
            **Tamil Nadu Pollution Control Board Actions**:
            
            1. **Industrial Pollution Control**:
               - Regular monitoring of industrial emissions and effluents
               - Consent mechanism for industrial operations
               - Show-cause notices and closure orders for violating units
               - Support for cleaner production technologies
            
            2. **Monitoring Networks**:
               - Continuous Air Quality Monitoring Stations in strategic locations
               - Water quality monitoring in major water bodies
               - Noise monitoring during festivals and in industrial zones
               - Online continuous emission monitoring systems for larger industries
            
            3. **Special Initiatives**:
               - Eco-friendly Ganesh festival promotion
               - Noise pollution control during festivals and events
               - Environmental awareness campaigns
               - Industry-specific guidelines and standards
            
            **State Government Programs**:
            
            1. **Water Management**:
               - Noyyal River restoration plan
               - Check dam construction along seasonal streams
               - Tank rehabilitation program
               - Groundwater regulation in critical areas
            
            2. **Urban Transport**:
               - Bus fleet modernization with less polluting vehicles
               - Traffic management systems
               - Public transportation enhancement
               - Plans for organized city bus terminals
            
            3. **Energy Initiatives**:
               - Rooftop solar promotion
               - Energy efficiency in government buildings
               - LED street lighting conversion
               - Electric vehicle charging infrastructure
            
            **Policy and Regulatory Framework**:
            
            1. **Development Regulations**:
               - Mandatory rainwater harvesting
               - Open space preservation requirements
               - Environmental impact assessment for larger projects
               - Wetland and water body protection provisions
            
            2. **Emissions and Effluent Standards**:
               - Industry-specific pollution standards
               - BS-VI fuel quality standards implementation
               - Water quality criteria for different uses
               - Stricter monitoring and compliance requirements
            
            3. **Incentive Programs**:
               - Tax benefits for green building practices
               - Subsidies for renewable energy adoption
               - Recognition programs for environmental performance
               - Green procurement policies
            
            **Implementation Challenges**:
            
            1. **Coordination Issues**:
               - Multiple agencies with overlapping jurisdictions
               - Need for better inter-departmental coordination
               - Data sharing and integrated planning limitations
            
            2. **Enforcement Capacity**:
               - Limited personnel for monitoring and enforcement
               - Technical capacity gaps in smaller departments
               - Resource constraints for comprehensive monitoring
            
            3. **Public Participation**:
               - Variable levels of community engagement
               - Need for more structured feedback mechanisms
               - Transparency in environmental decision-making
            """
        }
    }
    
    return content.get(topic, {
        'message': 'Educational content for this topic is not available.'
    })

def get_environmental_health_faq():
    """
    Get frequently asked questions about environmental health
    
    Returns:
    - list: List of dictionaries containing questions and answers
    """
    faqs = [
        {
            "question": "How does the air quality in Coimbatore compare to other cities in Tamil Nadu?",
            "answer": """Coimbatore generally has better air quality than Chennai or other major industrial centers in Tamil Nadu, largely due to its geographical advantages with the Western Ghats nearby providing a natural air purification effect.

However, Coimbatore's air quality varies significantly by location. Industrial areas like SIDCO and traffic hotspots like Gandhipuram typically have AQI readings that can be 30-40% higher than residential areas in the western parts of the city.

According to recent CPCB data, Coimbatore's annual average PM2.5 levels (25-30 μg/m³) are lower than Chennai's (35-40 μg/m³) but still exceed WHO guidelines (5 μg/m³). Seasonal variations are significant, with air quality deteriorating during winter months and improving during the monsoon season.""",
            "source": "Central Pollution Control Board (CPCB) data and Tamil Nadu Pollution Control Board reports"
        },
        {
            "question": "What are the safest areas in Coimbatore in terms of environmental quality?",
            "answer": """The western and northwestern parts of Coimbatore generally have better environmental quality metrics:

1. **Race Course Area and Vadavalli**: These areas benefit from better urban planning, more green cover, and distance from industrial zones. They typically show lower air pollution levels and better groundwater quality.

2. **Areas Near Marudhamalai and Western Outskirts**: Proximity to the Western Ghats provides these areas with better air quality and more natural vegetation. The elevation also helps with air circulation.

3. **Saibaba Colony and R.S. Puram (Western Parts)**: Despite being relatively central, these areas have better tree cover and urban planning that helps maintain better environmental quality compared to eastern parts of the city.

Areas that typically face more environmental challenges include industrial clusters like Kurichi and SIDCO, and highly congested areas like parts of Gandhipuram, Ukkadam, and Singanallur where traffic pollution is significant.

It's important to note that environmental quality can vary within neighborhoods and is influenced by proximity to main roads, industrial facilities, and water bodies.""",
            "source": "Environmental quality assessments from TNPCB and community monitoring data"
        },
        {
            "question": "How can I check if my drinking water is safe?",
            "answer": """To check your drinking water safety in Coimbatore, you can:

1. **Get Professional Testing**:
   - Contact TWAD Board (Tamil Nadu Water Supply and Drainage Board) laboratory for comprehensive testing
   - Private laboratories like Tamil Nadu Test House offer water quality analysis
   - Some hospitals in Coimbatore provide basic water testing services
   - Costs typically range from ₹500-2000 depending on parameters tested

2. **Use Home Testing Kits**:
   - Basic TDS (Total Dissolved Solids) meters are available online (₹300-800)
   - Multi-parameter test kits can test for bacteria, pH, hardness, nitrates, and chlorine
   - Quick test strips for specific contaminants are available at some pharmacies

3. **Check for Visual and Sensory Signs**:
   - Cloudiness or turbidity
   - Unusual color, odor, or taste
   - Staining on fixtures (orange/brown stains suggest iron, blue/green stains indicate copper)
   - Soap scum and scale indicate hard water

4. **Key Parameters to Test in Coimbatore**:
   - TDS (high in eastern parts of Coimbatore)
   - Hardness (common throughout the city)
   - Fluoride (elevated in some areas)
   - Bacterial contamination (especially after monsoons)
   - Iron content (common in deeper borewells)

If your water comes from Siruvani or Pillur supply, it generally undergoes treatment before distribution, but building storage tanks can sometimes be sources of contamination.""",
            "source": "Tamil Nadu Water Supply and Drainage Board (TWAD Board) guidelines"
        },
        {
            "question": "What health symptoms might indicate that I'm affected by air pollution?",
            "answer": """Health symptoms that may indicate you're being affected by air pollution include:

**Short-term (Acute) Symptoms**:
- **Respiratory Irritation**: Coughing, throat irritation, congestion, sneezing
- **Eye Irritation**: Watery or itchy eyes, redness
- **Headaches**: Particularly frontal headaches that develop after outdoor exposure
- **Dizziness or Fatigue**: Unexplained tiredness or lightheadedness
- **Exacerbation of Existing Conditions**: Worsening of asthma, allergies, or COPD symptoms
- **Skin Irritation**: Rashes or irritation, especially on exposed areas

**Longer-term Indications**:
- **Pattern Recognition**: Symptoms that consistently appear when in certain areas or during high pollution days
- **Symptom Timing**: Problems that worsen during known pollution events or in high-traffic areas
- **Seasonal Patterns**: Symptoms that correlate with seasonal pollution patterns (like winter inversions)
- **Improvement When Away**: Noticeable improvement when you leave Coimbatore or stay in areas with better air quality

**When to Seek Medical Attention**:
- Shortness of breath or difficulty breathing
- Severe or persistent coughing
- Chest pain or tightness
- Symptoms that significantly interfere with daily activities
- Asthma attacks not responding to usual medication

A healthcare provider can help determine if air pollution is contributing to your symptoms and recommend appropriate measures. Consider keeping a symptom diary to identify patterns related to location, weather, and air quality.""",
            "source": "World Health Organization (WHO) and respiratory health guidelines"
        },
        {
            "question": "How effective are indoor plants at improving air quality?",
            "answer": """Indoor plants can contribute to improved indoor air quality, but their effectiveness has both benefits and limitations:

**Benefits of Indoor Plants**:

1. **Low-level Pollutant Removal**: Research has shown that certain plants can remove small amounts of air pollutants like formaldehyde, benzene, and trichloroethylene through their leaves and root systems.

2. **Particulate Matter Reduction**: Leaf surfaces can trap dust and particulate matter, helping to reduce these pollutants in indoor air.

3. **Humidity Regulation**: Plants release water vapor through transpiration, which can help maintain healthy humidity levels (especially beneficial in Coimbatore's dry seasons).

4. **Psychological Benefits**: The presence of plants reduces stress and improves mood, which can indirectly support overall health.

**Limitations and Realistic Expectations**:

1. **Scale Considerations**: Most studies showing significant air purification were conducted in small, sealed chambers. In a typical room, you would need a very large number of plants (10-20 per 100 sq. ft.) for measurable air quality improvement.

2. **Slow Process**: Plant-based filtration happens gradually and cannot quickly address acute pollution events or spikes.

3. **Not a Replacement**: Plants should complement, not replace, other air quality measures like ventilation, air purifiers with HEPA filters, and source control.

**Most Effective Plants for Coimbatore Conditions**:

- **Snake Plant (Sansevieria)**: Survives well in Coimbatore's climate, requires minimal water, releases oxygen at night
- **Areca Palm**: Effective at humidifying air, works well in Coimbatore's dry seasons
- **Money Plant (Epipremnum aureum)**: Easy to grow, helps remove formaldehyde
- **Peace Lily**: Good for removing various pollutants, though needs more attention to watering
- **Aloe Vera**: Thrives in Coimbatore's climate and helps monitor air quality (develops brown spots when air quality is poor)

For best results, use a variety of plants and combine them with proper ventilation and air filtration systems, especially during high pollution days.""",
            "source": "NASA Clean Air Study and subsequent research on phytoremediation"
        },
        {
            "question": "How does seasonal weather in Coimbatore affect environmental health risks?",
            "answer": """Seasonal weather patterns in Coimbatore significantly influence environmental health risks throughout the year:

**Winter (December-February)**:
- **Air Quality Impacts**: Temperature inversions trap pollutants near the ground, leading to higher concentrations of PM2.5 and other pollutants, especially in the morning hours.
- **Health Risks**: Increased respiratory issues, exacerbation of asthma and COPD, more frequent morning cough and irritation.
- **Protective Measures**: Limit early morning outdoor activities, use air purifiers indoors, keep medications accessible if you have respiratory conditions.

**Summer (March-May)**:
- **Air Quality Impacts**: Higher levels of dust, including road dust and construction dust. Ground-level ozone formation increases with strong sunlight.
- **Water Concerns**: Declining water levels concentrate contaminants in remaining water bodies. Groundwater quality may deteriorate.
- **Heat-Related Issues**: Heat stress, dehydration, and heat stroke risks, especially for outdoor workers and elderly.
- **Protective Measures**: Stay hydrated, limit midday sun exposure, use masks in dusty conditions, ensure water purification systems are maintained.

**Southwest Monsoon (June-September)**:
- **Air Quality Improvement**: Rainfall helps clear particulate matter from the air, generally improving air quality.
- **Water Concerns**: First flush effect carries accumulated pollutants into water bodies. Potential for waterborne diseases increases.
- **Vector-Borne Diseases**: Mosquito breeding increases, raising dengue and malaria risks.
- **Protective Measures**: Ensure proper water treatment before consumption, prevent water stagnation around homes, use mosquito protection measures.

**Northeast Monsoon (October-November)**:
- **Flooding Risks**: Heavier rainfall can cause local flooding and contamination of water sources.
- **Waterborne Disease Peak**: Highest risk period for gastrointestinal illnesses from contaminated water.
- **Mold and Fungi**: Increased humidity promotes mold growth, affecting respiratory health.
- **Protective Measures**: Avoid wading through floodwater, ensure drinking water safety, address any moisture or mold issues promptly.

**Year-Round Considerations**:
- Pollution levels typically peak in morning and evening rush hours regardless of season
- Western parts of Coimbatore generally experience better air quality than eastern parts across seasons
- Individuals with pre-existing health conditions should adjust their medication and outdoor activity plans seasonally
- Indoor air quality protection becomes more important during pollution-prone seasons""",
            "source": "Tamil Nadu Meteorological Department and health department seasonal advisories"
        },
        {
            "question": "What are the environmental health risks specific to children in Coimbatore?",
            "answer": """Children in Coimbatore face several specific environmental health risks:

**Air Pollution Concerns**:
- **Respiratory Development**: Children's lungs continue developing through adolescence, making them vulnerable to permanent damage from air pollutants.
- **Higher Exposure**: Children breathe more air per body weight than adults and typically spend more time outdoors, especially in school playgrounds that may be near busy roads.
- **School Locations**: Several schools in Coimbatore are located on or near high-traffic roads (like Avinashi Road, Trichy Road), exposing children to vehicle emissions during critical developmental periods.
- **Local Factor**: Children in eastern parts of Coimbatore and near industrial areas face higher exposure risks.

**Water Quality Issues**:
- **Greater Susceptibility**: Children absorb a higher percentage of water contaminants relative to their body weight.
- **Specific Contaminants**: Fluoride (elevated in some groundwater sources in Coimbatore) and nitrates can particularly affect children's development.
- **School Water Systems**: Variable quality of drinking water in schools, with some depending on inadequately maintained water systems.
- **Local Factor**: Schools or homes using untreated borewell water in certain areas may expose children to contamination.

**Noise Pollution**:
- **Cognitive Development**: Chronic noise exposure from traffic and industrial sources can impair learning, reading acquisition, and concentration.
- **School Performance**: Studies show lower academic performance in schools located in noisy areas.
- **Local Factor**: Schools near Peelamedu industrial area, Gandhipuram bus stands, or railway lines face higher noise levels.

**Other Environmental Concerns**:
- **Lead Exposure**: Can come from older paints, certain industries, and contaminated soils near industrial areas.
- **Pesticide Exposure**: Residences near agricultural areas in peri-urban Coimbatore may have pesticide drift concerns.
- **Inadequate Sanitation**: Some areas still have sanitation gaps that particularly impact children's health.
- **Heat Exposure**: Increasing heat events affect children's ability to play outdoors and participate in physical activities.

**Protective Measures for Families in Coimbatore**:
- Consider air quality when selecting schools and residential locations
- Ensure children have access to safe drinking water, using appropriate purification methods
- Create green barriers (plants, trees) between busy roads and living/playing areas
- Advocate for vehicle-free zones around schools during drop-off and pick-up times
- Support school-based environmental health monitoring and improvement initiatives""",
            "source": "WHO Children's Environmental Health guidelines and local pediatric health reports"
        },
        {
            "question": "How can I make my home more environmentally healthy in Coimbatore's climate?",
            "answer": """Creating an environmentally healthy home in Coimbatore's climate involves addressing several aspects specific to local conditions:

**Air Quality Optimization**:

1. **Ventilation Strategies**:
   - Cross-ventilation design works well in Coimbatore's generally moderate climate
   - Open windows during early morning hours when air quality is typically better
   - Consider window placement to maximize natural airflow
   - Install exhaust fans in kitchens to remove cooking fumes

2. **Plant Barriers and Greenery**:
   - Plant trees or shrubs as buffers if you're near busy roads (neem trees are particularly effective)
   - Use indoor plants that thrive in Coimbatore's climate (snake plant, areca palm, money plant)
   - Consider vertical gardens on balconies facing roads

3. **Indoor Air Quality**:
   - Use air purifiers with HEPA filters, especially in bedrooms
   - Opt for low-VOC paints when renovating
   - Minimize synthetic air fresheners and incense
   - Keep shoes outside to prevent tracking in dust and pollutants
   - Regular dusting with damp cloths rather than dry dusting

**Water Quality and Management**:

1. **Purification Systems**:
   - Multi-stage filtration recommended for most areas
   - RO systems for areas with high TDS (common in eastern Coimbatore)
   - Regular maintenance of filters and tanks
   - Consider second-stage mineralization if using RO as Coimbatore water is generally hard

2. **Rainwater Harvesting**:
   - Implement efficient rainwater harvesting systems (mandatory for new constructions)
   - Regular maintenance of collection surfaces and filters
   - Separate storage for landscape irrigation and potential indoor use

3. **Storage Practices**:
   - Clean overhead tanks quarterly
   - Use food-grade plastic or stainless steel storage containers
   - Keep storage containers covered to prevent mosquito breeding

**Energy Efficiency for Local Climate**:

1. **Cooling Strategies**:
   - White or reflective roof coatings to reduce heat absorption
   - Ceiling fans installed in all rooms to reduce air conditioner usage
   - External shading for west-facing windows (particularly important in Coimbatore)
   - Consider solar reflective films for windows with direct sun exposure

2. **Renewable Energy**:
   - Rooftop solar has excellent potential given Coimbatore's 300+ sunny days
   - Solar water heaters are particularly cost-effective
   - Battery storage solutions for power backup instead of diesel generators

**Health-Promoting Design Elements**:

1. **Natural Light Optimization**:
   - Maximize north and east light exposure
   - Consider light shelves to bring daylight deeper into rooms
   - Use light-colored interiors to reflect natural light

2. **Noise Management**:
   - Double-glazed windows if you're near main roads
   - Strategic placement of bookshelves on walls facing noise sources
   - Acoustic ceiling treatments in bedrooms if noise is an issue
   - Soft furnishings to absorb sound

3. **Non-toxic Materials**:
   - Traditional flooring options like Athangudi tiles or natural stone
   - Avoid carpeting that can harbor dust and allergens
   - Natural wood furniture with non-toxic finishes
   - Bamboo or other sustainable materials for cabinetry""",
            "source": "Indian Green Building Council recommendations and local architectural practices"
        },
        {
            "question": "What are the most effective air purifiers for Coimbatore's specific pollution profile?",
            "answer": """For Coimbatore's specific pollution profile, which includes industrial particulates, road dust, vehicle emissions, and seasonal pollen, the most effective air purifiers should address these particular challenges:

**Key Technologies Required for Coimbatore Conditions**:

1. **HEPA Filtration**: Essential for removing the fine particulate matter (PM2.5) that comes from vehicular emissions and industrial sources common in areas like SIDCO, Kurichi, and major traffic corridors.

2. **Activated Carbon Filters**: Important for addressing gaseous pollutants from industrial emissions and vehicle exhaust, which are concerns in specific parts of Coimbatore.

3. **Pre-filters**: Necessary for capturing larger dust particles, which are abundant during Coimbatore's dry seasons and in areas with construction activity.

4. **Adequate CADR Rating**: For Coimbatore's conditions, look for Clean Air Delivery Rate appropriate for your room size, with slightly higher capacity recommended for homes near industrial zones or main roads.

**Considerations Specific to Coimbatore**:

1. **Humidity Management**: During monsoon seasons, purifiers with dehumidification capabilities or that work effectively in humid conditions are beneficial to prevent mold growth.

2. **Energy Efficiency**: Given Coimbatore's electricity tariff structure, energy-efficient models with low power consumption in continuous operation are economical in the long run.

3. **Noise Levels**: Important in residential areas near already-noisy industrial zones or main roads (like Avinashi Road or Trichy Road).

4. **Filter Replacement Availability**: Ensure replacement filters are readily available in Coimbatore or can be easily ordered online.

**Recommended Features Based on Location in Coimbatore**:

- **For homes near industrial areas** (SIDCO, Kurichi, Ganapathy industrial zone): Prioritize high-efficiency particulate and gas filtration with higher CADR ratings
- **For homes near major roads**: Focus on HEPA and activated carbon for vehicle emissions
- **For western residential areas** (Race Course, Vadavalli): Standard HEPA filtration is usually sufficient
- **For areas near construction**: Ensure effective pre-filtration systems

**Maintenance Considerations for Local Conditions**:

- More frequent filter changes may be needed during winter months when pollution levels are higher
- Pre-filters may require cleaning every 2-4 weeks in dustier eastern parts of the city
- Professional servicing is available at appliance service centers in R.S. Puram, Gandhipuram, and other commercial areas""",
            "source": "Air quality specialist recommendations based on Coimbatore's pollution profile"
        },
        {
            "question": "What local foods or dietary practices might help counter the effects of environmental pollution?",
            "answer": """Local foods and dietary practices in the Coimbatore region can help counter some effects of environmental pollution through their antioxidant, anti-inflammatory, and detoxifying properties:

**Local Produce with Protective Benefits**:

1. **Greens Abundant in Coimbatore Markets**:
   - **Moringa (Drumstick) Leaves**: Exceptionally high in antioxidants and anti-inflammatory compounds; grown extensively around Coimbatore
   - **Arai Keerai (Amaranth)**: Rich in iron and antioxidants that help combat oxidative stress from pollution
   - **Thoodhuvalai (Solanum trilobatum)**: Traditional Tamil Nadu green known for respiratory benefits
   - **Sirupulai Keerai**: Local green with detoxifying properties

2. **Locally Grown Fruits**:
   - **Amla (Indian Gooseberry)**: Extremely high vitamin C content helps boost immunity and counter oxidative stress
   - **Wood Apple (Vilampalam)**: Contains antioxidants and supports digestive health
   - **Guava**: High in vitamin C and available fresh in Coimbatore's markets
   - **Pomegranate**: Anti-inflammatory properties and grown in surrounding districts

3. **Local Spices with Protective Effects**:
   - **Turmeric**: Powerful anti-inflammatory curcumin compound; widely grown in Tamil Nadu
   - **Black Pepper**: Enhances bioavailability of turmeric and has its own antioxidant properties
   - **Ginger**: Supports respiratory health and reduces inflammation
   - **Garlic**: Contains allicin which has detoxifying properties

**Traditional Preparations with Health Benefits**:

1. **Respiratory Support**:
   - **Tulsi (Holy Basil) Tea**: Helps protect against respiratory effects of air pollution
   - **Chukku Kaapi (Dry Ginger Coffee)**: Traditional preparation supporting respiratory health
   - **Pepper Rasam**: Helps clear respiratory passages and provides antioxidants

2. **Detoxification Supports**:
   - **Neer Moru (Spiced Buttermilk)**: Aids digestion and contains probiotics
   - **Karisalankanni Keerai dishes**: Traditional green known for liver support
   - **Brahmi-based preparations**: Supports neurological health against pollution effects

3. **Anti-inflammatory Preparations**:
   - **Sambar with Moringa leaves**: Combines multiple anti-inflammatory ingredients
   - **Turmeric Milk (Manjal Paal)**: Traditional anti-inflammatory beverage
   - **Milagu Jeeraga Kashayam**: Pepper and cumin preparation with anti-inflammatory effects

**Practical Dietary Recommendations**:

1. **Local Food Sources in Coimbatore**:
   - Farmers' markets at R.S. Puram and Singanallur offer freshest local produce
   - Organic outlets specializing in traditional grains and greens
   - Community-supported agriculture initiatives connecting to farms in the Nilgiris and surrounding areas

2. **Daily Practices**:
   - Include a diversity of differently colored fruits and vegetables
   - Incorporate traditional greens in at least one meal daily
   - Use local spices liberally in cooking
   - Stay adequately hydrated with clean water
   - Consider seasonal eating aligned with traditional Tamil practices

3. **Specific Recommendations for Pollution Exposure**:
   - Increase antioxidant intake during high pollution seasons (winter months)
   - Emphasize respiratory-supporting foods when air quality deteriorates
   - Consider liver-supporting foods if living near industrial areas""",
            "source": "Traditional Tamil Nadu dietary practices and nutritional research"
        },
        {
            "question": "How do I interpret the Air Quality Index (AQI) readings for Coimbatore?",
            "answer": """Interpreting Air Quality Index (AQI) readings for Coimbatore requires understanding both the standard AQI categories and local context:

**AQI Categories and Their Meaning**:

| AQI Range | Category | Health Implications for Coimbatore Context |
|-----------|----------|-------------------------------------------|
| 0-50 | Good | Air quality is satisfactory. Enjoy outdoor activities across Coimbatore, including in parks like VOC Park and Botanical Gardens. |
| 51-100 | Moderate | Acceptable air quality, but unusually sensitive individuals should consider limiting prolonged outdoor exertion in busier areas like Gandhipuram and Peelamedu. |
| 101-150 | Unhealthy for Sensitive Groups | Members of sensitive groups (children, elderly, those with respiratory or heart conditions) may experience health effects, especially near industrial zones like SIDCO or busy corridors like Avinashi Road. |
| 151-200 | Unhealthy | General public may experience health effects. Sensitive groups should limit outdoor exposure, particularly in eastern industrial parts of Coimbatore. |
| 201-300 | Very Unhealthy | Health alert: everyone may experience more serious health effects. Limit all outdoor activities, use masks outdoors, and consider air purifiers indoors. |
| 301+ | Hazardous | Health emergency conditions. Everyone should avoid all outdoor physical activity. |

**Coimbatore-Specific Interpretation Factors**:

1. **Spatial Variation**: AQI can vary significantly across Coimbatore:
   - Western areas (Race Course, Vadavalli) typically have 15-25% better AQI than eastern industrial areas
   - Readings from central monitoring stations may not reflect conditions in your specific neighborhood
   - Areas near Western Ghats generally have better air quality

2. **Temporal Patterns**:
   - Early morning (6-8 AM): Often sees elevated pollution due to temperature inversions
   - Midday: Usually sees improved AQI as atmospheric mixing increases
   - Evening rush hour (5-8 PM): Typically shows second daily peak in pollution
   - These patterns are more pronounced during winter months

3. **Seasonal Considerations**:
   - Winter (Dec-Feb): AQI readings typically 20-30% worse than annual average
   - Summer (Mar-May): Dust contribution increases
   - Monsoon (Jun-Nov): Generally better AQI due to rain washing out pollutants

**How to Access Reliable AQI Data for Coimbatore**:

1. **Official Sources**:
   - Central Pollution Control Board's SAMEER app
   - Tamil Nadu Pollution Control Board website
   - National Air Quality Index portal

2. **Additional Resources**:
   - Private monitoring networks like AirVisual and PurpleAir
   - Local community monitoring initiatives in select neighborhoods

**Tailoring Your Response to Coimbatore AQI Levels**:

1. **Moderate AQI (51-100)** - Common in Coimbatore:
   - Generally safe for most activities
   - Sensitive individuals might limit prolonged exertion near busy roads
   - Good time for outdoor activities in parks and less congested areas

2. **Unhealthy for Sensitive Groups (101-150)** - Occurs in specific areas and seasons:
   - Plan outdoor activities in western parts of city rather than industrial east
   - Avoid rush hour outdoor exercise
   - Consider indoor air purification if you're in a sensitive group""",
            "source": "Central Pollution Control Board AQI guidelines and local air quality monitoring data"
        }
    ]
    
    return faqs

