import numpy as np
import pandas as pd
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def calculate_health_risk(air_data, water_data, noise_data):
    """
    Calculate health risk scores based on environmental data
    
    Parameters:
    - air_data (dict): Air quality data including AQI and pollutant levels
    - water_data (dict): Water quality data
    - noise_data (dict): Noise pollution data
    
    Returns:
    - dict: Health risk assessment including risk scores and recommendations
    """
    try:
        # Extract relevant metrics
        aqi = air_data.get('aqi', 50) if air_data else 50
        pm25 = air_data.get('pm25', 10) if air_data else 10
        pm10 = air_data.get('pm10', 20) if air_data else 20
        
        wqi = water_data.get('wqi', 80) if water_data else 80
        
        noise_level = noise_data.get('decibel', 50) if noise_data else 50
        
        # Calculate respiratory health risk (primarily influenced by air quality)
        respiratory_risk = calculate_respiratory_risk(aqi, pm25, pm10)
        
        # Calculate cardiovascular health risk
        cardiovascular_risk = calculate_cardiovascular_risk(aqi, pm25, pm10, noise_level)
        
        # Calculate overall health index (scale 0-10, 10 being best)
        air_factor = 0.5  # Air quality has 50% weight
        water_factor = 0.3  # Water quality has 30% weight
        noise_factor = 0.2  # Noise has 20% weight
        
        # Convert to 0-10 scale where 10 is best
        air_score = max(0, 10 - (aqi / 50))
        water_score = wqi / 10  # Assuming WQI is 0-100
        noise_score = max(0, 10 - (noise_level / 10))
        
        overall_health_index = round((air_score * air_factor) + 
                                    (water_score * water_factor) + 
                                    (noise_score * noise_factor), 1)
        
        # Generate recommendations based on risk factors
        recommendations = generate_recommendations(aqi, wqi, noise_level, respiratory_risk, cardiovascular_risk)
        
        # Generate risk messages
        respiratory_message = get_risk_message("respiratory", respiratory_risk)
        cardiovascular_message = get_risk_message("cardiovascular", cardiovascular_risk)
        overall_message = get_overall_health_message(overall_health_index)
        
        return {
            'respiratory_risk': respiratory_risk,
            'cardiovascular_risk': cardiovascular_risk,
            'overall_health_index': overall_health_index,
            'recommendations': recommendations,
            'respiratory_message': respiratory_message,
            'cardiovascular_message': cardiovascular_message,
            'overall_message': overall_message
        }
    
    except Exception as e:
        logger.error(f"Error calculating health risk: {str(e)}")
        return {
            'error': str(e),
            'status': 'error',
            'respiratory_risk': 10,
            'cardiovascular_risk': 10,
            'overall_health_index': 5,
            'recommendations': ["Unable to calculate precise recommendations due to error."],
            'respiratory_message': "Error in risk calculation",
            'cardiovascular_message': "Error in risk calculation",
            'overall_message': "Error in overall health assessment"
        }

def calculate_respiratory_risk(aqi, pm25, pm10):
    """Calculate respiratory health risk on a scale of 0-100"""
    # Base risk on AQI
    if aqi < 50:  # Good
        base_risk = 10
    elif aqi < 100:  # Moderate
        base_risk = 25
    elif aqi < 150:  # Unhealthy for sensitive groups
        base_risk = 40
    elif aqi < 200:  # Unhealthy
        base_risk = 60
    elif aqi < 300:  # Very unhealthy
        base_risk = 80
    else:  # Hazardous
        base_risk = 95
    
    # Adjust based on PM2.5 and PM10 levels
    pm_factor = 0
    if pm25 > 35:  # Unhealthy PM2.5 levels
        pm_factor += 10
    if pm10 > 150:  # Unhealthy PM10 levels
        pm_factor += 10
    
    # Final risk (capped at 100)
    return min(100, base_risk + pm_factor)

def calculate_cardiovascular_risk(aqi, pm25, pm10, noise_level):
    """Calculate cardiovascular health risk on a scale of 0-100"""
    # Base risk on AQI
    if aqi < 50:  # Good
        base_risk = 5
    elif aqi < 100:  # Moderate
        base_risk = 20
    elif aqi < 150:  # Unhealthy for sensitive groups
        base_risk = 35
    elif aqi < 200:  # Unhealthy
        base_risk = 50
    elif aqi < 300:  # Very unhealthy
        base_risk = 70
    else:  # Hazardous
        base_risk = 85
    
    # Adjust based on PM2.5 (particularly relevant for cardiovascular health)
    pm_factor = 0
    if pm25 > 25:
        pm_factor += 15
    
    # Adjust based on noise levels (chronic exposure to loud noise affects cardiovascular health)
    noise_factor = 0
    if noise_level > 60:  # Moderate noise
        noise_factor += 5
    if noise_level > 70:  # Loud noise
        noise_factor += 5
    if noise_level > 80:  # Very loud noise
        noise_factor += 10
    
    # Final risk (capped at 100)
    return min(100, base_risk + pm_factor + noise_factor)

def generate_recommendations(aqi, wqi, noise_level, respiratory_risk, cardiovascular_risk):
    """Generate health recommendations based on environmental data and risk levels"""
    recommendations = []
    
    # Air quality recommendations
    if aqi < 50:
        recommendations.append("Air quality is good. Enjoy outdoor activities.")
    elif aqi < 100:
        recommendations.append("Air quality is moderate. Unusually sensitive people should consider reducing prolonged outdoor exertion.")
    elif aqi < 150:
        recommendations.append("Air quality is unhealthy for sensitive groups. People with respiratory or heart conditions, the elderly and children should limit prolonged outdoor exertion.")
    elif aqi < 200:
        recommendations.append("Air quality is unhealthy. Everyone should reduce prolonged outdoor exertion. Sensitive groups should avoid outdoor activities.")
    elif aqi < 300:
        recommendations.append("Air quality is very unhealthy. Everyone should avoid prolonged outdoor exertion. Consider using an air purifier indoors.")
    else:
        recommendations.append("Air quality is hazardous. Everyone should avoid outdoor activities. Use air purifiers indoors and wear masks when outdoors.")
    
    # Water quality recommendations
    if wqi > 90:
        recommendations.append("Water quality is excellent for drinking with proper treatment.")
    elif wqi > 70:
        recommendations.append("Water quality is good but ensure proper filtration before drinking.")
    elif wqi > 50:
        recommendations.append("Water quality is moderate. Use good quality water purifiers.")
    else:
        recommendations.append("Water quality is poor. Use advanced water purification systems and consider testing your drinking water.")
    
    # Noise recommendations
    if noise_level < 50:
        recommendations.append("Noise levels are comfortable.")
    elif noise_level < 70:
        recommendations.append("Moderate noise levels. No immediate health concerns.")
    elif noise_level < 85:
        recommendations.append("High noise levels may cause stress with prolonged exposure. Consider using noise-cancelling headphones in very noisy areas.")
    else:
        recommendations.append("Very high noise levels. Prolonged exposure may damage hearing and increase stress. Use ear protection in noisy environments.")
    
    # Specific health risk recommendations
    if respiratory_risk > 70:
        recommendations.append("Your location has high respiratory health risks. If you have respiratory conditions, consult your doctor about additional precautions.")
    
    if cardiovascular_risk > 70:
        recommendations.append("Your location has high cardiovascular health risks. If you have heart conditions, consult your doctor about additional precautions.")
    
    return recommendations

def get_risk_message(risk_type, risk_score):
    """Generate a human-readable message based on the risk type and score"""
    if risk_type == "respiratory":
        if risk_score < 20:
            return "Very low risk to respiratory health"
        elif risk_score < 40:
            return "Low risk to respiratory health"
        elif risk_score < 60:
            return "Moderate risk to respiratory health"
        elif risk_score < 80:
            return "High risk to respiratory health"
        else:
            return "Very high risk to respiratory health"
    
    elif risk_type == "cardiovascular":
        if risk_score < 20:
            return "Very low risk to cardiovascular health"
        elif risk_score < 40:
            return "Low risk to cardiovascular health"
        elif risk_score < 60:
            return "Moderate risk to cardiovascular health"
        elif risk_score < 80:
            return "High risk to cardiovascular health"
        else:
            return "Very high risk to cardiovascular health"
    
    return "Unknown risk category"

def get_overall_health_message(health_index):
    """Generate a message based on the overall health index"""
    if health_index >= 8.5:
        return "Excellent environmental health conditions"
    elif health_index >= 7:
        return "Good environmental health conditions"
    elif health_index >= 5.5:
        return "Moderate environmental health conditions"
    elif health_index >= 4:
        return "Poor environmental health conditions"
    else:
        return "Very poor environmental health conditions"
