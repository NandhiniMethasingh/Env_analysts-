import pandas as pd
import numpy as np
import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def process_air_quality_data(air_data):
    """
    Process and normalize raw air quality data
    
    Parameters:
    - air_data (dict): Raw air quality data from the API
    
    Returns:
    - dict: Processed air quality data with normalized values and categories
    """
    if not air_data or 'error' in air_data:
        logger.warning("No air quality data to process or error in data")
        return None
    
    try:
        processed_data = {}
        
        # Copy original metrics
        processed_data['aqi'] = air_data.get('aqi')
        processed_data['pm25'] = air_data.get('pm25')
        processed_data['pm10'] = air_data.get('pm10')
        processed_data['so2'] = air_data.get('so2')
        processed_data['no2'] = air_data.get('no2')
        processed_data['co'] = air_data.get('co')
        processed_data['o3'] = air_data.get('o3')
        processed_data['timestamp'] = air_data.get('timestamp')
        processed_data['source'] = air_data.get('source')
        
        # Add AQI category
        aqi = processed_data['aqi']
        if aqi is not None:
            if aqi <= 50:
                processed_data['aqi_category'] = 'Good'
                processed_data['aqi_color'] = '#00E400'  # Green
            elif aqi <= 100:
                processed_data['aqi_category'] = 'Moderate'
                processed_data['aqi_color'] = '#FFFF00'  # Yellow
            elif aqi <= 150:
                processed_data['aqi_category'] = 'Unhealthy for Sensitive Groups'
                processed_data['aqi_color'] = '#FF7E00'  # Orange
            elif aqi <= 200:
                processed_data['aqi_category'] = 'Unhealthy'
                processed_data['aqi_color'] = '#FF0000'  # Red
            elif aqi <= 300:
                processed_data['aqi_category'] = 'Very Unhealthy'
                processed_data['aqi_color'] = '#99004C'  # Purple
            else:
                processed_data['aqi_category'] = 'Hazardous'
                processed_data['aqi_color'] = '#7E0023'  # Maroon
        
        return processed_data
    
    except Exception as e:
        logger.error(f"Error processing air quality data: {str(e)}")
        return None

def process_water_quality_data(water_data):
    """
    Process and normalize raw water quality data
    
    Parameters:
    - water_data (dict): Raw water quality data from the API
    
    Returns:
    - dict: Processed water quality data with normalized values and categories
    """
    if not water_data or 'error' in water_data:
        logger.warning("No water quality data to process or error in data")
        return None
    
    try:
        processed_data = {}
        
        # Copy original metrics
        processed_data['ph'] = water_data.get('ph')
        processed_data['do'] = water_data.get('do')  # Dissolved Oxygen
        processed_data['bod'] = water_data.get('bod')  # Biochemical Oxygen Demand
        processed_data['cod'] = water_data.get('cod')  # Chemical Oxygen Demand
        processed_data['tds'] = water_data.get('tds')  # Total Dissolved Solids
        processed_data['turbidity'] = water_data.get('turbidity')
        processed_data['wqi'] = water_data.get('wqi')  # Water Quality Index
        processed_data['timestamp'] = water_data.get('timestamp')
        processed_data['source'] = water_data.get('source')
        
        # Add WQI category
        wqi = processed_data.get('wqi')
        if wqi is not None:
            if wqi >= 95:
                processed_data['wqi_category'] = 'Excellent'
                processed_data['wqi_color'] = '#00E400'  # Green
            elif wqi >= 80:
                processed_data['wqi_category'] = 'Good'
                processed_data['wqi_color'] = '#AAFF00'  # Light Green
            elif wqi >= 65:
                processed_data['wqi_category'] = 'Fair'
                processed_data['wqi_color'] = '#FFFF00'  # Yellow
            elif wqi >= 45:
                processed_data['wqi_category'] = 'Marginal'
                processed_data['wqi_color'] = '#FF7E00'  # Orange
            else:
                processed_data['wqi_category'] = 'Poor'
                processed_data['wqi_color'] = '#FF0000'  # Red
        
        # Add pH category
        ph = processed_data.get('ph')
        if ph is not None:
            if 6.5 <= ph <= 8.5:
                processed_data['ph_category'] = 'Normal'
            elif 6.0 <= ph < 6.5 or 8.5 < ph <= 9.0:
                processed_data['ph_category'] = 'Slightly Abnormal'
            else:
                processed_data['ph_category'] = 'Abnormal'
        
        return processed_data
    
    except Exception as e:
        logger.error(f"Error processing water quality data: {str(e)}")
        return None

def process_noise_data(noise_data):
    """
    Process and categorize raw noise level data
    
    Parameters:
    - noise_data (dict): Raw noise data
    
    Returns:
    - dict: Processed noise data with categories and health impact info
    """
    if not noise_data or 'error' in noise_data:
        logger.warning("No noise data to process or error in data")
        return None
    
    try:
        processed_data = {}
        
        # Copy original metrics
        processed_data['decibel'] = noise_data.get('decibel')
        processed_data['timestamp'] = noise_data.get('timestamp')
        processed_data['source'] = noise_data.get('source')
        
        # Add noise level category
        decibel = processed_data.get('decibel')
        if decibel is not None:
            if decibel < 45:
                processed_data['noise_category'] = 'Low'
                processed_data['noise_color'] = '#00E400'  # Green
                processed_data['noise_impact'] = 'Minimal impact on health'
            elif decibel < 55:
                processed_data['noise_category'] = 'Moderate'
                processed_data['noise_color'] = '#AAFF00'  # Light Green
                processed_data['noise_impact'] = 'May cause mild annoyance'
            elif decibel < 65:
                processed_data['noise_category'] = 'Noticeable'
                processed_data['noise_color'] = '#FFFF00'  # Yellow
                processed_data['noise_impact'] = 'May interfere with rest and conversation'
            elif decibel < 75:
                processed_data['noise_category'] = 'Loud'
                processed_data['noise_color'] = '#FF7E00'  # Orange
                processed_data['noise_impact'] = 'May cause stress and sleep disturbance'
            elif decibel < 85:
                processed_data['noise_category'] = 'Very Loud'
                processed_data['noise_color'] = '#FF0000'  # Red
                processed_data['noise_impact'] = 'May cause hearing damage with prolonged exposure'
            else:
                processed_data['noise_category'] = 'Extremely Loud'
                processed_data['noise_color'] = '#99004C'  # Purple
                processed_data['noise_impact'] = 'Can cause hearing damage even with brief exposure'
        
        return processed_data
    
    except Exception as e:
        logger.error(f"Error processing noise data: {str(e)}")
        return None

def aggregate_historical_data(air_data_list, water_data_list, noise_data_list):
    """
    Aggregate historical environmental data for trend analysis
    
    Parameters:
    - air_data_list (list): List of air quality data dictionaries over time
    - water_data_list (list): List of water quality data dictionaries over time
    - noise_data_list (list): List of noise data dictionaries over time
    
    Returns:
    - pandas.DataFrame: Aggregated data with timestamps
    """
    try:
        # Create empty lists to store data
        timestamps = []
        aqi_values = []
        wqi_values = []
        noise_values = []
        
        # Process air quality data
        for data in air_data_list:
            if data and 'timestamp' in data and 'aqi' in data:
                timestamps.append(data['timestamp'])
                aqi_values.append(data['aqi'])
        
        # Process water quality data
        for data in water_data_list:
            if data and 'timestamp' in data and 'wqi' in data:
                if data['timestamp'] not in timestamps:
                    timestamps.append(data['timestamp'])
                    aqi_values.append(None)  # No air data for this timestamp
                wqi_values.append(data['wqi'])
        
        # Process noise data
        for data in noise_data_list:
            if data and 'timestamp' in data and 'decibel' in data:
                if data['timestamp'] not in timestamps:
                    timestamps.append(data['timestamp'])
                    aqi_values.append(None)  # No air data for this timestamp
                    wqi_values.append(None)  # No water data for this timestamp
                noise_values.append(data['decibel'])
        
        # Create DataFrame
        df = pd.DataFrame({
            'timestamp': timestamps,
            'aqi': aqi_values,
            'wqi': wqi_values,
            'noise': noise_values
        })
        
        # Sort by timestamp
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        return df
    
    except Exception as e:
        logger.error(f"Error aggregating historical data: {str(e)}")
        return pd.DataFrame()  # Return empty DataFrame on error
