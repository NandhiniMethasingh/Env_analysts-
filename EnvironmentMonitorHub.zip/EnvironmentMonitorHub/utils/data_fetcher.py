import requests
import pandas as pd
import numpy as np
import os
import datetime
import logging
from io import StringIO
import sys

# Add data directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import synthetic data generator
from data.synthetic_data import (
    generate_air_quality_data,
    generate_water_quality_data,
    generate_noise_data,
    generate_historical_data
)
from data.locations import STATES_DATA

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Define API endpoints and keys
# You would replace these with actual API endpoints
OPENAQ_API = "https://api.openaq.org/v2/latest"
CPCB_API = "https://api.cpcb.gov.in/data" # Placeholder, actual endpoint may differ
TNPCB_API = "https://api.tnpcb.gov.in/data" # Placeholder, actual endpoint may differ
# Get API key from environment variable
OPENAQ_API_KEY = os.getenv("OPENAQ_API_KEY", "")

def fetch_air_quality_data(latitude, longitude, date, source="database"):
    """
    Fetch air quality data for given coordinates and date
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to fetch data for
    - source (str): Data source - 'database', 'api', or 'synthetic'
    
    Returns:
    - dict: Air quality data including AQI and pollutant levels
    """
    try:
        # First try to get data from the database
        if source == "database":
            db_data = fetch_from_database(latitude, longitude, date, "air")
            if db_data:
                return db_data
            # Fall back to synthetic data if no database records
            logger.info(f"No database records for air quality at {latitude}, {longitude} on {date}, using synthetic data")
            source = "synthetic"
        
        # Try external APIs if specified
        if source == "api":
            api_data = fetch_from_api(latitude, longitude, date, "air")
            if api_data:
                return api_data
            # Fall back to synthetic data if API fails
            logger.info(f"API fetch failed for air quality at {latitude}, {longitude} on {date}, using synthetic data")
            source = "synthetic"
        
        # Generate synthetic data as a last resort
        if source == "synthetic":
            state_name = get_state_for_location(latitude, longitude)
            logger.info(f"Using synthetic data for air quality at {latitude}, {longitude} on {date}")
            return generate_air_quality_data(latitude, longitude, date, state_name)
        
        # Unknown source
        logger.error(f"Unknown air quality data source: {source}")
        return None
    except Exception as e:
        logger.error(f"Error fetching air quality data: {str(e)}")
        return {
            'error': str(e),
            'status': 'error'
        }

def fetch_from_database(latitude, longitude, date, data_type):
    """Fetch environmental data from the database for the nearest monitoring location"""
    try:
        # Import database functionality here to avoid circular imports
        from database.crud import get_nearest_location, get_latest_air_quality, get_latest_water_quality, get_latest_noise_reading
        
        # Find the nearest monitoring location
        location = get_nearest_location(latitude, longitude)
        if not location:
            logger.warning(f"No monitoring locations found near ({latitude}, {longitude})")
            return None
        
        # Convert datetime.date to datetime.datetime for proper comparison
        if isinstance(date, datetime.date):
            date = datetime.datetime.combine(date, datetime.time())
        
        # Return appropriate data based on type
        if data_type == "air":
            reading = get_latest_air_quality(location.id)
            if reading:
                # Convert SQLAlchemy model to dictionary
                return {
                    'aqi': reading.aqi,
                    'pm25': reading.pm25,
                    'pm10': reading.pm10,
                    'so2': reading.so2,
                    'no2': reading.no2,
                    'co': reading.co,
                    'o3': reading.o3,
                    'timestamp': reading.reading_date.isoformat(),
                    'source': 'database'
                }
        
        elif data_type == "water":
            reading = get_latest_water_quality(location.id)
            if reading:
                return {
                    'wqi': reading.wqi,
                    'ph': reading.ph,
                    'do': reading.do,
                    'bod': reading.bod,
                    'cod': reading.cod,
                    'tds': reading.tds,
                    'turbidity': reading.turbidity,
                    'timestamp': reading.reading_date.isoformat(),
                    'source': 'database'
                }
        
        elif data_type == "noise":
            reading = get_latest_noise_reading(location.id)
            if reading:
                return {
                    'decibel': reading.decibel,
                    'category': reading.category,
                    'timestamp': reading.reading_date.isoformat(),
                    'source': 'database'
                }
        
        # If we got here, no suitable data was found
        return None
    
    except Exception as e:
        logger.error(f"Error fetching data from database: {str(e)}")
        return None

def fetch_from_api(latitude, longitude, date, data_type):
    """Fetch environmental data from external APIs"""
    try:
        if data_type == "air":
            # Try different air quality APIs
            apis = ["openaq", "cpcb", "tnpcb"]
            for api in apis:
                data = None
                if api == "openaq":
                    data = fetch_from_openaq_api(latitude, longitude, date)
                elif api == "cpcb":
                    data = fetch_from_cpcb(latitude, longitude, date)
                elif api == "tnpcb":
                    data = fetch_from_tnpcb(latitude, longitude, date)
                
                if data:
                    return data
            
            # If all APIs failed, return None
            return None
        
        # For other data types, we don't have APIs yet
        return None
    
    except Exception as e:
        logger.error(f"Error fetching data from API: {str(e)}")
        return None

def fetch_from_openaq_api(latitude, longitude, date):
    """Fetch air quality data from OpenAQ API"""
    try:
        params = {
            'coordinates': f"{latitude},{longitude}",
            'radius': 10000,  # 10km radius
            'date_from': date.strftime('%Y-%m-%d'),
            'date_to': (date + datetime.timedelta(days=1)).strftime('%Y-%m-%d'),
            'limit': 100
        }
        
        if OPENAQ_API_KEY:
            headers = {"X-API-Key": OPENAQ_API_KEY}
            response = requests.get(OPENAQ_API, params=params, headers=headers)
        else:
            response = requests.get(OPENAQ_API, params=params)
        
        if response.status_code != 200:
            logger.error(f"OpenAQ API error: {response.status_code}, {response.text}")
            return None
        
        data = response.json()
        
        if not data or 'results' not in data or len(data['results']) == 0:
            logger.warning("No air quality data found in OpenAQ response")
            return None
        
        # Process response to extract air quality metrics
        pollutants = {}
        for result in data['results']:
            if 'parameters' in result:
                for param in result['parameters']:
                    name = param.get('parameter', '').lower()
                    value = param.get('value')
                    if name and value is not None:
                        if name in pollutants:
                            # Average if we have multiple readings
                            pollutants[name] = (pollutants[name] + value) / 2
                        else:
                            pollutants[name] = value
        
        # Calculate approximate AQI if not provided directly
        aqi = calculate_aqi_from_pollutants(pollutants)
        
        return {
            'aqi': aqi,
            'pm25': pollutants.get('pm25', None),
            'pm10': pollutants.get('pm10', None),
            'so2': pollutants.get('so2', None),
            'no2': pollutants.get('no2', None),
            'co': pollutants.get('co', None),
            'o3': pollutants.get('o3', None),
            'timestamp': datetime.datetime.now().isoformat(),
            'source': 'openaq'
        }
        
    except Exception as e:
        logger.error(f"Error in OpenAQ API fetch: {str(e)}")
        return None

def fetch_from_cpcb(latitude, longitude, date):
    """Fetch air quality data from CPCB API"""
    # This is a placeholder for CPCB API implementation
    # In a production environment, you would implement the actual API call
    logger.info(f"Attempted to fetch CPCB data for {latitude}, {longitude} on {date}")
    
    # Implement CPCB API call here
    return None

def fetch_from_tnpcb(latitude, longitude, date):
    """Fetch air quality data from TNPCB API"""
    # This is a placeholder for TNPCB API implementation
    # In a production environment, you would implement the actual API call
    logger.info(f"Attempted to fetch TNPCB data for {latitude}, {longitude} on {date}")
    
    # Implement TNPCB API call here
    return None

def fetch_water_quality_data(latitude, longitude, date, source="database"):
    """
    Fetch water quality data for given coordinates and date
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to fetch data for
    - source (str): Data source - 'database', 'api', or 'synthetic'
    
    Returns:
    - dict: Water quality data including WQI and parameters
    """
    try:
        # First try to get data from the database
        if source == "database":
            db_data = fetch_from_database(latitude, longitude, date, "water")
            if db_data:
                return db_data
            # Fall back to synthetic data if no database records
            logger.info(f"No database records for water quality at {latitude}, {longitude} on {date}, using synthetic data")
            source = "synthetic"
            
        # Generate synthetic water quality data
        if source == "synthetic":
            state_name = get_state_for_location(latitude, longitude)
            logger.info(f"Using synthetic data for water quality at {latitude}, {longitude} on {date}")
            return generate_water_quality_data(latitude, longitude, date, state_name)
        
        # Unknown source
        logger.error(f"Unknown water quality data source: {source}")
        return None
        
    except Exception as e:
        logger.error(f"Error fetching water quality data: {str(e)}")
        return {
            'error': str(e),
            'status': 'error'
        }

def fetch_noise_data(latitude, longitude, date, source="database"):
    """
    Fetch noise pollution data for given coordinates and date
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - date (datetime.date): Date to fetch data for
    - source (str): Data source - 'database', 'api', or 'synthetic'
    
    Returns:
    - dict: Noise data including decibel levels
    """
    try:
        # First try to get data from the database
        if source == "database":
            db_data = fetch_from_database(latitude, longitude, date, "noise")
            if db_data:
                return db_data
            # Fall back to synthetic data if no database records
            logger.info(f"No database records for noise data at {latitude}, {longitude} on {date}, using synthetic data")
            source = "synthetic"
            
        # Generate synthetic noise data
        if source == "synthetic":
            state_name = get_state_for_location(latitude, longitude)
            logger.info(f"Using synthetic data for noise pollution at {latitude}, {longitude} on {date}")
            return generate_noise_data(latitude, longitude, date, state_name)
        
        # Unknown source
        logger.error(f"Unknown noise data source: {source}")
        return None
        
    except Exception as e:
        logger.error(f"Error fetching noise data: {str(e)}")
        return {
            'error': str(e),
            'status': 'error'
        }

def get_state_for_location(latitude, longitude):
    """
    Determine which state a location belongs to based on its coordinates
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    
    Returns:
    - str or None: The state name if found, None otherwise
    """
    import math
    
    def calculate_distance(lat1, lon1, lat2, lon2):
        """Calculate simple Euclidean distance between two points"""
        return math.sqrt((lat1 - lat2)**2 + (lon1 - lon2)**2)
    
    # Check each state and its cities
    closest_state = None
    min_distance = float('inf')
    
    for state_name, state_data in STATES_DATA.items():
        for city_name, city_data in state_data["cities"].items():
            city_lat = city_data["lat"]
            city_lon = city_data["lon"]
            
            distance = calculate_distance(latitude, longitude, city_lat, city_lon)
            
            if distance < min_distance:
                min_distance = distance
                closest_state = state_name
    
    return closest_state

def fetch_historical_data(latitude, longitude, start_date, days=7, source="database"):
    """
    Fetch historical environmental data for a location
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - start_date (datetime.date): Start date for the historical data
    - days (int): Number of days of historical data to fetch
    - source (str): Data source - 'database', 'api', or 'synthetic' 
    
    Returns:
    - tuple: (air_data_list, water_data_list, noise_data_list)
    """
    try:
        # Try to get data from the database first
        if source == "database":
            try:
                # Import database functionality here to avoid circular imports
                from database.crud import (
                    get_nearest_location, 
                    get_air_quality_history, 
                    get_water_quality_history, 
                    get_noise_history
                )
                
                # Find the nearest monitoring location
                location = get_nearest_location(latitude, longitude)
                if location:
                    # Convert data from the database
                    air_readings = get_air_quality_history(location.id, days)
                    water_readings = get_water_quality_history(location.id, days)
                    noise_readings = get_noise_history(location.id, days)
                    
                    # If we have data, convert SQLAlchemy models to dictionaries
                    if air_readings and water_readings and noise_readings:
                        air_data_list = []
                        for reading in air_readings:
                            air_data_list.append({
                                'aqi': reading.aqi,
                                'pm25': reading.pm25,
                                'pm10': reading.pm10,
                                'so2': reading.so2,
                                'no2': reading.no2,
                                'co': reading.co,
                                'o3': reading.o3,
                                'timestamp': reading.reading_date.isoformat(),
                                'source': 'database'
                            })
                        
                        water_data_list = []
                        for reading in water_readings:
                            water_data_list.append({
                                'wqi': reading.wqi,
                                'ph': reading.ph,
                                'do': reading.do,
                                'bod': reading.bod,
                                'cod': reading.cod,
                                'tds': reading.tds,
                                'turbidity': reading.turbidity,
                                'timestamp': reading.reading_date.isoformat(),
                                'source': 'database'
                            })
                        
                        noise_data_list = []
                        for reading in noise_readings:
                            noise_data_list.append({
                                'decibel': reading.decibel,
                                'category': reading.category,
                                'timestamp': reading.reading_date.isoformat(),
                                'source': 'database'
                            })
                        
                        logger.info(f"Retrieved historical data from database for {latitude}, {longitude}")
                        return air_data_list, water_data_list, noise_data_list
            
            except Exception as db_error:
                logger.error(f"Error fetching historical data from database: {str(db_error)}")
                
            # If we get here, we couldn't get all data from the database
            logger.info(f"No complete historical data in database for {latitude}, {longitude}, using synthetic data")
            source = "synthetic"
        
        # Generate synthetic historical data as fallback
        if source == "synthetic":
            # Identify the state
            state_name = get_state_for_location(latitude, longitude)
            
            # Generate synthetic historical data
            logger.info(f"Generating historical data for {latitude}, {longitude} starting from {start_date}")
            return generate_historical_data(latitude, longitude, start_date, days, state_name)
        
    except Exception as e:
        logger.error(f"Error generating historical data: {str(e)}")
    
    # Default empty lists if all else fails
    return [], [], []

def calculate_aqi_from_pollutants(pollutants):
    """
    Calculate Air Quality Index from pollutant concentrations
    This is a simplified calculation - actual AQI calculation is more complex
    """
    # U.S. EPA AQI breakpoints
    # PM2.5 (μg/m3, 24-hour average)
    pm25_breakpoints = [
        (0, 12.0, 0, 50),
        (12.1, 35.4, 51, 100),
        (35.5, 55.4, 101, 150),
        (55.5, 150.4, 151, 200),
        (150.5, 250.4, 201, 300),
        (250.5, 500.4, 301, 500)
    ]
    
    # PM10 (μg/m3, 24-hour average)
    pm10_breakpoints = [
        (0, 54, 0, 50),
        (55, 154, 51, 100),
        (155, 254, 101, 150),
        (255, 354, 151, 200),
        (355, 424, 201, 300),
        (425, 604, 301, 500)
    ]
    
    # Calculate AQI for PM2.5 if available
    pm25_aqi = None
    if 'pm25' in pollutants:
        pm25 = pollutants['pm25']
        for low, high, aqi_low, aqi_high in pm25_breakpoints:
            if low <= pm25 <= high:
                pm25_aqi = ((aqi_high - aqi_low) / (high - low)) * (pm25 - low) + aqi_low
                break
    
    # Calculate AQI for PM10 if available
    pm10_aqi = None
    if 'pm10' in pollutants:
        pm10 = pollutants['pm10']
        for low, high, aqi_low, aqi_high in pm10_breakpoints:
            if low <= pm10 <= high:
                pm10_aqi = ((aqi_high - aqi_low) / (high - low)) * (pm10 - low) + aqi_low
                break
    
    # Take the highest AQI as the overall AQI
    aqi_values = [val for val in [pm25_aqi, pm10_aqi] if val is not None]
    if aqi_values:
        return round(max(aqi_values))
    else:
        # Default value if no pollutants are available
        return 50  # Moderate
