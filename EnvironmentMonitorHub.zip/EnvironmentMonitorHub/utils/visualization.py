import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import folium
from folium.plugins import HeatMap
import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_aqi_gauge(aqi_value):
    """
    Create a gauge chart for Air Quality Index
    
    Parameters:
    - aqi_value (float): AQI value to display
    
    Returns:
    - plotly.graph_objects.Figure: Gauge chart
    """
    try:
        if aqi_value is None:
            aqi_value = 0
        
        # AQI categories and colors
        aqi_ranges = [
            (0, 50, 'Good', '#00E400'),
            (51, 100, 'Moderate', '#FFFF00'),
            (101, 150, 'Unhealthy for Sensitive Groups', '#FF7E00'),
            (151, 200, 'Unhealthy', '#FF0000'),
            (201, 300, 'Very Unhealthy', '#99004C'),
            (301, 500, 'Hazardous', '#7E0023')
        ]
        
        # Find the current category
        category = "Unknown"
        color = "#CCCCCC"
        for low, high, cat, col in aqi_ranges:
            if low <= aqi_value <= high:
                category = cat
                color = col
                break
        
        # Create the gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=aqi_value,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': f"Air Quality Index: {category}", 'font': {'size': 24}},
            gauge={
                'axis': {'range': [0, 500], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': color},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 50], 'color': '#00E400'},
                    {'range': [51, 100], 'color': '#FFFF00'},
                    {'range': [101, 150], 'color': '#FF7E00'},
                    {'range': [151, 200], 'color': '#FF0000'},
                    {'range': [201, 300], 'color': '#99004C'},
                    {'range': [301, 500], 'color': '#7E0023'}
                ]
            }
        ))
        
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        return fig
    
    except Exception as e:
        logger.error(f"Error creating AQI gauge: {str(e)}")
        # Return a simple error figure
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14)
        )
        return fig

def create_wqi_gauge(wqi_value):
    """
    Create a gauge chart for Water Quality Index
    
    Parameters:
    - wqi_value (float): WQI value to display
    
    Returns:
    - plotly.graph_objects.Figure: Gauge chart
    """
    try:
        if wqi_value is None:
            wqi_value = 0
        
        # WQI categories and colors
        wqi_ranges = [
            (0, 44, 'Poor', '#FF0000'),
            (45, 64, 'Marginal', '#FF7E00'),
            (65, 79, 'Fair', '#FFFF00'),
            (80, 94, 'Good', '#AAFF00'),
            (95, 100, 'Excellent', '#00E400')
        ]
        
        # Find the current category
        category = "Unknown"
        color = "#CCCCCC"
        for low, high, cat, col in wqi_ranges:
            if low <= wqi_value <= high:
                category = cat
                color = col
                break
        
        # Create the gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=wqi_value,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': f"Water Quality Index: {category}", 'font': {'size': 24}},
            gauge={
                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': color},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 44], 'color': '#FF0000'},
                    {'range': [45, 64], 'color': '#FF7E00'},
                    {'range': [65, 79], 'color': '#FFFF00'},
                    {'range': [80, 94], 'color': '#AAFF00'},
                    {'range': [95, 100], 'color': '#00E400'}
                ]
            }
        ))
        
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        return fig
    
    except Exception as e:
        logger.error(f"Error creating WQI gauge: {str(e)}")
        # Return a simple error figure
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14)
        )
        return fig

def create_noise_gauge(decibel_value):
    """
    Create a gauge chart for noise levels
    
    Parameters:
    - decibel_value (float): Noise level in decibels
    
    Returns:
    - plotly.graph_objects.Figure: Gauge chart
    """
    try:
        if decibel_value is None:
            decibel_value = 0
        
        # Noise level categories and colors
        noise_ranges = [
            (0, 44, 'Low', '#00E400'),
            (45, 54, 'Moderate', '#AAFF00'),
            (55, 64, 'Noticeable', '#FFFF00'),
            (65, 74, 'Loud', '#FF7E00'),
            (75, 84, 'Very Loud', '#FF0000'),
            (85, 120, 'Extremely Loud', '#99004C')
        ]
        
        # Find the current category
        category = "Unknown"
        color = "#CCCCCC"
        for low, high, cat, col in noise_ranges:
            if low <= decibel_value <= high:
                category = cat
                color = col
                break
        
        # Create the gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=decibel_value,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': f"Noise Level: {category}", 'font': {'size': 24}},
            gauge={
                'axis': {'range': [0, 120], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': color},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 44], 'color': '#00E400'},
                    {'range': [45, 54], 'color': '#AAFF00'},
                    {'range': [55, 64], 'color': '#FFFF00'},
                    {'range': [65, 74], 'color': '#FF7E00'},
                    {'range': [75, 84], 'color': '#FF0000'},
                    {'range': [85, 120], 'color': '#99004C'}
                ]
            }
        ))
        
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        return fig
    
    except Exception as e:
        logger.error(f"Error creating noise gauge: {str(e)}")
        # Return a simple error figure
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14)
        )
        return fig

def plot_pollution_trends(latitude, longitude, days=7):
    """
    Create a line chart showing pollution trends over time
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - days (int): Number of days of historical data to include
    
    Returns:
    - plotly.graph_objects.Figure: Line chart with trends
    """
    try:
        # Import here to avoid circular imports
        from utils.data_fetcher import fetch_historical_data
        
        # Get historical data
        end_date = datetime.datetime.now().date()
        air_data_list, water_data_list, noise_data_list = fetch_historical_data(
            latitude, longitude, end_date, days
        )
        
        # Extract dates, AQI, WQI, and noise values
        dates = []
        aqi_values = []
        wqi_values = []
        noise_values = []
        
        # Process data from each date
        for air_data, water_data, noise_data in zip(air_data_list, water_data_list, noise_data_list):
            # Parse timestamp
            if 'timestamp' in air_data:
                try:
                    timestamp = datetime.datetime.fromisoformat(air_data['timestamp'])
                    dates.append(timestamp)
                except ValueError:
                    # If timestamp parsing fails, create a dummy date
                    dates.append(None)
            else:
                dates.append(None)
            
            # Extract AQI
            if air_data and 'aqi' in air_data:
                aqi_values.append(air_data['aqi'])
            else:
                aqi_values.append(None)
            
            # Extract WQI
            if water_data and 'wqi' in water_data:
                wqi_values.append(water_data['wqi'])
            else:
                wqi_values.append(None)
            
            # Extract noise level
            if noise_data and 'decibel' in noise_data:
                noise_values.append(noise_data['decibel'])
            else:
                noise_values.append(None)
        
        # Create DataFrame with the data
        data = {
            'date': dates,
            'AQI': aqi_values,
            'WQI': wqi_values,
            'Noise (dB)': noise_values
        }
        
        # Remove any None entries
        valid_indices = [i for i, d in enumerate(dates) if d is not None]
        clean_data = {
            'date': [dates[i] for i in valid_indices],
            'AQI': [aqi_values[i] for i in valid_indices],
            'WQI': [wqi_values[i] for i in valid_indices],
            'Noise (dB)': [noise_values[i] for i in valid_indices]
        }
        
        # Create DataFrame
        df = pd.DataFrame(clean_data)
        
        # Sort by date
        df = df.sort_values('date')
        
        # Create plot
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=df['date'], 
            y=df['AQI'],
            mode='lines+markers',
            name='Air Quality Index',
            line=dict(color='#FF7E00', width=2)  # Orange
        ))
        
        fig.add_trace(go.Scatter(
            x=df['date'], 
            y=df['WQI'],
            mode='lines+markers',
            name='Water Quality Index',
            line=dict(color='#00C4FF', width=2)  # Blue
        ))
        
        fig.add_trace(go.Scatter(
            x=df['date'], 
            y=df['Noise (dB)'],
            mode='lines+markers',
            name='Noise Level (dB)',
            line=dict(color='#8B00FF', width=2)  # Purple
        ))
        
        # Update layout
        fig.update_layout(
            title="Environmental Quality Trends (Last 7 Days)",
            xaxis_title="Date",
            yaxis_title="Value",
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            ),
            height=400,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        return fig
    
    except Exception as e:
        logger.error(f"Error creating pollution trends plot: {str(e)}")
        # Return a simple error figure
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating trend visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14)
        )
        return fig

def create_map(latitude, longitude, air_quality=None, water_quality=None, noise_level=None, zoom=12):
    """
    Create an interactive map centered on the specified location
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - air_quality (str/float): Air quality data to display
    - water_quality (str/float): Water quality data to display
    - noise_level (str/float): Noise level data to display
    - zoom (int): Initial zoom level
    
    Returns:
    - folium.Map: Interactive map
    """
    try:
        # Create base map
        m = folium.Map(location=[latitude, longitude], zoom_start=zoom, tiles="OpenStreetMap")
        
        # Determine marker color based on air quality
        if air_quality is not None and isinstance(air_quality, (int, float)):
            if air_quality <= 50:
                color = 'green'
            elif air_quality <= 100:
                color = 'blue'
            elif air_quality <= 150:
                color = 'orange'
            elif air_quality <= 200:
                color = 'red'
            elif air_quality <= 300:
                color = 'purple'
            else:
                color = 'darkred'
        else:
            color = 'blue'
        
        # Create popup content
        popup_html = f"""
        <div style="width: 200px; font-family: Arial;">
            <h4 style="margin: 5px 0;">Environmental Data</h4>
            <hr style="margin: 5px 0;">
            <p><b>Air Quality:</b> {air_quality if air_quality is not None else 'N/A'}</p>
            <p><b>Water Quality:</b> {water_quality if water_quality is not None else 'N/A'}</p>
            <p><b>Noise Level:</b> {noise_level if noise_level is not None else 'N/A'} dB</p>
            <hr style="margin: 5px 0;">
            <p>Lat: {latitude:.4f}, Lng: {longitude:.4f}</p>
        </div>
        """
        
        # Add marker
        folium.Marker(
            location=[latitude, longitude],
            popup=folium.Popup(popup_html, max_width=250),
            icon=folium.Icon(color=color, icon='info-sign')
        ).add_to(m)
        
        # Add circle to represent the area
        folium.Circle(
            location=[latitude, longitude],
            radius=1000,  # 1km radius
            color=color,
            fill=True,
            fill_opacity=0.2
        ).add_to(m)
        
        # Add Coimbatore areas of interest
        areas = [
            {"name": "Coimbatore City Center", "coords": [11.0168, 76.9558]},
            {"name": "Peelamedu", "coords": [11.0225, 77.0021]},
            {"name": "Singanallur", "coords": [11.0019, 77.0369]},
            {"name": "Saibaba Colony", "coords": [11.0242, 76.9382]},
            {"name": "R.S. Puram", "coords": [11.0041, 76.9510]},
            {"name": "Ganapathy", "coords": [11.0405, 76.9835]}
        ]
        
        for area in areas:
            folium.CircleMarker(
                location=area["coords"],
                radius=5,
                color='gray',
                fill=True,
                fill_color='gray',
                fill_opacity=0.7,
                popup=area["name"]
            ).add_to(m)
        
        # Add layer control
        folium.LayerControl().add_to(m)
        
        return m
    
    except Exception as e:
        logger.error(f"Error creating map: {str(e)}")
        # Return a simple map centered on Coimbatore
        return folium.Map(location=[11.0168, 76.9558], zoom_start=10)

def create_pollutant_bar_chart(pollutant_data, safe_limits=None):
    """
    Create a bar chart comparing pollutant levels to safe limits
    
    Parameters:
    - pollutant_data (dict): Dictionary of pollutant names and values
    - safe_limits (dict, optional): Dictionary of safe limits for each pollutant
    
    Returns:
    - plotly.graph_objects.Figure: Bar chart
    """
    try:
        if pollutant_data is None or len(pollutant_data) == 0:
            return go.Figure().add_annotation(
                text="No pollutant data available",
                showarrow=False,
                font=dict(size=14)
            )
        
        # Default safe limits if not provided
        if safe_limits is None:
            safe_limits = {
                'pm25': 12,   # PM2.5 (μg/m3)
                'pm10': 50,   # PM10 (μg/m3)
                'so2': 20,    # SO2 (ppb)
                'no2': 53,    # NO2 (ppb)
                'co': 9,      # CO (ppm)
                'o3': 70      # O3 (ppb)
            }
        
        # Extract relevant pollutants
        pollutants = []
        values = []
        limits = []
        
        for pollutant, value in pollutant_data.items():
            if pollutant in safe_limits and value is not None:
                pollutants.append(pollutant.upper())
                values.append(value)
                limits.append(safe_limits[pollutant])
        
        if len(pollutants) == 0:
            return go.Figure().add_annotation(
                text="No matching pollutant data available",
                showarrow=False,
                font=dict(size=14)
            )
        
        # Create the figure
        fig = go.Figure()
        
        # Add pollutant bars
        fig.add_trace(go.Bar(
            x=pollutants,
            y=values,
            name='Current Level',
            marker_color='indianred'
        ))
        
        # Add safe limit bars
        fig.add_trace(go.Bar(
            x=pollutants,
            y=limits,
            name='Safe Limit',
            marker_color='lightseagreen'
        ))
        
        # Update layout
        fig.update_layout(
            title="Pollutant Levels vs. Safe Limits",
            xaxis_title="Pollutant",
            yaxis_title="Concentration",
            barmode='group',
            height=400,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        return fig
    
    except Exception as e:
        logger.error(f"Error creating pollutant bar chart: {str(e)}")
        # Return a simple error figure
        fig = go.Figure()
        fig.add_annotation(
            text=f"Error creating pollutant visualization: {str(e)}",
            showarrow=False,
            font=dict(size=14)
        )
        return fig
