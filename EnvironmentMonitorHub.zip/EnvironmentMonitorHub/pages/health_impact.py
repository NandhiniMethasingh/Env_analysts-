import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import datetime
import sys
import os
from datetime import timedelta

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.data_fetcher import fetch_air_quality_data, fetch_water_quality_data, fetch_noise_data
from utils.data_processor import process_air_quality_data, process_water_quality_data, process_noise_data
from utils.health_assessment import calculate_health_risk
from utils.visualization import create_map

def show_health_impact_page(latitude, longitude, selected_date):
    """
    Display the health impact assessment page with personalized health risk information
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - selected_date (datetime.date): Date to display data for
    """
    st.title("HEALTH IMPACT ASSESSMENT")
    
    st.markdown("""
    This page provides a personalized health risk assessment based on the environmental 
    conditions in your selected location. Understanding the potential health impacts of 
    environmental factors can help you take appropriate preventive measures.
    """)
    
    # Display a loading spinner while fetching data
    with st.spinner("Analyzing environmental health impacts..."):
        # Fetch all environmental data
        air_data = fetch_air_quality_data(latitude, longitude, selected_date)
        water_data = fetch_water_quality_data(latitude, longitude, selected_date)
        noise_data = fetch_noise_data(latitude, longitude, selected_date)
        
        # Process the data
        processed_air_data = process_air_quality_data(air_data)
        processed_water_data = process_water_quality_data(water_data)
        processed_noise_data = process_noise_data(noise_data)
        
        # Calculate health risk
        health_risk = calculate_health_risk(processed_air_data, processed_water_data, noise_data)
    
    if 'error' in health_risk:
        st.error(f"Error calculating health risks: {health_risk['error']}")
        return
    
    # User profile section
    st.subheader("Personalize Your Health Assessment")
    
    with st.expander("Enter Your Health Information (Optional)", expanded=False):
        st.markdown("""
        Providing additional health information can help us personalize your environmental health assessment.
        This information is processed locally and is not stored or transmitted.
        """)
        
        col1, col2 = st.columns(2)
        
        with col1:
            age_group = st.selectbox(
                "Age Group",
                ["Child (0-12)", "Teenager (13-19)", "Adult (20-64)", "Senior (65+)"]
            )
            
            gender = st.selectbox(
                "Gender",
                ["Male", "Female", "Other"]
            )
        
        with col2:
            has_respiratory_condition = st.checkbox("I have a respiratory condition (asthma, COPD, etc.)")
            has_cardiovascular_condition = st.checkbox("I have a cardiovascular condition")
            is_pregnant = st.checkbox("I am pregnant")
            has_allergies = st.checkbox("I have allergies")
        
        st.markdown("---")
        
        # Activity level
        activity_level = st.select_slider(
            "Daily Outdoor Activity Level",
            options=["Minimal", "Low", "Moderate", "High", "Very High"],
            value="Moderate"
        )
        
        # Time spent outdoors
        hours_outdoors = st.slider("Average Hours Spent Outdoors Daily", 0, 24, 2)
    
    # Create columns for risk display
    st.subheader("Your Environmental Health Risk Assessment")
    
    # Location map
    st.markdown("#### Location")
    map_fig = create_map(
        latitude, longitude,
        air_quality=processed_air_data.get('aqi', 'N/A') if processed_air_data else 'N/A',
        water_quality=processed_water_data.get('wqi', 'N/A') if processed_water_data else 'N/A',
        noise_level=processed_noise_data.get('decibel', 'N/A') if processed_noise_data else 'N/A'
    )
    st.components.v1.html(map_fig._repr_html_(), height=300)
    
    # Health risk metrics
    st.markdown("#### Health Risk Metrics")
    
    risk_col1, risk_col2, risk_col3 = st.columns(3)
    
    with risk_col1:
        respiratory_risk = health_risk['respiratory_risk']
        st.markdown(f"**Respiratory Health Risk**")
        
        # Create gauge chart for respiratory risk
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=respiratory_risk,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Respiratory Risk", 'font': {'size': 16}},
            gauge={
                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': get_risk_color(respiratory_risk)},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 20], 'color': '#00E400'},
                    {'range': [20, 40], 'color': '#AAFF00'},
                    {'range': [40, 60], 'color': '#FFFF00'},
                    {'range': [60, 80], 'color': '#FF7E00'},
                    {'range': [80, 100], 'color': '#FF0000'}
                ]
            }
        ))
        
        fig.update_layout(height=200, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(health_risk['respiratory_message'])
        
    with risk_col2:
        cardiovascular_risk = health_risk['cardiovascular_risk']
        st.markdown(f"**Cardiovascular Health Risk**")
        
        # Create gauge chart for cardiovascular risk
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=cardiovascular_risk,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Cardiovascular Risk", 'font': {'size': 16}},
            gauge={
                'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': get_risk_color(cardiovascular_risk)},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 20], 'color': '#00E400'},
                    {'range': [20, 40], 'color': '#AAFF00'},
                    {'range': [40, 60], 'color': '#FFFF00'},
                    {'range': [60, 80], 'color': '#FF7E00'},
                    {'range': [80, 100], 'color': '#FF0000'}
                ]
            }
        ))
        
        fig.update_layout(height=200, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(health_risk['cardiovascular_message'])
    
    with risk_col3:
        overall_health_index = health_risk['overall_health_index']
        st.markdown(f"**Overall Environmental Health Index**")
        
        # Create gauge chart for overall health index
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=overall_health_index,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Health Index", 'font': {'size': 16}},
            gauge={
                'axis': {'range': [0, 10], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': get_health_index_color(overall_health_index)},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 2], 'color': '#FF0000'},
                    {'range': [2, 4], 'color': '#FF7E00'},
                    {'range': [4, 6], 'color': '#FFFF00'},
                    {'range': [6, 8], 'color': '#AAFF00'},
                    {'range': [8, 10], 'color': '#00E400'}
                ]
            }
        ))
        
        fig.update_layout(height=200, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(health_risk['overall_message'])
    
    # Recommendations section
    st.subheader("Personalized Health Recommendations")
    
    for i, recommendation in enumerate(health_risk['recommendations']):
        st.markdown(f"{i+1}. {recommendation}")
    
    # Health impact analysis
    st.subheader("Detailed Health Impact Analysis")
    
    impact_tabs = st.tabs(["Air Quality Impact", "Water Quality Impact", "Noise Impact", "Cumulative Effects"])
    
    with impact_tabs[0]:
        st.markdown("### Air Quality Health Impact")
        
        if processed_air_data and 'aqi' in processed_air_data:
            aqi = processed_air_data['aqi']
            aqi_category = processed_air_data.get('aqi_category', 'Unknown')
            
            st.markdown(f"**Current Air Quality Index (AQI):** {aqi} - {aqi_category}")
            
            st.markdown("#### Short-term Health Effects:")
            if aqi < 50:  # Good
                st.markdown("- No significant short-term health effects expected")
            elif aqi < 100:  # Moderate
                st.markdown("- Unusually sensitive individuals may experience respiratory symptoms")
                st.markdown("- Possible mild irritation of eyes, nose, and throat for sensitive individuals")
            elif aqi < 150:  # Unhealthy for Sensitive Groups
                st.markdown("- People with respiratory or heart conditions, the elderly, and children may experience health effects")
                st.markdown("- May cause respiratory symptoms like coughing or shortness of breath in sensitive groups")
                st.markdown("- Could trigger asthma attacks in susceptible individuals")
            elif aqi < 200:  # Unhealthy
                st.markdown("- Everyone may begin to experience health effects")
                st.markdown("- Significant increase in respiratory symptoms")
                st.markdown("- Aggravation of heart or lung disease")
                st.markdown("- Increased likelihood of asthma attacks")
            elif aqi < 300:  # Very Unhealthy
                st.markdown("- Serious health effects for everyone, especially sensitive groups")
                st.markdown("- Significant aggravation of heart or lung disease")
                st.markdown("- Premature mortality in people with cardiopulmonary disease and the elderly")
                st.markdown("- Serious risk of respiratory effects in general population")
            else:  # Hazardous
                st.markdown("- Health warnings of emergency conditions")
                st.markdown("- Serious risk of respiratory effects in the general population")
                st.markdown("- Significant aggravation of heart or lung disease")
                st.markdown("- Likelihood of premature mortality increases significantly")
            
            st.markdown("#### Long-term Health Concerns:")
            if aqi < 100:  # Good to Moderate
                st.markdown("- Minimal long-term concerns for most individuals")
                st.markdown("- Those with pre-existing conditions should monitor consistent exposure")
            else:  # Unhealthy and worse
                st.markdown("- Increased risk of developing respiratory conditions")
                st.markdown("- Potential cardiovascular effects including increased risk of heart attacks and stroke")
                st.markdown("- Possible neurological impacts including cognitive decline")
                st.markdown("- Decreased lung function and development in children")
                st.markdown("- Potentially reduced life expectancy with prolonged exposure")
        else:
            st.warning("Air quality data unavailable for health impact assessment")
    
    with impact_tabs[1]:
        st.markdown("### Water Quality Health Impact")
        
        if processed_water_data and 'wqi' in processed_water_data:
            wqi = processed_water_data['wqi']
            wqi_category = processed_water_data.get('wqi_category', 'Unknown')
            
            st.markdown(f"**Current Water Quality Index (WQI):** {wqi} - {wqi_category}")
            
            st.markdown("#### Potential Health Effects:")
            if wqi >= 95:  # Excellent
                st.markdown("- No health concerns expected with properly treated water")
                st.markdown("- Suitable for all uses including drinking with standard treatment")
            elif wqi >= 80:  # Good
                st.markdown("- Generally safe for all uses with proper treatment")
                st.markdown("- Minimal health concerns")
            elif wqi >= 65:  # Fair
                st.markdown("- May contain impurities requiring additional treatment")
                st.markdown("- Possible mild gastrointestinal issues with inadequate treatment")
                st.markdown("- Recommended to use quality water purification methods")
            elif wqi >= 45:  # Marginal
                st.markdown("- Higher risk of contaminants that may affect health")
                st.markdown("- Potential gastrointestinal illness from inadequately treated water")
                st.markdown("- Risk of exposure to harmful chemicals or pathogens")
                st.markdown("- Advanced water treatment systems recommended")
            else:  # Poor
                st.markdown("- Significant health risks without thorough treatment")
                st.markdown("- Potential for serious waterborne illnesses")
                st.markdown("- May contain harmful chemical contaminants")
                st.markdown("- Not recommended for drinking without advanced purification")
                st.markdown("- Avoid recreational contact")
            
            st.markdown("#### Water Quality Parameters of Concern:")
            if processed_water_data.get('ph') and (processed_water_data['ph'] < 6.5 or processed_water_data['ph'] > 8.5):
                st.markdown("- **pH Level**: Abnormal pH can affect taste and may indicate contamination")
            
            if processed_water_data.get('do') and processed_water_data['do'] < 5:
                st.markdown("- **Dissolved Oxygen**: Low levels may indicate pollution and affect water taste")
            
            if processed_water_data.get('bod') and processed_water_data['bod'] > 3:
                st.markdown("- **Biochemical Oxygen Demand (BOD)**: Elevated levels suggest organic pollution")
            
            if processed_water_data.get('tds') and processed_water_data['tds'] > 500:
                st.markdown("- **Total Dissolved Solids (TDS)**: High levels can affect taste and indicate mineral contamination")
            
            if processed_water_data.get('turbidity') and processed_water_data['turbidity'] > 5:
                st.markdown("- **Turbidity**: High turbidity can harbor pathogens and reduce disinfection effectiveness")
        else:
            st.warning("Water quality data unavailable for health impact assessment")
    
    with impact_tabs[2]:
        st.markdown("### Noise Pollution Health Impact")
        
        if processed_noise_data and 'decibel' in processed_noise_data:
            decibel = processed_noise_data['decibel']
            noise_category = processed_noise_data.get('noise_category', 'Unknown')
            
            st.markdown(f"**Current Noise Level:** {decibel} dB - {noise_category}")
            
            st.markdown("#### Short-term Health Effects:")
            if decibel < 45:  # Low
                st.markdown("- No significant short-term health effects expected")
            elif decibel < 55:  # Moderate
                st.markdown("- Minimal health effects for most people")
                st.markdown("- May cause mild annoyance")
                st.markdown("- Could impact sleep for sensitive individuals")
            elif decibel < 65:  # Noticeable
                st.markdown("- Potential sleep disturbance")
                st.markdown("- May interfere with rest and conversation")
                st.markdown("- Could cause mild stress responses")
            elif decibel < 75:  # Loud
                st.markdown("- Increased stress levels")
                st.markdown("- Sleep disruption")
                st.markdown("- Difficulty concentrating")
                st.markdown("- Increased blood pressure and heart rate")
            elif decibel < 85:  # Very Loud
                st.markdown("- Significant stress responses")
                st.markdown("- Temporary hearing threshold shift possible with prolonged exposure")
                st.markdown("- Sleep disruption highly likely")
                st.markdown("- Increased risk of stress-related conditions")
            else:  # Extremely Loud
                st.markdown("- Risk of hearing damage even with brief exposure")
                st.markdown("- Significant physiological stress response")
                st.markdown("- Potential for immediate hearing threshold shift")
                st.markdown("- Pain and discomfort at levels above 120 dB")
            
            st.markdown("#### Long-term Health Concerns:")
            if decibel < 65:  # Low to Noticeable
                st.markdown("- Minimal long-term concerns for most individuals")
            elif decibel < 85:  # Loud to Very Loud
                st.markdown("- Potential hearing loss with prolonged, regular exposure")
                st.markdown("- Increased risk of stress-related conditions")
                st.markdown("- Possible cardiovascular effects including hypertension")
                st.markdown("- Cognitive effects including decreased concentration and performance")
            else:  # Extremely Loud
                st.markdown("- High risk of permanent hearing loss")
                st.markdown("- Significant increased risk of cardiovascular disease")
                st.markdown("- Chronic stress-related health issues")
                st.markdown("- Cognitive impairment and decreased quality of life")
                st.markdown("- Possible endocrine and metabolic effects")
        else:
            st.warning("Noise data unavailable for health impact assessment")
    
    with impact_tabs[3]:
        st.markdown("### Cumulative Environmental Health Effects")
        
        st.markdown("""
        Environmental factors don't exist in isolation - they interact and can have compound effects on health. The following analysis examines the potential cumulative impact of air, water, and noise pollution in your area.
        """)
        
        # Combined risk factors
        combined_risks = []
        
        # Check for multiple high-risk factors
        air_risk = "high" if processed_air_data and 'aqi' in processed_air_data and processed_air_data['aqi'] > 100 else "low"
        water_risk = "high" if processed_water_data and 'wqi' in processed_water_data and processed_water_data['wqi'] < 65 else "low"
        noise_risk = "high" if processed_noise_data and 'decibel' in processed_noise_data and processed_noise_data['decibel'] > 65 else "low"
        
        if air_risk == "high" and noise_risk == "high":
            combined_risks.append("The combination of poor air quality and high noise levels can significantly increase respiratory and cardiovascular strain.")
        
        if air_risk == "high" and water_risk == "high":
            combined_risks.append("Exposure to both air and water pollutants may increase the total body burden of toxins, potentially overwhelming natural detoxification processes.")
        
        if water_risk == "high" and noise_risk == "high":
            combined_risks.append("The stress from noise pollution combined with potential waterborne contaminants can impact immune function and overall health.")
        
        if air_risk == "high" and water_risk == "high" and noise_risk == "high":
            combined_risks.append("The triple combination of all environmental stressors presents a significant health challenge and may have synergistic negative effects on multiple body systems.")
        
        if not combined_risks:
            st.markdown("**No significant combined risk factors identified in your location.**")
        else:
            st.markdown("**Identified Combined Risk Factors:**")
            for risk in combined_risks:
                st.markdown(f"- {risk}")
        
        # Vulnerability factors
        st.markdown("#### Vulnerability Factors")
        st.markdown("""
        Certain populations are more vulnerable to environmental health impacts. These include:
        
        - **Children**: Still developing respiratory, immune, and neurological systems
        - **Elderly**: Decreased ability to detoxify pollutants and recover from stress
        - **Pregnant women**: Potential impacts on fetal development
        - **People with pre-existing conditions**: Especially respiratory and cardiovascular conditions
        - **People with compromised immune systems**: Reduced ability to handle additional stressors
        """)
        
        # Long-term considerations
        st.markdown("#### Long-term Considerations")
        st.markdown("""
        Chronic exposure to multiple environmental pollutants may lead to:
        
        1. **Increased allostatic load**: The cumulative wear and tear on the body from multiple environmental stressors
        2. **Epigenetic changes**: Potential changes in gene expression that can influence health
        3. **Chronic inflammation**: A common pathway for many environmental health effects
        4. **Accelerated aging processes**: Including cellular senescence and telomere shortening
        5. **Increased susceptibility to infectious diseases**: Due to compromised immune function
        """)
    
    # Future projections
    st.subheader("Environmental Health Projections")
    
    # Create a simple forecast for the next week
    today = datetime.datetime.now().date()
    dates = [today + timedelta(days=i) for i in range(7)]
    
    # Generate some reasonable forecast data
    np.random.seed(42)  # For reproducibility
    
    # Base values on current metrics with some random variation
    if processed_air_data and 'aqi' in processed_air_data:
        aqi_base = processed_air_data['aqi']
    else:
        aqi_base = 80  # Default moderate value
        
    if processed_water_data and 'wqi' in processed_water_data:
        wqi_base = processed_water_data['wqi']
    else:
        wqi_base = 75  # Default moderate value
        
    if processed_noise_data and 'decibel' in processed_noise_data:
        noise_base = processed_noise_data['decibel']
    else:
        noise_base = 65  # Default moderate value
    
    # Generate forecasts with small daily variations
    aqi_forecast = [max(0, min(500, aqi_base + np.random.normal(0, 5))) for _ in range(7)]
    wqi_forecast = [max(0, min(100, wqi_base + np.random.normal(0, 2))) for _ in range(7)]
    noise_forecast = [max(30, min(100, noise_base + np.random.normal(0, 3))) for _ in range(7)]
    
    # Calculate health risk for each day
    risk_forecast = []
    for i in range(7):
        # Simplified risk calculation
        aqi_risk = min(100, (aqi_forecast[i] / 500) * 100 * 1.5)  # Weighted more heavily
        wqi_risk = min(100, ((100 - wqi_forecast[i]) / 100) * 100)
        noise_risk = min(100, ((noise_forecast[i] - 30) / 70) * 100)
        
        # Combined risk (simplified)
        daily_risk = (aqi_risk * 0.6) + (wqi_risk * 0.3) + (noise_risk * 0.1)
        risk_forecast.append(min(100, daily_risk))
    
    # Create a DataFrame for the forecast
    forecast_df = pd.DataFrame({
        'Date': dates,
        'AQI': aqi_forecast,
        'WQI': wqi_forecast,
        'Noise': noise_forecast,
        'Health Risk': risk_forecast
    })
    
    # Create tab for forecast
    forecast_tab1, forecast_tab2 = st.tabs(["Health Risk Forecast", "Detailed Metrics"])
    
    with forecast_tab1:
        # Plot health risk forecast
        fig = px.line(
            forecast_df, 
            x='Date', 
            y='Health Risk',
            title='Projected Health Risk (7-Day Forecast)',
            markers=True
        )
        
        # Add colored background zones
        fig.add_shape(
            type="rect",
            x0=forecast_df['Date'].min(),
            x1=forecast_df['Date'].max(),
            y0=0,
            y1=25,
            fillcolor="green",
            opacity=0.2,
            layer="below",
            line_width=0,
        )
        
        fig.add_shape(
            type="rect",
            x0=forecast_df['Date'].min(),
            x1=forecast_df['Date'].max(),
            y0=25,
            y1=50,
            fillcolor="yellow",
            opacity=0.2,
            layer="below",
            line_width=0,
        )
        
        fig.add_shape(
            type="rect",
            x0=forecast_df['Date'].min(),
            x1=forecast_df['Date'].max(),
            y0=50,
            y1=75,
            fillcolor="orange",
            opacity=0.2,
            layer="below",
            line_width=0,
        )
        
        fig.add_shape(
            type="rect",
            x0=forecast_df['Date'].min(),
            x1=forecast_df['Date'].max(),
            y0=75,
            y1=100,
            fillcolor="red",
            opacity=0.2,
            layer="below",
            line_width=0,
        )
        
        fig.update_layout(
            yaxis_range=[0, 100],
            height=400,
            margin=dict(l=20, r=20, t=50, b=20),
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        st.info("This forecast is based on current trends and historical patterns. Actual conditions may vary due to weather changes, special events, or other factors.")
        
    with forecast_tab2:
        # Plot all metrics
        fig = px.line(
            forecast_df, 
            x='Date', 
            y=['AQI', 'WQI', 'Noise'],
            title='Environmental Metrics Forecast (7-Day)',
            markers=True
        )
        
        fig.update_layout(
            height=400,
            margin=dict(l=20, r=20, t=50, b=20),
            yaxis_title="Value"
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Display forecast data as a table
        st.dataframe(forecast_df.round(1), hide_index=True)

def get_risk_color(risk_value):
    """Return color based on risk value"""
    if risk_value < 20:
        return '#00E400'  # Green
    elif risk_value < 40:
        return '#AAFF00'  # Light green
    elif risk_value < 60:
        return '#FFFF00'  # Yellow
    elif risk_value < 80:
        return '#FF7E00'  # Orange
    else:
        return '#FF0000'  # Red

def get_health_index_color(index_value):
    """Return color based on health index value (0-10, 10 is best)"""
    if index_value > 8:
        return '#00E400'  # Green
    elif index_value > 6:
        return '#AAFF00'  # Light green
    elif index_value > 4:
        return '#FFFF00'  # Yellow
    elif index_value > 2:
        return '#FF7E00'  # Orange
    else:
        return '#FF0000'  # Red

if __name__ == "__main__":
    # This will be executed if the script is run directly
    st.write("This is a module that should be imported, not run directly.")
