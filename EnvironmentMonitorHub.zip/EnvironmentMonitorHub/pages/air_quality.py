import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import datetime
import sys
import os

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.data_fetcher import fetch_air_quality_data
from utils.data_processor import process_air_quality_data
from utils.visualization import create_aqi_gauge, create_pollutant_bar_chart, create_map
from data.knowledge_base import get_pollutant_info, get_health_tips

def show_air_quality_page(latitude, longitude, selected_date):
    """
    Display the air quality page with detailed air quality information
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - selected_date (datetime.date): Date to display data for
    """
    st.title("AIR QUALITY ANALYSIS")
    
    st.markdown("""
    This page provides detailed information about air quality in your selected location. 
    Air pollution can significantly impact respiratory and cardiovascular health, and understanding 
    the local air quality can help you take appropriate preventive measures.
    """)
    
    # Display a loading spinner while fetching data
    with st.spinner("Fetching air quality data..."):
        # Fetch air quality data
        air_data = fetch_air_quality_data(latitude, longitude, selected_date)
        processed_air_data = process_air_quality_data(air_data)
    
    if not processed_air_data:
        st.error("Unable to retrieve air quality data for this location and date. Please try a different location or date.")
        return
    
    # Create layout with columns
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Current Air Quality")
        
        # AQI gauge
        if 'aqi' in processed_air_data:
            aqi = processed_air_data['aqi']
            aqi_category = processed_air_data.get('aqi_category', 'Unknown')
            st.markdown(f"**Air Quality Index (AQI):** {aqi} - {aqi_category}")
            fig = create_aqi_gauge(aqi)
            st.plotly_chart(fig, use_container_width=True)
            
            # Health recommendations based on AQI
            st.subheader("Health Recommendations")
            tips = get_health_tips(aqi)
            for tip in tips:
                st.markdown(f"- {tip}")
        else:
            st.warning("AQI data unavailable for this location/date")
    
    with col2:
        st.subheader("Location")
        map_fig = create_map(latitude, longitude, air_quality=processed_air_data.get('aqi', 'N/A'))
        st.components.v1.html(map_fig._repr_html_(), height=400)
    
    # Pollutant breakdown
    st.subheader("Pollutant Breakdown")
    
    # Extract pollutant data
    pollutant_data = {
        'pm25': processed_air_data.get('pm25'),
        'pm10': processed_air_data.get('pm10'),
        'so2': processed_air_data.get('so2'),
        'no2': processed_air_data.get('no2'),
        'co': processed_air_data.get('co'),
        'o3': processed_air_data.get('o3')
    }
    
    # Create pollutant visualization
    pollutant_fig = create_pollutant_bar_chart(pollutant_data)
    st.plotly_chart(pollutant_fig, use_container_width=True)
    
    # Pollutant information
    st.subheader("Understanding Air Pollutants")
    pollutant_tabs = st.tabs(["PM2.5", "PM10", "SO2", "NO2", "CO", "O3"])
    
    with pollutant_tabs[0]:
        info = get_pollutant_info('pm25')
        st.markdown(f"### PM2.5 (Fine Particulate Matter)")
        st.markdown(f"**Current Level:** {pollutant_data['pm25']} μg/m³") if pollutant_data['pm25'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} μg/m³")
    
    with pollutant_tabs[1]:
        info = get_pollutant_info('pm10')
        st.markdown(f"### PM10 (Coarse Particulate Matter)")
        st.markdown(f"**Current Level:** {pollutant_data['pm10']} μg/m³") if pollutant_data['pm10'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} μg/m³")
    
    with pollutant_tabs[2]:
        info = get_pollutant_info('so2')
        st.markdown(f"### SO2 (Sulfur Dioxide)")
        st.markdown(f"**Current Level:** {pollutant_data['so2']} ppb") if pollutant_data['so2'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} ppb")
    
    with pollutant_tabs[3]:
        info = get_pollutant_info('no2')
        st.markdown(f"### NO2 (Nitrogen Dioxide)")
        st.markdown(f"**Current Level:** {pollutant_data['no2']} ppb") if pollutant_data['no2'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} ppb")
    
    with pollutant_tabs[4]:
        info = get_pollutant_info('co')
        st.markdown(f"### CO (Carbon Monoxide)")
        st.markdown(f"**Current Level:** {pollutant_data['co']} ppm") if pollutant_data['co'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} ppm")
    
    with pollutant_tabs[5]:
        info = get_pollutant_info('o3')
        st.markdown(f"### O3 (Ozone)")
        st.markdown(f"**Current Level:** {pollutant_data['o3']} ppb") if pollutant_data['o3'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Sources:** {info['sources']}")
        st.markdown(f"**Safe Limit:** {info['safe_limit']} ppb")
    
    # Air quality trends
    st.subheader("Air Quality Trends")
    st.info("Historical air quality data trends would be displayed here, integrated with actual historical data APIs in a production environment.")
    
    # Additional resources
    st.subheader("Additional Resources")
    st.markdown("""
    - [Central Pollution Control Board (CPCB) India](https://cpcb.nic.in/)
    - [Tamil Nadu Pollution Control Board (TNPCB)](https://tnpcb.nic.in/)
    - [World Health Organization (WHO) Air Quality Guidelines](https://www.who.int/news-room/fact-sheets/detail/ambient-(outdoor)-air-quality-and-health)
    - [OpenAQ](https://openaq.org/) - Open-source air quality data platform
    """)

if __name__ == "__main__":
    # This will be executed if the script is run directly
    st.write("This is a module that should be imported, not run directly.")
