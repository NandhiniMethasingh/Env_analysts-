import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import datetime
import sys
import os

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.data_fetcher import fetch_noise_data
from utils.data_processor import process_noise_data
from utils.visualization import create_noise_gauge, create_map
from data.knowledge_base import get_noise_health_tips

def show_noise_pollution_page(latitude, longitude, selected_date):
    """
    Display the noise pollution page with detailed noise information
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - selected_date (datetime.date): Date to display data for
    """
    st.title("NOISE POLLUTION ANALYSIS")
    
    st.markdown("""
    This page provides detailed information about noise pollution in your selected location. 
    Exposure to excessive noise can lead to various health issues including hearing loss, 
    sleep disturbance, cardiovascular effects, and decreased cognitive performance.
    """)
    
    # Display a loading spinner while fetching data
    with st.spinner("Fetching noise data..."):
        # Fetch noise data
        noise_data = fetch_noise_data(latitude, longitude, selected_date)
        processed_noise_data = process_noise_data(noise_data)
    
    if not processed_noise_data:
        st.error("Unable to retrieve noise data for this location and date. Please try a different location or date.")
        return
    
    # Create layout with columns
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Current Noise Levels")
        
        # Noise gauge
        if 'decibel' in processed_noise_data:
            decibel = processed_noise_data['decibel']
            noise_category = processed_noise_data.get('noise_category', 'Unknown')
            st.markdown(f"**Noise Level:** {decibel} dB - {noise_category}")
            fig = create_noise_gauge(decibel)
            st.plotly_chart(fig, use_container_width=True)
            
            # Health impact
            st.subheader("Health Impact")
            if 'noise_impact' in processed_noise_data:
                st.markdown(f"**{processed_noise_data['noise_impact']}**")
            
            # Health recommendations based on noise levels
            st.subheader("Health Recommendations")
            tips = get_noise_health_tips(decibel)
            for tip in tips:
                st.markdown(f"- {tip}")
        else:
            st.warning("Noise level data unavailable for this location/date")
    
    with col2:
        st.subheader("Location")
        map_fig = create_map(latitude, longitude, noise_level=processed_noise_data.get('decibel', 'N/A'))
        st.components.v1.html(map_fig._repr_html_(), height=400)
    
    # Noise reference chart
    st.subheader("Noise Level Reference Chart")
    
    # Create a reference chart for common noise levels
    noise_references = pd.DataFrame({
        'Source': [
            'Threshold of Hearing', 
            'Whisper', 
            'Quiet Library', 
            'Normal Conversation', 
            'Busy Traffic', 
            'Vacuum Cleaner', 
            'Noisy Restaurant', 
            'Power Mower', 
            'Rock Concert', 
            'Jackhammer', 
            'Jet Engine'
        ],
        'Decibel (dB)': [0, 30, 40, 60, 70, 75, 80, 90, 110, 120, 140],
        'Category': [
            'Very Low', 'Very Low', 'Low', 'Moderate', 'Moderate', 
            'Loud', 'Loud', 'Very Loud', 'Extremely Loud', 'Extremely Loud', 'Painful'
        ]
    })
    
    # Add the current noise level to the reference
    if 'decibel' in processed_noise_data:
        current_location = pd.DataFrame({
            'Source': ['Your Location'],
            'Decibel (dB)': [processed_noise_data['decibel']],
            'Category': [processed_noise_data.get('noise_category', 'Unknown')]
        })
        noise_references = pd.concat([noise_references, current_location])
    
    # Create a horizontal bar chart for noise reference
    fig = px.bar(
        noise_references, 
        y='Source', 
        x='Decibel (dB)',
        color='Category',
        title='Common Noise Levels (dB)',
        labels={'Decibel (dB)': 'Noise Level (dB)', 'Source': ''},
        orientation='h',
        height=500,
        color_discrete_map={
            'Very Low': '#00E400',
            'Low': '#AAFF00',
            'Moderate': '#FFFF00',
            'Loud': '#FF7E00',
            'Very Loud': '#FF0000',
            'Extremely Loud': '#99004C',
            'Painful': '#7E0023'
        }
    )
    
    # Highlight the current location
    if 'decibel' in processed_noise_data:
        fig.update_traces(
            marker_line_width=3,
            marker_line_color="black",
            selector=dict(name='Your Location')
        )
    
    # Set consistent x-axis range
    fig.update_layout(xaxis_range=[0, 150])
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Information about noise pollution
    st.subheader("Understanding Noise Pollution")
    
    st.markdown("""
    ### What is Noise Pollution?
    
    Noise pollution, also known as environmental noise or sound pollution, refers to the excessive amount of noise in the environment that disrupts the normal activities of humans and animals. It is typically caused by human activities such as transportation, industrial activities, construction, and various social events.
    
    ### Health Effects of Noise Pollution:
    
    1. **Hearing Problems**: Prolonged exposure to noise above 85 dB can cause hearing loss.
    
    2. **Sleep Disturbance**: Noise can interfere with sleep, leading to insomnia and poor sleep quality.
    
    3. **Cardiovascular Issues**: Studies have linked noise pollution to increased risk of hypertension, heart disease, and stroke.
    
    4. **Stress and Mental Health**: Excessive noise can trigger stress responses, anxiety, and irritability.
    
    5. **Cognitive Impairment**: Especially in children, noise can affect learning, concentration, and academic performance.
    
    6. **Tinnitus**: Exposure to loud noise can cause ringing, buzzing, or roaring in the ears.
    
    ### Noise Level Guidelines:
    
    - **Below 70 dB**: Generally considered safe for daily exposure
    - **70-85 dB**: Extended exposure may cause hearing damage
    - **Above 85 dB**: Hearing protection recommended
    - **Above 120 dB**: Can cause immediate pain and hearing damage
    
    ### Sources of Noise Pollution in Urban Areas:
    
    - **Traffic**: Road, rail, and air traffic
    - **Construction**: Building activities and heavy machinery
    - **Industrial Operations**: Factories and manufacturing plants
    - **Social Activities**: Restaurants, bars, public events
    - **Household Appliances**: Vacuum cleaners, blenders, lawn mowers
    """)
    
    # Noise trends and patterns
    st.subheader("Noise Patterns")
    st.info("Noise level patterns throughout the day would be displayed here, integrated with actual historical data in a production environment.")
    
    # Additional resources
    st.subheader("Additional Resources")
    st.markdown("""
    - [World Health Organization (WHO) Noise Guidelines](https://www.who.int/europe/publications/i/item/9789289053563)
    - [National Institute on Deafness and Other Communication Disorders (NIDCD)](https://www.nidcd.nih.gov/health/noise-induced-hearing-loss)
    - [Noise Pollution Clearinghouse](https://www.nonoise.org/)
    - [CDC - Noise and Hearing Loss Prevention](https://www.cdc.gov/niosh/topics/noise/)
    """)

if __name__ == "__main__":
    # This will be executed if the script is run directly
    st.write("This is a module that should be imported, not run directly.")
