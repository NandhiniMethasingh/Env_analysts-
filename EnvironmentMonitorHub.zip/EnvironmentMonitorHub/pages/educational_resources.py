import streamlit as st
import pandas as pd
import sys
import os

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from data.knowledge_base import (
    get_educational_content,
    get_pollutant_info,
    get_water_parameter_info,
    get_environmental_health_faq
)

def show_educational_resources_page():
    """
    Display the educational resources page with information about environmental
    health impacts and related educational content
    """
    st.title("ENVIRONMENTAL HEALTH KNOWLEDGE HUB")
    
    st.markdown("""
    Welcome to our Environmental Health Knowledge Hub. This page provides educational 
    resources to help you understand the connections between environmental quality and health,
    specifically in the context of Coimbatore, Tamil Nadu, India.
    
    Explore the sections below to learn about various pollutants, their health effects, 
    and ways to protect yourself and your community.
    """)
    
    # Create main category tabs
    category = st.radio(
        "Select a category to explore:",
        ["Air Pollution", "Water Quality", "Noise Pollution", "Health Effects", "Local Environmental Issues", "FAQ"],
        horizontal=True
    )
    
    if category == "Air Pollution":
        show_air_pollution_resources()
    elif category == "Water Quality":
        show_water_quality_resources()
    elif category == "Noise Pollution":
        show_noise_pollution_resources()
    elif category == "Health Effects":
        show_health_effects_resources()
    elif category == "Local Environmental Issues":
        show_local_environmental_issues()
    elif category == "FAQ":
        show_environmental_health_faq()

def show_air_pollution_resources():
    """Display air pollution educational resources"""
    st.header("AIR POLLUTION")
    
    st.markdown("""
    Air pollution is a significant environmental health risk in many urban areas, including Coimbatore. 
    Understanding the types, sources, and health impacts of air pollutants can help you make informed 
    decisions to protect your health.
    """)
    
    # Get educational content for air pollution
    air_content = get_educational_content("air_pollution")
    
    # Air quality index explanation
    st.subheader("Understanding Air Quality Index (AQI)")
    
    st.markdown(air_content["aqi_explanation"])
    
    # Create AQI reference table
    aqi_df = pd.DataFrame({
        'AQI Range': ['0-50', '51-100', '101-150', '151-200', '201-300', '301-500'],
        'Category': ['Good', 'Moderate', 'Unhealthy for Sensitive Groups', 'Unhealthy', 'Very Unhealthy', 'Hazardous'],
        'Color': ['Green', 'Yellow', 'Orange', 'Red', 'Purple', 'Maroon'],
        'Health Implications': [
            'Air quality is satisfactory, and air pollution poses little or no risk.',
            'Air quality is acceptable, but there may be a risk for some people, particularly those who are unusually sensitive to air pollution.',
            'Members of sensitive groups may experience health effects. The general public is less likely to be affected.',
            'Some members of the general public may experience health effects; members of sensitive groups may experience more serious health effects.',
            'Health alert: The risk of health effects is increased for everyone.',
            'Health warning of emergency conditions: everyone is more likely to be affected.'
        ]
    })
    
    st.dataframe(aqi_df, hide_index=True)
    
    # Common air pollutants
    st.subheader("Common Air Pollutants")
    
    pollutant_tabs = st.tabs(["PM2.5", "PM10", "SO2", "NO2", "CO", "O3"])
    
    with pollutant_tabs[0]:
        pollutant_info = get_pollutant_info('pm25')
        st.markdown(f"### PM2.5 (Fine Particulate Matter)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} μg/m³")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    with pollutant_tabs[1]:
        pollutant_info = get_pollutant_info('pm10')
        st.markdown(f"### PM10 (Coarse Particulate Matter)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} μg/m³")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    with pollutant_tabs[2]:
        pollutant_info = get_pollutant_info('so2')
        st.markdown(f"### SO2 (Sulfur Dioxide)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} ppb")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    with pollutant_tabs[3]:
        pollutant_info = get_pollutant_info('no2')
        st.markdown(f"### NO2 (Nitrogen Dioxide)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} ppb")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    with pollutant_tabs[4]:
        pollutant_info = get_pollutant_info('co')
        st.markdown(f"### CO (Carbon Monoxide)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} ppm")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    with pollutant_tabs[5]:
        pollutant_info = get_pollutant_info('o3')
        st.markdown(f"### O3 (Ozone)")
        st.markdown(f"**Description:** {pollutant_info['description']}")
        st.markdown(f"**Health Effects:** {pollutant_info['health_effects']}")
        st.markdown(f"**Sources:** {pollutant_info['sources']}")
        st.markdown(f"**Safe Limit:** {pollutant_info['safe_limit']} ppb")
        st.markdown(f"**Protection Measures:** {pollutant_info['protection_measures']}")
    
    # Air pollution in Coimbatore
    st.subheader("Air Pollution in Coimbatore")
    
    st.markdown(air_content["coimbatore_air_quality"])
    
    # Protection measures
    st.subheader("How to Protect Yourself from Air Pollution")
    
    st.markdown(air_content["protection_measures"])
    
    # Resources and references
    st.subheader("Additional Resources")
    
    st.markdown("""
    - [Central Pollution Control Board (CPCB) India](https://cpcb.nic.in/)
    - [Tamil Nadu Pollution Control Board (TNPCB)](https://tnpcb.nic.in/)
    - [World Health Organization (WHO) Air Quality Guidelines](https://www.who.int/news-room/fact-sheets/detail/ambient-(outdoor)-air-quality-and-health)
    - [OpenAQ](https://openaq.org/) - Open-source air quality data platform
    - [AirNow International](https://www.airnow.gov/international/us-embassies-and-consulates/)
    """)

def show_water_quality_resources():
    """Display water quality educational resources"""
    st.header("WATER QUALITY")
    
    st.markdown("""
    Water quality is essential for human health and ecosystem functioning. In Coimbatore, 
    water quality varies across different areas and is affected by various natural and human factors.
    """)
    
    # Get educational content for water quality
    water_content = get_educational_content("water_quality")
    
    # Water quality index explanation
    st.subheader("Understanding Water Quality Index (WQI)")
    
    st.markdown(water_content["wqi_explanation"])
    
    # Create WQI reference table
    wqi_df = pd.DataFrame({
        'WQI Range': ['91-100', '71-90', '51-70', '26-50', '0-25'],
        'Category': ['Excellent', 'Good', 'Medium', 'Bad', 'Very Bad'],
        'Water Quality': ['Water is suitable for all purposes, including drinking with conventional treatment.',
                         'Water is slightly polluted but suitable for most purposes after treatment.',
                         'Water is moderately polluted and requires adequate treatment.',
                         'Water is highly polluted and suitable only for industrial use after treatment.',
                         'Water is severely polluted and unsuitable for most purposes.']
    })
    
    st.dataframe(wqi_df, hide_index=True)
    
    # Water quality parameters
    st.subheader("Important Water Quality Parameters")
    
    param_tabs = st.tabs(["pH", "Dissolved Oxygen", "BOD", "COD", "TDS", "Turbidity"])
    
    with param_tabs[0]:
        param_info = get_water_parameter_info('ph')
        st.markdown(f"### pH")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    with param_tabs[1]:
        param_info = get_water_parameter_info('do')
        st.markdown(f"### Dissolved Oxygen (DO)")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    with param_tabs[2]:
        param_info = get_water_parameter_info('bod')
        st.markdown(f"### Biochemical Oxygen Demand (BOD)")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    with param_tabs[3]:
        param_info = get_water_parameter_info('cod')
        st.markdown(f"### Chemical Oxygen Demand (COD)")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    with param_tabs[4]:
        param_info = get_water_parameter_info('tds')
        st.markdown(f"### Total Dissolved Solids (TDS)")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    with param_tabs[5]:
        param_info = get_water_parameter_info('turbidity')
        st.markdown(f"### Turbidity")
        st.markdown(f"**Description:** {param_info['description']}")
        st.markdown(f"**Significance:** {param_info['significance']}")
        st.markdown(f"**Health Effects:** {param_info['health_effects']}")
        st.markdown(f"**Optimal Range:** {param_info['optimal_range']}")
    
    # Water quality in Coimbatore
    st.subheader("Water Quality in Coimbatore")
    
    st.markdown(water_content["coimbatore_water_quality"])
    
    # Water-borne diseases
    st.subheader("Common Water-borne Diseases")
    
    st.markdown(water_content["waterborne_diseases"])
    
    # Water treatment methods
    st.subheader("Water Treatment Methods for Homes")
    
    st.markdown(water_content["water_treatment_methods"])
    
    # Resources and references
    st.subheader("Additional Resources")
    
    st.markdown("""
    - [Central Pollution Control Board (CPCB) Water Quality Monitoring](https://cpcb.nic.in/water-quality-data/)
    - [Tamil Nadu Water Supply and Drainage Board (TWAD Board)](https://twadboard.tn.gov.in/)
    - [World Health Organization (WHO) Water Quality Guidelines](https://www.who.int/water_sanitation_health/water-quality/guidelines/en/)
    - [Ministry of Jal Shakti, Department of Water Resources](http://mowr.gov.in/)
    - [Indian Water Portal](https://www.indiawaterportal.org/)
    """)

def show_noise_pollution_resources():
    """Display noise pollution educational resources"""
    st.header("NOISE POLLUTION")
    
    st.markdown("""
    Noise pollution is an often overlooked environmental health hazard, particularly in urban areas like Coimbatore.
    Excessive noise can lead to various health issues from sleep disturbance to cardiovascular effects.
    """)
    
    # Get educational content for noise pollution
    noise_content = get_educational_content("noise_pollution")
    
    # Noise levels explanation
    st.subheader("Understanding Noise Levels")
    
    st.markdown(noise_content["noise_levels_explanation"])
    
    # Create noise level reference table
    noise_df = pd.DataFrame({
        'Decibel Range (dB)': ['0-30', '31-45', '46-55', '56-65', '66-75', '76-85', '86-120', '121+'],
        'Category': ['Very Low', 'Low', 'Moderate', 'Noticeable', 'Loud', 'Very Loud', 'Extremely Loud', 'Painful'],
        'Examples': [
            'Whisper, rustling leaves', 
            'Quiet library, soft music',
            'Normal conversation, quiet office',
            'Regular talking, busy restaurant',
            'Busy traffic, vacuum cleaner',
            'Heavy traffic, noisy restaurant',
            'Factory noise, power tools, rock concert',
            'Jet engine, gunshot, explosion'
        ],
        'Health Impact': [
            'No impact',
            'Minimal impact',
            'May cause mild annoyance',
            'May interfere with rest and conversation',
            'May cause stress and sleep disturbance',
            'May cause hearing damage with prolonged exposure',
            'Can cause hearing damage even with brief exposure',
            'Immediate pain and potential hearing damage'
        ]
    })
    
    st.dataframe(noise_df, hide_index=True)
    
    # Health effects of noise pollution
    st.subheader("Health Effects of Noise Pollution")
    
    st.markdown(noise_content["health_effects"])
    
    # Noise pollution in Coimbatore
    st.subheader("Noise Pollution in Coimbatore")
    
    st.markdown(noise_content["coimbatore_noise_pollution"])
    
    # Noise protection measures
    st.subheader("How to Protect Yourself from Noise Pollution")
    
    st.markdown(noise_content["protection_measures"])
    
    # Noise pollution regulations
    st.subheader("Noise Pollution Regulations in India")
    
    st.markdown(noise_content["regulations"])
    
    # Resources and references
    st.subheader("Additional Resources")
    
    st.markdown("""
    - [Central Pollution Control Board (CPCB) Noise Standards](https://cpcb.nic.in/ambient-noise-standards/)
    - [World Health Organization (WHO) Noise Guidelines](https://www.who.int/europe/publications/i/item/9789289053563)
    - [National Institute on Deafness and Other Communication Disorders (NIDCD)](https://www.nidcd.nih.gov/health/noise-induced-hearing-loss)
    - [The Noise Pollution (Regulation and Control) Rules, 2000](http://moef.gov.in/wp-content/uploads/2017/08/noise-pollution-rules-en.pdf)
    """)

def show_health_effects_resources():
    """Display health effects educational resources"""
    st.header("ENVIRONMENTAL HEALTH EFFECTS")
    
    st.markdown("""
    Environmental factors can significantly impact human health. This section explores the various ways 
    in which air, water, and noise pollution can affect your health, both in the short and long term.
    """)
    
    # Get educational content for health effects
    health_content = get_educational_content("health_effects")
    
    # Vulnerable populations
    st.subheader("Vulnerable Populations")
    
    st.markdown(health_content["vulnerable_populations"])
    
    # Create a table for vulnerable groups
    vulnerable_df = pd.DataFrame({
        'Group': ['Children', 'Elderly', 'Pregnant Women', 'People with Pre-existing Conditions', 'Outdoor Workers'],
        'Vulnerability Factors': [
            'Developing respiratory and immune systems, higher breathing rate relative to body size, more time spent outdoors',
            'Weakened immune systems, pre-existing health conditions, reduced ability to detoxify pollutants',
            'Changes in immune function, increased oxygen demands, potential impacts on fetal development',
            'Compromised respiratory, cardiovascular, or immune systems',
            'Prolonged exposure to outdoor air pollution and extreme temperatures'
        ]
    })
    
    st.dataframe(vulnerable_df, hide_index=True)
    
    # Short-term vs. long-term health effects
    st.subheader("Short-term vs. Long-term Health Effects")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Short-term Effects")
        st.markdown(health_content["short_term_effects"])
    
    with col2:
        st.markdown("#### Long-term Effects")
        st.markdown(health_content["long_term_effects"])
    
    # Respiratory health effects
    st.subheader("Respiratory Health Effects")
    
    st.markdown(health_content["respiratory_effects"])
    
    # Cardiovascular health effects
    st.subheader("Cardiovascular Health Effects")
    
    st.markdown(health_content["cardiovascular_effects"])
    
    # Other health effects
    st.subheader("Other Health Effects")
    
    st.markdown(health_content["other_health_effects"])
    
    # Preventive measures
    st.subheader("Preventive Measures")
    
    st.markdown(health_content["preventive_measures"])
    
    # Resources and references
    st.subheader("Additional Resources")
    
    st.markdown("""
    - [World Health Organization (WHO) - Environmental Health](https://www.who.int/health-topics/environmental-health)
    - [Centers for Disease Control and Prevention (CDC) - Environmental Health](https://www.cdc.gov/environmental/index.html)
    - [National Health Portal of India](https://www.nhp.gov.in/)
    - [Environmental Health Perspectives Journal](https://ehp.niehs.nih.gov/)
    - [American Lung Association](https://www.lung.org/clean-air)
    """)

def show_local_environmental_issues():
    """Display information about local environmental issues in Coimbatore"""
    st.header("LOCAL ENVIRONMENTAL ISSUES")
    
    st.markdown("""
    Coimbatore, one of Tamil Nadu's major industrial cities, faces several environmental challenges.
    Understanding these local issues can help residents make more informed decisions about their health and well-being.
    """)
    
    # Get educational content for local issues
    local_content = get_educational_content("local_issues")
    
    # Industrial pollution
    st.subheader("Industrial Pollution")
    
    st.markdown(local_content["industrial_pollution"])
    
    # Water body pollution
    st.subheader("Water Body Pollution")
    
    st.markdown(local_content["water_body_pollution"])
    
    # Traffic and vehicular pollution
    st.subheader("Traffic and Vehicular Pollution")
    
    st.markdown(local_content["traffic_pollution"])
    
    # Urban development and green spaces
    st.subheader("Urban Development and Green Spaces")
    
    st.markdown(local_content["urban_development"])
    
    # Seasonal environmental variations
    st.subheader("Seasonal Environmental Variations")
    
    st.markdown(local_content["seasonal_variations"])
    
    # Community initiatives
    st.subheader("Community Environmental Initiatives")
    
    st.markdown(local_content["community_initiatives"])
    
    # Government actions
    st.subheader("Government Actions and Policies")
    
    st.markdown(local_content["government_actions"])
    
    # Resources and references
    st.subheader("Local Resources")
    
    st.markdown("""
    - [Coimbatore City Municipal Corporation](https://ccmc.gov.in/)
    - [Tamil Nadu Pollution Control Board - Coimbatore](https://tnpcb.nic.in/coimbatore/)
    - [Siruthuli](http://www.siruthuli.com/) - Local environmental NGO
    - [Residents Awareness Association of Coimbatore (RAAC)](https://www.raac.co.in/)
    - [The Kovai Medical Center and Hospital (KMCH) - Environmental Health Department](https://www.kmchhospitals.com/)
    """)

def show_environmental_health_faq():
    """Display frequently asked questions about environmental health"""
    st.header("FREQUENTLY ASKED QUESTIONS")
    
    st.markdown("""
    Find answers to common questions about environmental health concerns specific to Coimbatore and general environmental health topics.
    """)
    
    # Get FAQ content
    faq_list = get_environmental_health_faq()
    
    # Create expandable sections for each FAQ
    for i, faq in enumerate(faq_list):
        with st.expander(faq["question"]):
            st.markdown(faq["answer"])
            if "source" in faq and faq["source"]:
                st.markdown(f"**Source:** {faq['source']}")

if __name__ == "__main__":
    # This will be executed if the script is run directly
    st.write("This is a module that should be imported, not run directly.")
