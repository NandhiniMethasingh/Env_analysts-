import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import datetime
import sys
import os

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.data_fetcher import fetch_water_quality_data
from utils.data_processor import process_water_quality_data
from utils.visualization import create_wqi_gauge, create_map
from data.knowledge_base import get_water_parameter_info, get_water_health_tips

def show_water_quality_page(latitude, longitude, selected_date):
    """
    Display the water quality page with detailed water quality information
    
    Parameters:
    - latitude (float): Latitude coordinate
    - longitude (float): Longitude coordinate
    - selected_date (datetime.date): Date to display data for
    """
    st.title("WATER QUALITY ANALYSIS")
    
    st.markdown("""
    This page provides detailed information about water quality in your selected location. 
    Water quality affects both health and the environment. Clean, safe water is essential for 
    drinking, recreation, and supporting healthy aquatic ecosystems.
    """)
    
    # Display a loading spinner while fetching data
    with st.spinner("Fetching water quality data..."):
        # Fetch water quality data
        water_data = fetch_water_quality_data(latitude, longitude, selected_date)
        processed_water_data = process_water_quality_data(water_data)
    
    if not processed_water_data:
        st.error("Unable to retrieve water quality data for this location and date. Please try a different location or date.")
        return
    
    # Create layout with columns
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Current Water Quality")
        
        # WQI gauge
        if 'wqi' in processed_water_data:
            wqi = processed_water_data['wqi']
            wqi_category = processed_water_data.get('wqi_category', 'Unknown')
            st.markdown(f"**Water Quality Index (WQI):** {wqi} - {wqi_category}")
            fig = create_wqi_gauge(wqi)
            st.plotly_chart(fig, use_container_width=True)
            
            # Health recommendations based on WQI
            st.subheader("Health Recommendations")
            tips = get_water_health_tips(wqi)
            for tip in tips:
                st.markdown(f"- {tip}")
        else:
            st.warning("WQI data unavailable for this location/date")
    
    with col2:
        st.subheader("Location")
        map_fig = create_map(latitude, longitude, water_quality=processed_water_data.get('wqi', 'N/A'))
        st.components.v1.html(map_fig._repr_html_(), height=400)
    
    # Water parameter breakdown
    st.subheader("Water Quality Parameters")
    
    # Extract water quality parameters
    params = {
        'pH': processed_water_data.get('ph'),
        'Dissolved Oxygen (DO)': processed_water_data.get('do'),
        'Biochemical Oxygen Demand (BOD)': processed_water_data.get('bod'),
        'Chemical Oxygen Demand (COD)': processed_water_data.get('cod'),
        'Total Dissolved Solids (TDS)': processed_water_data.get('tds'),
        'Turbidity': processed_water_data.get('turbidity')
    }
    
    # Create a dataframe for the parameters
    if any(params.values()):
        param_df = pd.DataFrame({
            'Parameter': list(params.keys()),
            'Value': list(params.values()),
            'Unit': ['', 'mg/L', 'mg/L', 'mg/L', 'mg/L', 'NTU']
        })
        
        # Display as a table
        st.dataframe(param_df, hide_index=True)
        
        # Create a simple bar chart for parameters
        fig = px.bar(
            param_df, 
            x='Parameter', 
            y='Value',
            color='Parameter',
            title='Water Quality Parameters',
            labels={'Value': 'Concentration', 'Parameter': ''},
            height=400
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Detailed water quality parameters are not available for this location/date")
    
    # Water quality parameter information
    st.subheader("Understanding Water Quality Parameters")
    param_tabs = st.tabs(["pH", "Dissolved Oxygen", "BOD", "COD", "TDS", "Turbidity"])
    
    with param_tabs[0]:
        info = get_water_parameter_info('ph')
        st.markdown(f"### pH")
        st.markdown(f"**Current Level:** {params['pH']}") if params['pH'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    with param_tabs[1]:
        info = get_water_parameter_info('do')
        st.markdown(f"### Dissolved Oxygen (DO)")
        st.markdown(f"**Current Level:** {params['Dissolved Oxygen (DO)']} mg/L") if params['Dissolved Oxygen (DO)'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    with param_tabs[2]:
        info = get_water_parameter_info('bod')
        st.markdown(f"### Biochemical Oxygen Demand (BOD)")
        st.markdown(f"**Current Level:** {params['Biochemical Oxygen Demand (BOD)']} mg/L") if params['Biochemical Oxygen Demand (BOD)'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    with param_tabs[3]:
        info = get_water_parameter_info('cod')
        st.markdown(f"### Chemical Oxygen Demand (COD)")
        st.markdown(f"**Current Level:** {params['Chemical Oxygen Demand (COD)']} mg/L") if params['Chemical Oxygen Demand (COD)'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    with param_tabs[4]:
        info = get_water_parameter_info('tds')
        st.markdown(f"### Total Dissolved Solids (TDS)")
        st.markdown(f"**Current Level:** {params['Total Dissolved Solids (TDS)']} mg/L") if params['Total Dissolved Solids (TDS)'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    with param_tabs[5]:
        info = get_water_parameter_info('turbidity')
        st.markdown(f"### Turbidity")
        st.markdown(f"**Current Level:** {params['Turbidity']} NTU") if params['Turbidity'] else st.markdown("**Current Level:** Not available")
        st.markdown(f"**Description:** {info['description']}")
        st.markdown(f"**Significance:** {info['significance']}")
        st.markdown(f"**Health Effects:** {info['health_effects']}")
        st.markdown(f"**Optimal Range:** {info['optimal_range']}")
    
    # Water quality trends
    st.subheader("Water Quality Trends")
    st.info("Historical water quality data trends would be displayed here, integrated with actual historical data APIs in a production environment.")
    
    # Additional resources
    st.subheader("Additional Resources")
    st.markdown("""
    - [Central Pollution Control Board (CPCB) Water Quality Monitoring](https://cpcb.nic.in/water-quality-data/)
    - [Tamil Nadu Water Supply and Drainage Board (TWAD Board)](https://twadboard.tn.gov.in/)
    - [Central Water Commission (CWC)](https://cwc.gov.in/)
    - [World Health Organization (WHO) Water Quality Guidelines](https://www.who.int/water_sanitation_health/water-quality/guidelines/en/)
    """)

if __name__ == "__main__":
    # This will be executed if the script is run directly
    st.write("This is a module that should be imported, not run directly.")
