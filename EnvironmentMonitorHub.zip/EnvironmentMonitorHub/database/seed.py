"""
Seed the database with initial data
"""
import logging
import datetime
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from database.connection import get_session, close_session, init_db
from database.models import Location, AirQualityReading, WaterQualityReading, NoiseReading
from data.locations import STATES_DATA, get_all_cities

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed_locations():
    """Seed the database with locations from the locations module"""
    session = get_session()
    try:
        cities = get_all_cities()
        count = 0
        
        for city_name, state_name, latitude, longitude, description in cities:
            # Check if location already exists
            existing = session.query(Location).filter(
                Location.name == city_name,
                Location.state == state_name
            ).first()
            
            if existing:
                logger.info(f"Location '{city_name}, {state_name}' already exists, skipping.")
                continue
            
            # Create new location
            location = Location(
                name=city_name,
                state=state_name,
                latitude=latitude,
                longitude=longitude,
                description=description,
                created_at=datetime.datetime.utcnow(),
                updated_at=datetime.datetime.utcnow()
            )
            
            session.add(location)
            count += 1
            
            # Commit in batches to avoid long transactions
            if count % 10 == 0:
                session.commit()
                logger.info(f"Added {count} locations so far...")
        
        # Final commit for any remaining locations
        session.commit()
        logger.info(f"Successfully seeded {count} locations")
        return count
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error seeding locations: {str(e)}")
        return 0
    finally:
        close_session(session)

def seed_sample_readings():
    """Seed the database with sample environmental readings for demonstration"""
    from data.synthetic_data import (
        generate_air_quality_data,
        generate_water_quality_data,
        generate_noise_data
    )
    
    session = get_session()
    try:
        # Get all locations
        locations = session.query(Location).all()
        count_air = 0
        count_water = 0
        count_noise = 0
        
        # Current date
        today = datetime.datetime.utcnow().date()
        
        # Generate readings for the last 7 days
        for days_ago in range(7, 0, -1):
            date = today - datetime.timedelta(days=days_ago)
            date_time = datetime.datetime.combine(date, datetime.time(12, 0))  # Noon
            
            for location in locations:
                # Generate synthetic data
                air_data = generate_air_quality_data(
                    location.latitude, location.longitude, date, location.state
                )
                
                water_data = generate_water_quality_data(
                    location.latitude, location.longitude, date, location.state
                )
                
                noise_data = generate_noise_data(
                    location.latitude, location.longitude, date, location.state
                )
                
                # Create air quality reading
                if air_data and 'aqi' in air_data:
                    air_reading = AirQualityReading(
                        location_id=location.id,
                        reading_date=date_time,
                        aqi=air_data.get('aqi'),
                        pm25=air_data.get('pm25'),
                        pm10=air_data.get('pm10'),
                        so2=air_data.get('so2'),
                        no2=air_data.get('no2'),
                        co=air_data.get('co'),
                        o3=air_data.get('o3'),
                        source='synthetic',
                        notes='Initial seeded data'
                    )
                    session.add(air_reading)
                    count_air += 1
                
                # Create water quality reading
                if water_data and 'wqi' in water_data:
                    water_reading = WaterQualityReading(
                        location_id=location.id,
                        reading_date=date_time,
                        wqi=water_data.get('wqi'),
                        ph=water_data.get('ph'),
                        do=water_data.get('do'),
                        bod=water_data.get('bod'),
                        cod=water_data.get('cod'),
                        tds=water_data.get('tds'),
                        turbidity=water_data.get('turbidity'),
                        source='synthetic',
                        notes='Initial seeded data'
                    )
                    session.add(water_reading)
                    count_water += 1
                
                # Create noise reading
                if noise_data and 'decibel' in noise_data:
                    noise_reading = NoiseReading(
                        location_id=location.id,
                        reading_date=date_time,
                        decibel=noise_data.get('decibel'),
                        category=noise_data.get('category'),
                        source='synthetic',
                        notes='Initial seeded data'
                    )
                    session.add(noise_reading)
                    count_noise += 1
                
                # Commit every 20 locations to avoid large transactions
                if (count_air + count_water + count_noise) % 60 == 0:
                    session.commit()
                    logger.info(f"Seeded readings for {count_air // 7} locations so far...")
        
        # Final commit
        session.commit()
        logger.info(f"Successfully seeded {count_air} air readings, {count_water} water readings, and {count_noise} noise readings")
        return count_air, count_water, count_noise
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error seeding sample readings: {str(e)}")
        return 0, 0, 0
    finally:
        close_session(session)

def run_seeding():
    """Initialize the database and run all seeding operations"""
    try:
        # Initialize database
        init_db()
        logger.info("Database initialized")
        
        # Seed locations
        loc_count = seed_locations()
        logger.info(f"Seeded {loc_count} locations")
        
        # Seed sample readings
        air_count, water_count, noise_count = seed_sample_readings()
        logger.info(f"Seeded {air_count} air readings, {water_count} water readings, and {noise_count} noise readings")
        
        logger.info("Database seeding completed successfully")
        return True
    except Exception as e:
        logger.error(f"Error during database seeding: {str(e)}")
        return False

if __name__ == "__main__":
    run_seeding()