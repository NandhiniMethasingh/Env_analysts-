"""
Database connection and session management module
"""
import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.ext.declarative import declarative_base

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get database connection string from environment variable
DATABASE_URL = os.environ.get("DATABASE_URL")

if not DATABASE_URL:
    logger.warning("DATABASE_URL environment variable not set. Using SQLite as fallback.")
    DATABASE_URL = "sqlite:///environmental_monitor.db"

# Create engine
engine = create_engine(DATABASE_URL)

# Create session factory
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

# Create base class for declarative models
Base = declarative_base()

def init_db():
    """Initialize the database by creating all tables"""
    try:
        # Import all models to ensure they're registered with Base
        from database.models import User, AirQualityReading, WaterQualityReading, NoiseReading, UserFeedback, Location
        
        # Create all tables
        Base.metadata.create_all(engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        raise

def get_session():
    """Get a new database session"""
    return Session()

def close_session(session):
    """Close a database session"""
    if session:
        session.close()