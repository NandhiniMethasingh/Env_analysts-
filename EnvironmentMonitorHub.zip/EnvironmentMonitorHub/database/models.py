"""
Database models for the Environmental Monitoring application
"""
import datetime
from sqlalchemy import Column, Integer, Float, String, Text, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from database.connection import Base

class Location(Base):
    """Model representing geographic locations monitored in the system"""
    __tablename__ = 'locations'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    state = Column(String(50), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # Relationships
    air_readings = relationship("AirQualityReading", back_populates="location")
    water_readings = relationship("WaterQualityReading", back_populates="location")
    noise_readings = relationship("NoiseReading", back_populates="location")
    
    def __repr__(self):
        return f"<Location(id={self.id}, name='{self.name}', state='{self.state}')>"

class AirQualityReading(Base):
    """Model for air quality measurements"""
    __tablename__ = 'air_quality_readings'
    
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey('locations.id'))
    reading_date = Column(DateTime, default=datetime.datetime.utcnow)
    aqi = Column(Float)
    pm25 = Column(Float)
    pm10 = Column(Float)
    so2 = Column(Float)
    no2 = Column(Float)
    co = Column(Float)
    o3 = Column(Float)
    source = Column(String(50))
    notes = Column(Text)
    
    # Relationships
    location = relationship("Location", back_populates="air_readings")
    
    def __repr__(self):
        return f"<AirQualityReading(id={self.id}, aqi={self.aqi}, date='{self.reading_date}')>"

class WaterQualityReading(Base):
    """Model for water quality measurements"""
    __tablename__ = 'water_quality_readings'
    
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey('locations.id'))
    reading_date = Column(DateTime, default=datetime.datetime.utcnow)
    wqi = Column(Float)
    ph = Column(Float)
    do = Column(Float)  # Dissolved Oxygen
    bod = Column(Float)  # Biochemical Oxygen Demand
    cod = Column(Float)  # Chemical Oxygen Demand
    tds = Column(Float)  # Total Dissolved Solids
    turbidity = Column(Float)
    source = Column(String(50))
    notes = Column(Text)
    
    # Relationships
    location = relationship("Location", back_populates="water_readings")
    
    def __repr__(self):
        return f"<WaterQualityReading(id={self.id}, wqi={self.wqi}, date='{self.reading_date}')>"

class NoiseReading(Base):
    """Model for noise level measurements"""
    __tablename__ = 'noise_readings'
    
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey('locations.id'))
    reading_date = Column(DateTime, default=datetime.datetime.utcnow)
    decibel = Column(Float)
    category = Column(String(50))
    source = Column(String(50))
    notes = Column(Text)
    
    # Relationships
    location = relationship("Location", back_populates="noise_readings")
    
    def __repr__(self):
        return f"<NoiseReading(id={self.id}, decibel={self.decibel}, date='{self.reading_date}')>"

class User(Base):
    """Model for application users"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), nullable=False, unique=True)
    email = Column(String(100), nullable=False, unique=True)
    password_hash = Column(String(256), nullable=False)
    first_name = Column(String(50))
    last_name = Column(String(50))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)
    
    # Relationships
    feedbacks = relationship("UserFeedback", back_populates="user")
    
    def __repr__(self):
        return f"<User(id={self.id}, username='{self.username}')>"

class UserFeedback(Base):
    """Model for user feedback and reports"""
    __tablename__ = 'user_feedbacks'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    location_id = Column(Integer, ForeignKey('locations.id'))
    feedback_type = Column(String(50), nullable=False)  # 'air', 'water', 'noise', 'general'
    feedback_text = Column(Text, nullable=False)
    rating = Column(Integer)  # Optional rating (1-5)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="feedbacks")
    
    def __repr__(self):
        return f"<UserFeedback(id={self.id}, type='{self.feedback_type}', date='{self.created_at}')>"