"""
CRUD operations for the environmental monitoring database
"""
import logging
import datetime
from sqlalchemy.exc import SQLAlchemyError
from database.connection import get_session, close_session
from database.models import (
    Location, 
    AirQualityReading, 
    WaterQualityReading, 
    NoiseReading, 
    User, 
    UserFeedback
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============== Location operations ===============

def add_location(name, state, latitude, longitude, description=None):
    """Add a new location to the database"""
    session = get_session()
    try:
        location = Location(
            name=name,
            state=state,
            latitude=latitude,
            longitude=longitude,
            description=description
        )
        session.add(location)
        session.commit()
        logger.info(f"Added new location: {name}, {state}")
        return location.id
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error adding location: {str(e)}")
        return None
    finally:
        close_session(session)

def get_location_by_id(location_id):
    """Get a location by its ID"""
    session = get_session()
    try:
        location = session.query(Location).filter(Location.id == location_id).first()
        return location
    except SQLAlchemyError as e:
        logger.error(f"Error getting location: {str(e)}")
        return None
    finally:
        close_session(session)

def get_locations_by_state(state):
    """Get all locations in a specific state"""
    session = get_session()
    try:
        locations = session.query(Location).filter(Location.state == state).all()
        return locations
    except SQLAlchemyError as e:
        logger.error(f"Error getting locations by state: {str(e)}")
        return []
    finally:
        close_session(session)

def get_nearest_location(latitude, longitude, max_distance=None):
    """Get the nearest monitoring location to the given coordinates"""
    session = get_session()
    try:
        # SQL Alchemy doesn't support geospatial queries directly,
        # but we can approximate using a basic formula
        from math import sqrt, pow
        
        # Get all locations
        locations = session.query(Location).all()
        
        nearest_location = None
        min_distance = float('inf')
        
        for loc in locations:
            # Calculate Euclidean distance (simplified)
            distance = sqrt(pow(loc.latitude - latitude, 2) + pow(loc.longitude - longitude, 2))
            
            if distance < min_distance:
                min_distance = distance
                nearest_location = loc
                
            if max_distance and min_distance <= max_distance:
                break
                
        return nearest_location
    except SQLAlchemyError as e:
        logger.error(f"Error finding nearest location: {str(e)}")
        return None
    finally:
        close_session(session)

# =============== Air Quality operations ===============

def add_air_quality_reading(location_id, aqi, pm25=None, pm10=None, so2=None, 
                           no2=None, co=None, o3=None, source=None, 
                           reading_date=None, notes=None):
    """Add a new air quality reading to the database"""
    session = get_session()
    try:
        reading = AirQualityReading(
            location_id=location_id,
            reading_date=reading_date or datetime.datetime.utcnow(),
            aqi=aqi,
            pm25=pm25,
            pm10=pm10,
            so2=so2,
            no2=no2,
            co=co,
            o3=o3,
            source=source,
            notes=notes
        )
        session.add(reading)
        session.commit()
        logger.info(f"Added new air quality reading for location {location_id}")
        return reading.id
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error adding air quality reading: {str(e)}")
        return None
    finally:
        close_session(session)

def get_latest_air_quality(location_id):
    """Get the latest air quality reading for a location"""
    session = get_session()
    try:
        reading = session.query(AirQualityReading)\
            .filter(AirQualityReading.location_id == location_id)\
            .order_by(AirQualityReading.reading_date.desc())\
            .first()
        return reading
    except SQLAlchemyError as e:
        logger.error(f"Error getting latest air quality: {str(e)}")
        return None
    finally:
        close_session(session)

def get_air_quality_history(location_id, days=7):
    """Get historical air quality readings for a location"""
    session = get_session()
    try:
        start_date = datetime.datetime.utcnow() - datetime.timedelta(days=days)
        readings = session.query(AirQualityReading)\
            .filter(AirQualityReading.location_id == location_id)\
            .filter(AirQualityReading.reading_date >= start_date)\
            .order_by(AirQualityReading.reading_date.asc())\
            .all()
        return readings
    except SQLAlchemyError as e:
        logger.error(f"Error getting air quality history: {str(e)}")
        return []
    finally:
        close_session(session)

# =============== Water Quality operations ===============

def add_water_quality_reading(location_id, wqi, ph=None, do=None, bod=None, 
                             cod=None, tds=None, turbidity=None, source=None, 
                             reading_date=None, notes=None):
    """Add a new water quality reading to the database"""
    session = get_session()
    try:
        reading = WaterQualityReading(
            location_id=location_id,
            reading_date=reading_date or datetime.datetime.utcnow(),
            wqi=wqi,
            ph=ph,
            do=do,
            bod=bod,
            cod=cod,
            tds=tds,
            turbidity=turbidity,
            source=source,
            notes=notes
        )
        session.add(reading)
        session.commit()
        logger.info(f"Added new water quality reading for location {location_id}")
        return reading.id
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error adding water quality reading: {str(e)}")
        return None
    finally:
        close_session(session)

def get_latest_water_quality(location_id):
    """Get the latest water quality reading for a location"""
    session = get_session()
    try:
        reading = session.query(WaterQualityReading)\
            .filter(WaterQualityReading.location_id == location_id)\
            .order_by(WaterQualityReading.reading_date.desc())\
            .first()
        return reading
    except SQLAlchemyError as e:
        logger.error(f"Error getting latest water quality: {str(e)}")
        return None
    finally:
        close_session(session)

def get_water_quality_history(location_id, days=7):
    """Get historical water quality readings for a location"""
    session = get_session()
    try:
        start_date = datetime.datetime.utcnow() - datetime.timedelta(days=days)
        readings = session.query(WaterQualityReading)\
            .filter(WaterQualityReading.location_id == location_id)\
            .filter(WaterQualityReading.reading_date >= start_date)\
            .order_by(WaterQualityReading.reading_date.asc())\
            .all()
        return readings
    except SQLAlchemyError as e:
        logger.error(f"Error getting water quality history: {str(e)}")
        return []
    finally:
        close_session(session)

# =============== Noise Reading operations ===============

def add_noise_reading(location_id, decibel, category=None, source=None, 
                     reading_date=None, notes=None):
    """Add a new noise level reading to the database"""
    session = get_session()
    try:
        reading = NoiseReading(
            location_id=location_id,
            reading_date=reading_date or datetime.datetime.utcnow(),
            decibel=decibel,
            category=category,
            source=source,
            notes=notes
        )
        session.add(reading)
        session.commit()
        logger.info(f"Added new noise level reading for location {location_id}")
        return reading.id
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error adding noise reading: {str(e)}")
        return None
    finally:
        close_session(session)

def get_latest_noise_reading(location_id):
    """Get the latest noise level reading for a location"""
    session = get_session()
    try:
        reading = session.query(NoiseReading)\
            .filter(NoiseReading.location_id == location_id)\
            .order_by(NoiseReading.reading_date.desc())\
            .first()
        return reading
    except SQLAlchemyError as e:
        logger.error(f"Error getting latest noise reading: {str(e)}")
        return None
    finally:
        close_session(session)

def get_noise_history(location_id, days=7):
    """Get historical noise level readings for a location"""
    session = get_session()
    try:
        start_date = datetime.datetime.utcnow() - datetime.timedelta(days=days)
        readings = session.query(NoiseReading)\
            .filter(NoiseReading.location_id == location_id)\
            .filter(NoiseReading.reading_date >= start_date)\
            .order_by(NoiseReading.reading_date.asc())\
            .all()
        return readings
    except SQLAlchemyError as e:
        logger.error(f"Error getting noise history: {str(e)}")
        return []
    finally:
        close_session(session)

# =============== User Feedback operations ===============

def add_user_feedback(user_id, location_id, feedback_type, feedback_text, rating=None):
    """Add user feedback or report"""
    session = get_session()
    try:
        feedback = UserFeedback(
            user_id=user_id,
            location_id=location_id,
            feedback_type=feedback_type,
            feedback_text=feedback_text,
            rating=rating,
            created_at=datetime.datetime.utcnow()
        )
        session.add(feedback)
        session.commit()
        logger.info(f"Added new user feedback for location {location_id}")
        return feedback.id
    except SQLAlchemyError as e:
        session.rollback()
        logger.error(f"Error adding user feedback: {str(e)}")
        return None
    finally:
        close_session(session)

def get_recent_feedbacks(location_id=None, limit=10):
    """Get recent user feedbacks, optionally filtered by location"""
    session = get_session()
    try:
        query = session.query(UserFeedback)\
            .order_by(UserFeedback.created_at.desc())
        
        if location_id:
            query = query.filter(UserFeedback.location_id == location_id)
            
        feedbacks = query.limit(limit).all()
        return feedbacks
    except SQLAlchemyError as e:
        logger.error(f"Error getting recent feedbacks: {str(e)}")
        return []
    finally:
        close_session(session)