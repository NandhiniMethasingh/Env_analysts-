import streamlit as st
import pandas as pd
import numpy as np
import folium
from streamlit_folium import folium_static
import datetime
import os
import sys
import math

# Add the project directory to the path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.data_fetcher import fetch_air_quality_data, fetch_water_quality_data, fetch_noise_data
from utils.health_assessment import calculate_health_risk
from utils.data_processor import process_air_quality_data, process_water_quality_data
from utils.visualization import create_aqi_gauge, plot_pollution_trends, create_map
from data.knowledge_base import get_health_tips, get_pollutant_info
from data.locations import STATES_DATA, get_all_cities, get_cities_in_state, get_state_descriptions, get_environmental_concerns

# Set page configuration
st.set_page_config(
    page_title="INDIA ENVHEALTH",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS customization for a more attractive interface
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
        font-weight: 700;
    }
    
    .sub-header {
        font-size: 1.8rem;
        color: #388E3C;
        margin-top: 2rem;
        margin-bottom: 1rem;
        font-weight: 500;
    }
    
    .card {
        background-color: #f8f9fa;
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .highlight {
        background-color: #e3f2fd;
        padding: 0.8rem;
        border-left: 4px solid #1E88E5;
        margin-bottom: 1rem;
    }
    
    .metric-good {
        font-weight: bold;
        color: #388E3C;
    }
    
    .metric-moderate {
        font-weight: bold;
        color: #FBC02D;
    }
    
    .metric-bad {
        font-weight: bold;
        color: #E53935;
    }
    
    .footer {
        text-align: center;
        margin-top: 3rem;
        color: #757575;
        font-size: 0.9rem;
    }
    
    /* Make the sidebar more attractive */
    div[data-testid="stSidebar"] {
        background-color: #e8f0fe;
        border-right: 1px solid #ccc;
        padding: 1rem;
        box-shadow: 2px 0px 5px rgba(0,0,0,0.1);
    }
    
    div[data-testid="stSidebar"] hr {
        margin-top: 1.5rem;
        margin-bottom: 1.5rem;
        border-color: #ccc;
    }
    
    div[data-testid="stSidebar"] .stTitle {
        color: #1565C0;
        font-weight: 700;
        text-align: center;
        padding: 0.3rem;
        border-bottom: 2px solid #1E88E5;
        margin-bottom: 1rem;
    }
    
    /* Improve radio button styling */
    div.row-widget.stRadio > div {
        flex-direction: column;
        align-items: stretch;
    }
    
    div.row-widget.stRadio > div label {
        background-color: #f8f9fa;
        border-radius: 5px;
        padding: 10px;
        margin-bottom: 5px;
        text-align: center;
        border-left: 3px solid #1E88E5;
        transition: all 0.3s;
    }
    
    div.row-widget.stRadio > div label:hover {
        background-color: #e3f2fd;
        border-left: 5px solid #1565C0;
        box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
    }
    
    /* Streamlit elements styling */
    div.stButton > button {
        background-color: #1E88E5;
        color: white;
        border-radius: 5px;
    }
    
    div.stButton > button:hover {
        background-color: #1565C0;
    }
    
    /* Style for selectboxes in sidebar */
    div[data-testid="stSidebar"] .stSelectbox label {
        color: #1565C0;
        font-weight: 600;
    }
    
    div[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div {
        background-color: #f8f9fa;
        border-radius: 5px;
        border-color: #dddfe2;
        border-width: 1px;
        padding: 5px;
    }
    
    div[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div:hover {
        border-color: #1565C0;
    }
</style>
""", unsafe_allow_html=True)

# Default locations
DEFAULT_STATE = "Tamil Nadu"
DEFAULT_CITY = "Chennai"
DEFAULT_LAT = 13.0827
DEFAULT_LON = 80.2707

def main():
    # App title and description
    st.markdown("<div class='main-header'>INDIA ENVHEALTH</div>", unsafe_allow_html=True)
    st.markdown("""
    <div class="highlight">
    This application provides real-time environmental quality monitoring and health impact assessments 
    across five Indian states. Monitor air quality, water quality, and noise pollution in your area 
    and understand potential health impacts through interactive visualizations and personalized recommendations.
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar
    st.sidebar.title("NAVIGATION")
    page = st.sidebar.radio(
        "Select a page:",
        ["DASHBOARD", "AIR QUALITY", "WATER QUALITY", "NOISE POLLUTION", "HEALTH IMPACT", "EDUCATIONAL RESOURCES"]
    )
    
    # Location selection
    st.sidebar.title("LOCATION SELECTION")
    
    # State selection
    selected_state = st.sidebar.selectbox(
        "Select State:",
        list(STATES_DATA.keys()),
        index=list(STATES_DATA.keys()).index(DEFAULT_STATE) if DEFAULT_STATE in STATES_DATA else 0
    )
    
    # Get cities for the selected state
    cities_in_state = get_cities_in_state(selected_state)
    city_names = [city[0] for city in cities_in_state]
    
    # City selection
    selected_city = st.sidebar.selectbox(
        "Select City:",
        city_names,
        index=city_names.index(DEFAULT_CITY) if DEFAULT_CITY in city_names else 0
    )
    
    # Get coordinates for the selected city
    city_info = next((city for city in cities_in_state if city[0] == selected_city), None)
    if city_info:
        latitude, longitude = city_info[1], city_info[2]
        city_description = city_info[3]
    else:
        latitude, longitude = DEFAULT_LAT, DEFAULT_LON
        city_description = "Major urban center"
    
    # Advanced location options - custom coordinates
    with st.sidebar.expander("Custom Location Options"):
        use_custom_coords = st.checkbox("Use Custom Coordinates")
        if use_custom_coords:
            custom_lat = st.number_input("Latitude:", value=latitude, format="%.4f", 
                                         min_value=6.0, max_value=37.0, step=0.0001)
            custom_lon = st.number_input("Longitude:", value=longitude, format="%.4f", 
                                         min_value=68.0, max_value=98.0, step=0.0001)
            latitude, longitude = custom_lat, custom_lon
    
    # Date selection for historical data
    st.sidebar.title("TIME PERIOD")
    today = datetime.date.today()
    selected_date = st.sidebar.date_input("Select date for historical data:", today)
    
    # Display state information in sidebar
    st.sidebar.markdown("---")
    st.sidebar.markdown(f"**{selected_state.upper()} INFORMATION**")
    st.sidebar.markdown(f"*{get_state_descriptions().get(selected_state, '')}*")
    
    # Show environmental concerns for the state
    concerns = get_environmental_concerns(selected_state)
    if concerns:
        st.sidebar.markdown("**MAJOR ENVIRONMENTAL CONCERNS:**")
        for concern in concerns:
            st.sidebar.markdown(f"- {concern}")
            
    # Add environmental health tips to sidebar
    st.sidebar.markdown("---")
    st.sidebar.markdown("### ENVIRONMENTAL HEALTH TIPS")
    
    # Add a random environmental health tip that changes based on the selected state
    import random
    
    env_health_tips = [
        "Wear a mask when AQI levels exceed 150 to protect your respiratory system.",
        "Boil water before drinking if the water quality index is below 60.",
        "Use noise-cancelling headphones in areas with high decibel levels.",
        "Keep indoor plants like Snake Plant and Peace Lily to improve indoor air quality.",
        "Limit outdoor activities during high pollution days, especially for children and elderly.",
        "Test your home for radon, a leading cause of lung cancer among non-smokers.",
        "Use HEPA air purifiers in your home to reduce indoor air pollutants.",
        "Stay hydrated to help your body process and eliminate toxins.",
        "Regular exercise improves your body's resilience to environmental stressors.",
        "Keep your windows closed during peak pollution hours (usually morning and evening)."
    ]
    
    # Get state-specific tips
    state_tips = {
        "Tamil Nadu": [
            "During Chennai's humid summers, stay hydrated and limit outdoor activities.",
            "Use air purifiers during festival seasons when air pollution increases.",
            "Report water contamination to the Tamil Nadu Pollution Control Board."
        ],
        "Maharashtra": [
            "In Mumbai, avoid beaches after heavy rainfall due to increased pollution.",
            "Use apps to monitor real-time AQI in high-traffic areas of Maharashtra cities.",
            "Filter tap water, as industrial pollution can affect water quality."
        ],
        "Karnataka": [
            "In Bangalore, protect yourself from vehicular pollution during peak traffic hours.",
            "Check lake water quality before recreational activities.",
            "Plant native species to help improve local air quality."
        ],
        "Gujarat": [
            "During industrial zone visits, wear appropriate protective gear.",
            "Check water salinity levels in coastal areas before consumption.",
            "Monitor air quality during festival seasons and Diwali."
        ],
        "West Bengal": [
            "Use water purifiers in areas with arsenic contamination.",
            "Check air quality during winter months when pollution levels rise.",
            "Avoid areas near the Hooghly river after industrial discharge days."
        ]
    }
    
    # Display general tip
    st.sidebar.info(random.choice(env_health_tips))
    
    # Display state-specific tip if available
    if selected_state in state_tips:
        st.sidebar.success(f"**{selected_state.upper()} TIP:** {random.choice(state_tips[selected_state])}")
    
    # Add educational quick links
    st.sidebar.markdown("### QUICK RESOURCES")
    st.sidebar.markdown("""
    - [Air Quality Standards](https://cpcb.nic.in/air-quality-standard/)
    - [Water Quality Guidelines](https://www.who.int/water_sanitation_health/water-quality/guidelines/en/)
    - [Noise Pollution Effects](https://www.who.int/europe/news-room/fact-sheets/item/noise)
    - [Health Protection Measures](https://www.mohfw.gov.in/)
    - [Environmental Laws in India](https://moef.gov.in/en/legislation/acts-rules/)
    """)
    
    # Add a separator at the bottom of sidebar
    st.sidebar.markdown("---")
    st.sidebar.markdown("<div class='footer'>© 2025 INDIA ENVHEALTH</div>", unsafe_allow_html=True)
    
    # Main content based on selected page
    if page == "DASHBOARD":
        show_dashboard(latitude, longitude, selected_date)
    elif page == "AIR QUALITY":
        # Import and run the air quality page
        from pages.air_quality import show_air_quality_page
        show_air_quality_page(latitude, longitude, selected_date)
    elif page == "WATER QUALITY":
        # Import and run the water quality page
        from pages.water_quality import show_water_quality_page
        show_water_quality_page(latitude, longitude, selected_date)
    elif page == "NOISE POLLUTION":
        # Import and run the noise pollution page
        from pages.noise_pollution import show_noise_pollution_page
        show_noise_pollution_page(latitude, longitude, selected_date)
    elif page == "HEALTH IMPACT":
        # Import and run the health impact page
        from pages.health_impact import show_health_impact_page
        show_health_impact_page(latitude, longitude, selected_date)
    elif page == "EDUCATIONAL RESOURCES":
        # Import and run the educational resources page
        from pages.educational_resources import show_educational_resources_page
        show_educational_resources_page()

def show_dashboard(latitude, longitude, selected_date):
    """Main dashboard showing overview of all environmental metrics"""
    
    # Display a loading spinner while fetching data
    with st.spinner("Fetching environmental data..."):
        # Fetch all environmental data
        air_data = fetch_air_quality_data(latitude, longitude, selected_date)
        water_data = fetch_water_quality_data(latitude, longitude, selected_date)
        noise_data = fetch_noise_data(latitude, longitude, selected_date)
        
        # Process the data
        processed_air_data = process_air_quality_data(air_data)
        processed_water_data = process_water_quality_data(water_data)
    
    # Location information
    st.markdown("<div class='sub-header'>Location Information</div>", unsafe_allow_html=True)
    
    # Use two columns for the location section
    loc_col1, loc_col2 = st.columns([2, 1])
    
    with loc_col1:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        map_data = create_map(latitude, longitude, 
                              air_quality=processed_air_data.get('aqi', 'N/A') if processed_air_data else 'N/A',
                              water_quality=processed_water_data.get('wqi', 'N/A') if processed_water_data else 'N/A',
                              noise_level=noise_data.get('decibel', 'N/A') if noise_data else 'N/A')
        folium_static(map_data)
        st.markdown("</div>", unsafe_allow_html=True)
    
    with loc_col2:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Location Details")
        st.markdown(f"**Latitude:** {latitude:.4f}")
        st.markdown(f"**Longitude:** {longitude:.4f}")
        
        # Get state information for the coordinates
        from utils.data_fetcher import get_state_for_location
        state_name = get_state_for_location(latitude, longitude)
        
        if state_name:
            st.markdown(f"**State:** {state_name}")
            
            # Display environmental concerns for this location
            concerns = get_environmental_concerns(state_name)
            if concerns:
                st.markdown("**Local Environmental Concerns:**")
                concerns_list = "<ul>" + "".join([f"<li>{concern}</li>" for concern in concerns[:3]]) + "</ul>"
                st.markdown(concerns_list, unsafe_allow_html=True)
        
        # Add current date and time
        st.markdown(f"**Data as of:** {selected_date.strftime('%B %d, %Y')}")
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Environmental quality section with improved visuals
    st.markdown("<div class='sub-header'>Current Environmental Quality</div>", unsafe_allow_html=True)
    
    # Use three columns for the quality metrics
    col1, col2, col3 = st.columns(3)
    
    # Air Quality
    with col1:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Air Quality")
        
        if processed_air_data and 'aqi' in processed_air_data:
            aqi = processed_air_data['aqi']
            
            # Determine color class based on AQI
            aqi_class = "metric-good"
            if aqi > 100:
                aqi_class = "metric-bad"
            elif aqi > 50:
                aqi_class = "metric-moderate"
                
            st.markdown(f"**AQI:** <span class='{aqi_class}'>{aqi}</span>", unsafe_allow_html=True)
            
            # Create gauge chart
            fig = create_aqi_gauge(aqi)
            st.plotly_chart(fig, use_container_width=True)
            
            # Add main pollutants if available
            if 'main_pollutants' in processed_air_data:
                st.markdown("**Main Pollutants:**")
                for pollutant in processed_air_data['main_pollutants'][:2]:  # Show top 2
                    st.markdown(f"- {pollutant}")
        else:
            st.warning("Air quality data unavailable for this location/date")
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Water Quality
    with col2:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Water Quality")
        
        if processed_water_data and 'wqi' in processed_water_data:
            wqi = processed_water_data['wqi']
            
            # Determine color class based on WQI (higher is better for water)
            wqi_class = "metric-good"
            if wqi < 50:
                wqi_class = "metric-bad"
            elif wqi < 70:
                wqi_class = "metric-moderate"
                
            st.markdown(f"**WQI:** <span class='{wqi_class}'>{wqi}</span>", unsafe_allow_html=True)
            
            # Create gauge chart for WQI
            from utils.visualization import create_wqi_gauge
            fig = create_wqi_gauge(wqi)
            st.plotly_chart(fig, use_container_width=True)
            
            # Show key parameters
            if processed_water_data.get('ph'):
                st.markdown(f"**pH Level:** {processed_water_data['ph']}")
            if processed_water_data.get('tds'):
                st.markdown(f"**TDS:** {processed_water_data['tds']} mg/L")
        else:
            st.warning("Water quality data unavailable for this location/date")
            
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Noise Pollution
    with col3:
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        st.markdown("### Noise Pollution")
        
        if noise_data and 'decibel' in noise_data:
            decibel = noise_data['decibel']
            
            # Determine color class based on noise level
            noise_class = "metric-good"
            if decibel > 70:
                noise_class = "metric-bad"
            elif decibel > 55:
                noise_class = "metric-moderate"
                
            st.markdown(f"**Noise Level:** <span class='{noise_class}'>{decibel} dB</span>", unsafe_allow_html=True)
            
            # Create gauge chart for noise
            from utils.visualization import create_noise_gauge
            fig = create_noise_gauge(decibel)
            st.plotly_chart(fig, use_container_width=True)
            
            # Show category if available
            if 'category' in noise_data:
                st.markdown(f"**Category:** {noise_data['category']}")
        else:
            st.warning("Noise data unavailable for this location/date")
            
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Health risk assessment with improved styling
    st.markdown("<div class='sub-header'>Health Impact Assessment</div>", unsafe_allow_html=True)
    
    if processed_air_data and processed_water_data and noise_data:
        health_risk = calculate_health_risk(processed_air_data, processed_water_data, noise_data)
        
        # Health risk cards
        st.markdown("<div class='card'>", unsafe_allow_html=True)
        
        risk_col1, risk_col2, risk_col3 = st.columns(3)
        
        with risk_col1:
            resp_risk = health_risk['respiratory_risk']
            resp_class = "metric-good"
            if resp_risk > 50:
                resp_class = "metric-bad"
            elif resp_risk > 25:
                resp_class = "metric-moderate"
                
            st.metric("Respiratory Health Risk", f"{resp_risk}%")
            st.markdown(f"<span class='{resp_class}'>{health_risk['respiratory_message']}</span>", unsafe_allow_html=True)
        
        with risk_col2:
            cardio_risk = health_risk['cardiovascular_risk']
            cardio_class = "metric-good"
            if cardio_risk > 50:
                cardio_class = "metric-bad"
            elif cardio_risk > 25:
                cardio_class = "metric-moderate"
                
            st.metric("Cardiovascular Health Risk", f"{cardio_risk}%")
            st.markdown(f"<span class='{cardio_class}'>{health_risk['cardiovascular_message']}</span>", unsafe_allow_html=True)
        
        with risk_col3:
            health_index = health_risk['overall_health_index']
            health_class = "metric-bad"
            if health_index > 7:
                health_class = "metric-good"
            elif health_index > 4:
                health_class = "metric-moderate"
                
            st.metric("Overall Health Index", f"{health_index}/10")
            st.markdown(f"<span class='{health_class}'>{health_risk['overall_message']}</span>", unsafe_allow_html=True)
        
        # Health recommendations in a highlight box
        st.markdown("<div class='highlight'>", unsafe_allow_html=True)
        st.markdown("### Recommended Health Actions")
        for recommendation in health_risk['recommendations']:
            st.markdown(f"- {recommendation}")
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.warning("Insufficient data to calculate health risks for this location/date")
    
    # Trends section with improved styling
    st.markdown("<div class='sub-header'>Environmental Trends</div>", unsafe_allow_html=True)
    
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    try:
        trends_fig = plot_pollution_trends(latitude, longitude, days=7)
        st.plotly_chart(trends_fig, use_container_width=True)
        
        # Add trend insights
        st.markdown("### Key Insights")
        st.markdown("- Trends are based on the last 7 days of environmental data")
        st.markdown("- Weekend patterns may show increased noise levels")
        st.markdown("- Air quality trends can help predict respiratory health risks")
        
    except Exception as e:
        st.error(f"Unable to load trend data: {str(e)}")
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Educational content section
    st.markdown("<div class='sub-header'>Environmental Health Tips</div>", unsafe_allow_html=True)
    
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    
    # Get health tips based on the current air quality
    tips = get_health_tips(processed_air_data.get('aqi', 0) if processed_air_data else 0)
    water_tips = []
    if processed_water_data and 'wqi' in processed_water_data:
        from data.knowledge_base import get_water_health_tips
        water_tips = get_water_health_tips(processed_water_data['wqi'])
    
    tips_col1, tips_col2 = st.columns(2)
    
    with tips_col1:
        st.markdown("### Air Quality Tips")
        for tip in tips[:4]:  # Show only top 4 tips
            st.markdown(f"- {tip}")
    
    with tips_col2:
        if water_tips:
            st.markdown("### Water Quality Tips")
            for tip in water_tips[:4]:  # Show only top 4 tips
                st.markdown(f"- {tip}")
        else:
            st.markdown("### Noise Health Tips")
            from data.knowledge_base import get_noise_health_tips
            noise_tips = get_noise_health_tips(noise_data.get('decibel', 60) if noise_data else 60)
            for tip in noise_tips[:4]:
                st.markdown(f"- {tip}")
    
    # Add a link to educational resources
    st.markdown("### Learn More")
    st.markdown("Visit the Educational Resources page for more information on environmental health impacts and prevention strategies.")
    
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Footer with data sources
    st.markdown("<div class='footer'>", unsafe_allow_html=True)
    st.markdown("Data sources: Environmental monitoring stations, synthesized data models, and health guidelines from WHO and national environmental agencies.")
    st.markdown("Last updated: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    st.markdown("</div>", unsafe_allow_html=True)

def initialize_database():
    """Initialize the database if not already initialized"""
    try:
        # Import the database initialization modules
        from database.connection import init_db
        
        # Initialize the database tables
        init_db()
        
        # Check if the database has locations
        from database.crud import get_locations_by_state
        locations = []
        for state in STATES_DATA.keys():
            locs = get_locations_by_state(state)
            if locs:
                locations.extend(locs)
        
        # If no locations, seed the database
        if not locations:
            st.info("Initializing database with locations and sample data...")
            from database.seed import seed_locations, seed_sample_readings
            
            # Seed locations
            loc_count = seed_locations()
            st.success(f"Seeded {loc_count} locations into the database")
            
            # Seed sample readings
            air_count, water_count, noise_count = seed_sample_readings()
            st.success(f"Seeded sample environmental readings into the database")
        
        return True
    except Exception as e:
        st.error(f"Error initializing database: {str(e)}")
        return False

if __name__ == "__main__":
    # Initialize the database
    db_initialized = initialize_database()
    
    # Run the main application
    main()
