// Environment Monitor Hub - Dashboard JavaScript

class EnvironmentDashboard {
    constructor() {
        this.charts = {};
        this.currentData = null;
        this.historicalData = [];
        this.loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadEnvironmentalData();
        this.checkModelStatus();
        
        // Auto-refresh every 5 minutes
        setInterval(() => {
            this.loadEnvironmentalData();
        }, 300000);
    }
    
    bindEvents() {
        // Refresh data button
        document.getElementById('refreshData').addEventListener('click', () => {
            this.loadEnvironmentalData();
        });
        
        // Train model button
        document.getElementById('trainModel').addEventListener('click', () => {
            this.trainModel();
        });
        
        // View predictions button
        document.getElementById('viewPredictions').addEventListener('click', () => {
            window.location.href = '/predictions';
        });
        
        // Export data button
        document.getElementById('exportData').addEventListener('click', () => {
            this.exportData();
        });
    }
    
    showLoading(message = 'Loading...') {
        document.getElementById('loadingMessage').textContent = message;
        this.loadingModal.show();
    }
    
    hideLoading() {
        this.loadingModal.hide();
    }
    
    showToast(message, type = 'info') {
        // Create and show a bootstrap toast
        const toastHtml = `
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;
        
        // Add to toast container (create if doesn't exist)
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        const toastElement = toastContainer.lastElementChild;
        const toast = new bootstrap.Toast(toastElement);
        toast.show();
        
        // Remove element after hiding
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
    
    async loadEnvironmentalData() {
        try {
            this.showLoading('Fetching environmental data...');
            
            const response = await fetch('/api/environmental-data');
            const data = await response.json();
            
            if (data.success) {
                this.currentData = data.current;
                this.historicalData = data.historical;
                
                this.updateCurrentConditions();
                this.updateCharts();
                this.updateRecentDataTable();
                
                this.showToast('Environmental data updated successfully', 'success');
            } else {
                throw new Error(data.error || 'Failed to fetch environmental data');
            }
        } catch (error) {
            console.error('Error loading environmental data:', error);
            this.showToast(`Error: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    updateCurrentConditions() {
        if (!this.currentData) return;
        
        // Update current condition displays
        document.getElementById('currentTemp').textContent = `${this.currentData.temperature}°C`;
        document.getElementById('currentHumidity').textContent = `${this.currentData.humidity}%`;
        document.getElementById('currentPressure').textContent = `${this.currentData.pressure} hPa`;
        document.getElementById('currentWind').textContent = `${this.currentData.wind_speed} m/s`;
        document.getElementById('currentLocation').textContent = this.currentData.location || 'Unknown Location';
        
        // Update timestamp
        const timestamp = new Date(this.currentData.timestamp);
        document.getElementById('lastUpdated').textContent = timestamp.toLocaleTimeString();
        
        // Add color coding based on values
        this.applyConditionColors();
    }
    
    applyConditionColors() {
        const tempElement = document.getElementById('currentTemp');
        const humidityElement = document.getElementById('currentHumidity');
        
        // Temperature color coding
        const temp = this.currentData.temperature;
        if (temp < 0) {
            tempElement.className = 'condition-value text-info';
        } else if (temp > 35) {
            tempElement.className = 'condition-value text-danger';
        } else if (temp > 25) {
            tempElement.className = 'condition-value text-warning';
        } else {
            tempElement.className = 'condition-value text-success';
        }
        
        // Humidity color coding
        const humidity = this.currentData.humidity;
        if (humidity < 30 || humidity > 80) {
            humidityElement.className = 'condition-value text-warning';
        } else {
            humidityElement.className = 'condition-value text-success';
        }
    }
    
    updateCharts() {
        if (this.historicalData.length === 0) return;
        
        // Prepare data for charts
        const sortedData = this.historicalData
            .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
            .slice(-24); // Last 24 records
        
        const labels = sortedData.map(item => {
            const date = new Date(item.timestamp);
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        });
        
        const temperatures = sortedData.map(item => item.temperature);
        const humidity = sortedData.map(item => item.humidity);
        const pressure = sortedData.map(item => item.pressure);
        
        this.updateTemperatureChart(labels, temperatures);
        this.updateHumidityPressureChart(labels, humidity, pressure);
    }
    
    updateTemperatureChart(labels, temperatures) {
        const ctx = document.getElementById('temperatureChart').getContext('2d');
        
        if (this.charts.temperature) {
            this.charts.temperature.destroy();
        }
        
        this.charts.temperature = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Temperature (°C)',
                    data: temperatures,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#ffffff'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y: {
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    updateHumidityPressureChart(labels, humidity, pressure) {
        const ctx = document.getElementById('humidityPressureChart').getContext('2d');
        
        if (this.charts.humidityPressure) {
            this.charts.humidityPressure.destroy();
        }
        
        // Normalize pressure data for better visualization
        const normalizedPressure = pressure.map(p => (p - 1000) / 2); // Scale pressure for dual axis
        
        this.charts.humidityPressure = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Humidity (%)',
                        data: humidity,
                        borderColor: '#17a2b8',
                        backgroundColor: 'rgba(23, 162, 184, 0.1)',
                        borderWidth: 2,
                        yAxisID: 'y',
                        tension: 0.4
                    },
                    {
                        label: 'Pressure (scaled)',
                        data: normalizedPressure,
                        borderColor: '#6f42c1',
                        backgroundColor: 'rgba(111, 66, 193, 0.1)',
                        borderWidth: 2,
                        yAxisID: 'y1',
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#ffffff'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            drawOnChartArea: false,
                        }
                    }
                }
            }
        });
    }
    
    updateRecentDataTable() {
        const tbody = document.getElementById('recentDataTable');
        
        if (this.historicalData.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No data available</td></tr>';
            return;
        }
        
        const recentData = this.historicalData
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 10);
        
        tbody.innerHTML = recentData.map(item => {
            const timestamp = new Date(item.timestamp);
            return `
                <tr>
                    <td>${timestamp.toLocaleString()}</td>
                    <td>${item.temperature}°C</td>
                    <td>${item.humidity}%</td>
                    <td>${item.pressure} hPa</td>
                    <td>${item.wind_speed} m/s</td>
                    <td><span class="badge bg-secondary">${item.weather_condition || 'N/A'}</span></td>
                </tr>
            `;
        }).join('');
    }
    
    async checkModelStatus() {
        try {
            const response = await fetch('/api/model-metrics');
            const data = await response.json();
            
            if (data.success) {
                this.displayModelMetrics(data.metrics);
            } else {
                this.displayModelNotTrained();
            }
        } catch (error) {
            console.error('Error checking model status:', error);
            this.displayModelNotTrained();
        }
    }
    
    displayModelMetrics(metrics) {
        const modelStatus = document.getElementById('modelStatus');
        const modelMetricsDiv = document.getElementById('modelMetrics');
        
        modelStatus.innerHTML = `
            <div class="d-flex align-items-center text-success">
                <i class="fas fa-check-circle me-2"></i>
                <span>Model trained and ready (${new Date(metrics.training_date).toLocaleDateString()})</span>
            </div>
        `;
        
        modelMetricsDiv.innerHTML = `
            <div class="col-md-3">
                <div class="metric-item">
                    <div class="metric-value">${(metrics.temperature_model.r2_score * 100).toFixed(1)}%</div>
                    <div class="metric-label">Temperature R²</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-item">
                    <div class="metric-value">${(metrics.weather_condition_model.accuracy * 100).toFixed(1)}%</div>
                    <div class="metric-label">Weather Accuracy</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-item">
                    <div class="metric-value">${metrics.training_data_size}</div>
                    <div class="metric-label">Training Samples</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="metric-item">
                    <div class="metric-value">${metrics.temperature_model.rmse.toFixed(2)}</div>
                    <div class="metric-label">Temp RMSE</div>
                </div>
            </div>
        `;
        
        modelMetricsDiv.style.display = 'flex';
    }
    
    displayModelNotTrained() {
        const modelStatus = document.getElementById('modelStatus');
        
        modelStatus.innerHTML = `
            <div class="d-flex align-items-center text-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <span>Model not trained. Click "Train Model" to start.</span>
            </div>
        `;
    }
    
    async trainModel() {
        try {
            this.showLoading('Training machine learning model...');
            
            const response = await fetch('/api/train-model', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.displayModelMetrics(data.metrics);
                this.showToast('Model trained successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to train model');
            }
        } catch (error) {
            console.error('Error training model:', error);
            this.showToast(`Training failed: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    async exportData() {
        try {
            this.showLoading('Preparing data export...');
            
            const response = await fetch('/api/export-data');
            const data = await response.json();
            
            if (data.success) {
                // Create and download JSON file
                const jsonData = JSON.stringify(data.data, null, 2);
                const blob = new Blob([jsonData], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                
                const a = document.createElement('a');
                a.href = url;
                a.download = `environmental_data_export_${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                this.showToast('Data exported successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to export data');
            }
        } catch (error) {
            console.error('Error exporting data:', error);
            this.showToast(`Export failed: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new EnvironmentDashboard();
});
