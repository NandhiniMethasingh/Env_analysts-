// Environment Monitor Hub - Predictions JavaScript

class PredictionsPage {
    constructor() {
        this.charts = {};
        this.predictionHistory = [];
        this.loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadModelMetrics();
        this.loadCurrentDataToForm();
    }
    
    bindEvents() {
        // Prediction form submission
        document.getElementById('predictionForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.makePrediction();
        });
        
        // Generate future predictions
        document.getElementById('generateFuturePredictions').addEventListener('click', () => {
            this.generateFuturePredictions();
        });
        
        // Model actions
        document.getElementById('retrainModel').addEventListener('click', () => {
            this.retrainModel();
        });
        
        document.getElementById('loadCurrentData').addEventListener('click', () => {
            this.loadCurrentDataToForm();
        });
        
        document.getElementById('exportPredictions').addEventListener('click', () => {
            this.exportPredictions();
        });
    }
    
    showLoading(message = 'Processing...') {
        document.getElementById('loadingMessage').textContent = message;
        this.loadingModal.show();
    }
    
    hideLoading() {
        this.loadingModal.hide();
    }
    
    showToast(message, type = 'info') {
        // Create and show a bootstrap toast
        const toastHtml = `
            <div class="toast align-items-center text-white bg-${type} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;
        
        // Add to toast container (create if doesn't exist)
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.insertAdjacentHTML('beforeend', toastHtml);
        const toastElement = toastContainer.lastElementChild;
        const toast = new bootstrap.Toast(toastElement);
        toast.show();
        
        // Remove element after hiding
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }
    
    async loadCurrentDataToForm() {
        try {
            this.showLoading('Loading current environmental data...');
            
            const response = await fetch('/api/environmental-data');
            const data = await response.json();
            
            if (data.success && data.current) {
                // Populate form with current data
                document.getElementById('inputTemp').value = data.current.temperature;
                document.getElementById('inputHumidity').value = data.current.humidity;
                document.getElementById('inputPressure').value = data.current.pressure;
                document.getElementById('inputWindSpeed').value = data.current.wind_speed;
                document.getElementById('inputWindDirection').value = data.current.wind_direction;
                
                this.showToast('Current data loaded into form', 'success');
            } else {
                throw new Error(data.error || 'Failed to load current data');
            }
        } catch (error) {
            console.error('Error loading current data:', error);
            this.showToast(`Error: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    async makePrediction() {
        try {
            this.showLoading('Making prediction...');
            
            // Get form data
            const inputData = {
                temperature: parseFloat(document.getElementById('inputTemp').value),
                humidity: parseFloat(document.getElementById('inputHumidity').value),
                pressure: parseFloat(document.getElementById('inputPressure').value),
                wind_speed: parseFloat(document.getElementById('inputWindSpeed').value),
                wind_direction: parseFloat(document.getElementById('inputWindDirection').value)
            };
            
            const response = await fetch('/api/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(inputData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.displayPredictionResults(data.prediction);
                this.addToPredictionHistory(inputData, data.prediction);
                this.showToast('Prediction completed successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to make prediction');
            }
        } catch (error) {
            console.error('Error making prediction:', error);
            this.showToast(`Prediction failed: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    displayPredictionResults(prediction) {
        const resultsDiv = document.getElementById('predictionResults');
        
        resultsDiv.innerHTML = `
            <div class="prediction-result fade-in">
                <h6 class="mb-3"><i class="fas fa-chart-bar me-2"></i>Prediction Results</h6>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="metric-item">
                            <div class="metric-value">${prediction.predicted_temperature.toFixed(1)}°C</div>
                            <div class="metric-label">Temperature</div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="metric-item">
                            <div class="metric-value">${prediction.predicted_humidity.toFixed(1)}%</div>
                            <div class="metric-label">Humidity</div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="metric-item">
                            <div class="metric-value">${prediction.predicted_pressure.toFixed(1)} hPa</div>
                            <div class="metric-label">Pressure</div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <div class="metric-item">
                            <div class="metric-value">${prediction.predicted_weather_condition}</div>
                            <div class="metric-label">Weather Condition</div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3">
                    <h6 class="text-muted">Confidence Scores</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <small class="prediction-confidence">
                                Temperature: ${(prediction.confidence_scores.temperature * 100).toFixed(1)}%
                            </small>
                        </div>
                        <div class="col-md-6">
                            <small class="prediction-confidence">
                                Weather: ${(prediction.confidence_scores.weather * 100).toFixed(1)}%
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    addToPredictionHistory(input, prediction) {
        const historyItem = {
            timestamp: new Date().toISOString(),
            input: input,
            prediction: prediction
        };
        
        this.predictionHistory.unshift(historyItem);
        
        // Keep only last 10 predictions
        if (this.predictionHistory.length > 10) {
            this.predictionHistory = this.predictionHistory.slice(0, 10);
        }
        
        this.updatePredictionHistoryTable();
    }
    
    updatePredictionHistoryTable() {
        const tbody = document.getElementById('predictionHistoryTable');
        
        if (this.predictionHistory.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No predictions made yet</td></tr>';
            return;
        }
        
        tbody.innerHTML = this.predictionHistory.map(item => {
            const timestamp = new Date(item.timestamp);
            const prediction = item.prediction;
            
            return `
                <tr>
                    <td>${timestamp.toLocaleTimeString()}</td>
                    <td>${prediction.predicted_temperature.toFixed(1)}°C</td>
                    <td>${prediction.predicted_humidity.toFixed(1)}%</td>
                    <td>${prediction.predicted_pressure.toFixed(1)} hPa</td>
                    <td><span class="badge bg-secondary">${prediction.predicted_weather_condition}</span></td>
                    <td>${(prediction.confidence_scores.weather * 100).toFixed(1)}%</td>
                </tr>
            `;
        }).join('');
    }
    
    async generateFuturePredictions() {
        try {
            this.showLoading('Generating future predictions...');
            
            const response = await fetch('/api/future-predictions');
            const data = await response.json();
            
            if (data.success) {
                this.displayFuturePredictionsChart(data.predictions);
                this.showToast('Future predictions generated!', 'success');
            } else {
                throw new Error(data.error || 'Failed to generate future predictions');
            }
        } catch (error) {
            console.error('Error generating future predictions:', error);
            this.showToast(`Failed to generate predictions: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    displayFuturePredictionsChart(predictions) {
        const ctx = document.getElementById('futurePredictionsChart').getContext('2d');
        
        if (this.charts.futurePredictions) {
            this.charts.futurePredictions.destroy();
        }
        
        const labels = predictions.map(p => {
            const date = new Date(p.prediction_date);
            return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        });
        
        const temperatures = predictions.map(p => p.predicted_temperature);
        const humidity = predictions.map(p => p.predicted_humidity);
        const pressure = predictions.map(p => p.predicted_pressure);
        
        this.charts.futurePredictions = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Temperature (°C)',
                        data: temperatures,
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Humidity (%)',
                        data: humidity,
                        borderColor: '#17a2b8',
                        backgroundColor: 'rgba(23, 162, 184, 0.1)',
                        borderWidth: 2,
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#ffffff'
                        }
                    },
                    title: {
                        display: true,
                        text: '7-Day Environmental Predictions',
                        color: '#ffffff'
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Temperature (°C)',
                            color: '#adb5bd'
                        },
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Humidity (%)',
                            color: '#adb5bd'
                        },
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            drawOnChartArea: false,
                        }
                    }
                }
            }
        });
    }
    
    async loadModelMetrics() {
        try {
            const response = await fetch('/api/model-metrics');
            const data = await response.json();
            
            if (data.success) {
                this.displayModelMetrics(data.metrics);
                this.displayFeatureImportance(data.metrics);
            } else {
                this.displayModelNotTrained();
            }
        } catch (error) {
            console.error('Error loading model metrics:', error);
            this.displayModelNotTrained();
        }
    }
    
    displayModelMetrics(metrics) {
        const metricsDiv = document.getElementById('performanceMetrics');
        
        metricsDiv.innerHTML = `
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${(metrics.temperature_model.r2_score * 100).toFixed(1)}%</div>
                        <div class="metric-label">Temperature R² Score</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${metrics.temperature_model.rmse.toFixed(2)}</div>
                        <div class="metric-label">Temperature RMSE</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${(metrics.weather_condition_model.accuracy * 100).toFixed(1)}%</div>
                        <div class="metric-label">Weather Accuracy</div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${metrics.training_data_size}</div>
                        <div class="metric-label">Training Samples</div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${(metrics.humidity_model.r2_score * 100).toFixed(1)}%</div>
                        <div class="metric-label">Humidity R² Score</div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${(metrics.pressure_model.r2_score * 100).toFixed(1)}%</div>
                        <div class="metric-label">Pressure R² Score</div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="metric-item">
                        <div class="metric-value">${(metrics.weather_condition_model.f1_score * 100).toFixed(1)}%</div>
                        <div class="metric-label">Weather F1 Score</div>
                    </div>
                </div>
            </div>
            
            <div class="mt-3">
                <small class="text-muted">
                    <i class="fas fa-calendar me-1"></i>
                    Last trained: ${new Date(metrics.training_date).toLocaleString()}
                </small>
            </div>
        `;
    }
    
    displayModelNotTrained() {
        const metricsDiv = document.getElementById('performanceMetrics');
        
        metricsDiv.innerHTML = `
            <div class="text-center text-warning">
                <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                <h5>Model Not Trained</h5>
                <p>Please train the model first to view performance metrics and make predictions.</p>
                <button onclick="window.location.href='/'" class="btn btn-primary">
                    <i class="fas fa-arrow-left me-1"></i>Go to Dashboard
                </button>
            </div>
        `;
    }
    
    displayFeatureImportance(metrics) {
        const featureNames = ['temperature', 'humidity', 'pressure', 'wind_speed', 'wind_direction', 'temp_humidity_ratio', 'pressure_normalized', 'wind_power'];
        
        // Temperature model feature importance
        this.createFeatureImportanceChart(
            'tempFeatureChart',
            'Temperature Model Feature Importance',
            featureNames,
            metrics.temperature_model.feature_importance
        );
        
        // Weather condition model feature importance
        this.createFeatureImportanceChart(
            'weatherFeatureChart',
            'Weather Condition Model Feature Importance',
            featureNames,
            metrics.weather_condition_model.feature_importance
        );
    }
    
    createFeatureImportanceChart(canvasId, title, labels, importance) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        if (this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }
        
        // Sort features by importance
        const sortedData = labels.map((label, index) => ({
            label: label,
            importance: importance[index]
        })).sort((a, b) => b.importance - a.importance);
        
        const sortedLabels = sortedData.map(item => item.label);
        const sortedImportance = sortedData.map(item => item.importance);
        
        this.charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: sortedLabels,
                datasets: [{
                    label: 'Importance',
                    data: sortedImportance,
                    backgroundColor: 'rgba(40, 167, 69, 0.6)',
                    borderColor: '#28a745',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: title,
                        color: '#ffffff'
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#adb5bd',
                            maxRotation: 45
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y: {
                        ticks: {
                            color: '#adb5bd'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    async retrainModel() {
        try {
            this.showLoading('Retraining machine learning model...');
            
            const response = await fetch('/api/train-model', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.displayModelMetrics(data.metrics);
                this.displayFeatureImportance(data.metrics);
                this.showToast('Model retrained successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to retrain model');
            }
        } catch (error) {
            console.error('Error retraining model:', error);
            this.showToast(`Retraining failed: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
    
    async exportPredictions() {
        try {
            if (this.predictionHistory.length === 0) {
                this.showToast('No predictions to export', 'warning');
                return;
            }
            
            this.showLoading('Preparing predictions export...');
            
            const exportData = {
                export_timestamp: new Date().toISOString(),
                prediction_history: this.predictionHistory,
                total_predictions: this.predictionHistory.length
            };
            
            // Create and download JSON file
            const jsonData = JSON.stringify(exportData, null, 2);
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `predictions_export_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showToast('Predictions exported successfully!', 'success');
        } catch (error) {
            console.error('Error exporting predictions:', error);
            this.showToast(`Export failed: ${error.message}`, 'danger');
        } finally {
            this.hideLoading();
        }
    }
}

// Initialize predictions page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PredictionsPage();
});
